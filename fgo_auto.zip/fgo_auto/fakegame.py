"""内置模拟游戏（mock 后端）。

它的作用不是替代游戏，而是让你在没有游戏 / 没有模拟器的情况下，
完整验证「截图 -> 模板识别 -> 流程执行 -> 战斗选卡 -> 剧情跳过 -> AP 回复」
这条链路是否正常，也用于自动化测试。

界面按 1280x720 生成，元素位置刻意和默认配置中的坐标一致。
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

import numpy as np

from .device import Device

CARD_COLORS = {
    "buster": (220, 38, 38),
    "arts": (37, 99, 235),
    "quick": (22, 163, 74),
}


def _font(size: int):
    from PIL import ImageFont

    for name in ("arial.ttf", "seguisb.ttf", "msyh.ttc"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size=size)
    except TypeError:  # 老版本 Pillow
        return ImageFont.load_default()


class MockGame:
    """一个极简的 FGO 式界面状态机。"""

    def __init__(self, size: tuple[int, int] = (1280, 720)):
        self.width, self.height = int(size[0]), int(size[1])
        self.state = "home"
        self.nodes_cleared = 0
        self.ap = 4
        self.turn = 0
        self.picked = 0
        self.dialog_left = 0
        self.card_colors: list[str] = []
        self.history: list[str] = []
        self._font_cache: dict[int, Any] = {}
        self._render_cache: dict[tuple, np.ndarray] = {}

    # -- 元素定义 -------------------------------------------------

    def elements(self) -> list[dict]:
        if self.state == "home":
            return [
                self._el("t_home", (40, 24, 260, 52), (37, 99, 235), "HOME"),
                self._el("t_terminal", (440, 620, 400, 76), (16, 185, 129), "TERMINAL"),
                self._el("hud_ap", (20, 660, 300, 44), (55, 65, 81), f"AP {self.ap}"),
            ]
        if self.state == "stage_select":
            return [
                self._el("t_stage_select", (40, 24, 420, 56), (147, 51, 234), "STAGE SELECT"),
                self._el("t_stage_node", (440, 280, 400, 96), (245, 158, 11), "NODE"),
                self._el("hud_node", (440, 386, 400, 40), (31, 41, 55),
                         f"CLEARED {self.nodes_cleared}"),
                self._el("hud_ap", (20, 660, 300, 44), (55, 65, 81), f"AP {self.ap}"),
            ]
        if self.state == "party":
            return [
                self._el("party_panel", (120, 140, 1040, 380), (30, 41, 59), "PARTY"),
                self._el("t_party_start", (860, 600, 360, 80), (16, 185, 129), "START BATTLE"),
            ]
        if self.state == "support":
            return [
                self._el("support_panel", (120, 140, 1040, 340), (17, 24, 39), "SUPPORT"),
                self._el("t_support_start", (860, 520, 360, 64), (59, 130, 246), "CHOOSE SUPPORT"),
            ]
        if self.state == "battle":
            return [
                self._el("battle_hud", (20, 20, 420, 56), (31, 41, 55),
                         f"TURN {self.turn + 1}"),
                self._el("enemy", (700, 180, 280, 260), (120, 53, 15), "ENEMY"),
                self._el("t_attack", (1000, 580, 220, 96), (220, 38, 38), "ATTACK"),
            ]
        if self.state == "battle_cards":
            items = [self._el("t_cards", (440, 24, 400, 56), (234, 88, 12), "CHOOSE CARDS")]
            for i, color in enumerate(self.card_colors):
                cx = int(round(float([0.20, 0.39, 0.58][i]) * self.width))
                cy = int(round(0.80 * self.height))
                bw = int(round(0.105 * self.width))
                bh = int(round(0.24 * self.height))
                items.append(
                    self._el(
                        f"card_{i}",
                        (cx - bw // 2, cy - bh // 2, bw, bh),
                        CARD_COLORS[color],
                        color.upper(),
                    )
                )
            return items
        if self.state == "result":
            return [
                self._el("result_panel", (160, 120, 960, 320), (15, 23, 42), "BATTLE RESULT"),
                self._el("t_result_continue", (900, 600, 340, 80), (202, 138, 4), "NEXT"),
            ]
        if self.state == "dialog":
            return [
                self._el("t_dialog", (60, 470, 460, 120), (30, 58, 138), "DIALOG"),
                self._el("dialog_name", (90, 430, 300, 46), (55, 65, 81), "SERVANT"),
                self._el("dialog_box", (60, 610, 1160, 90), (24, 34, 62), "tap to continue"),
            ]
        if self.state == "ap_restore":
            return [
                self._el("t_ap_restore", (340, 180, 600, 110), (153, 27, 27), "AP NOT ENOUGH"),
                self._el("t_use_apple", (480, 380, 320, 84), (21, 128, 61), "USE APPLE"),
            ]
        if self.state == "levelup":
            return [
                self._el("t_levelup", (340, 180, 600, 110), (161, 98, 7), "LEVEL UP!"),
                self._el("levelup_ok", (490, 560, 300, 80), (55, 65, 81), "OK"),
            ]
        return []

    @staticmethod
    def _el(name: str, box, color, label: str) -> dict:
        return {"name": name, "box": tuple(int(v) for v in box), "color": color, "label": label}

    # -- 交互 -----------------------------------------------------

    def tap(self, x: int, y: int) -> None:
        if self.state == "dialog":
            self._advance_dialog()
            return
        for el in self.elements():
            if _inside(el["box"], x, y):
                self._on(el["name"])
                return

    def back(self) -> None:
        if self.state in ("stage_select", "ap_restore", "levelup"):
            self.state = "home"

    def _on(self, name: str) -> None:
        self.history.append(f"{self.state}:{name}")
        if name == "t_terminal":
            self.state = "stage_select"
        elif name == "t_stage_node":
            if self.ap <= 0:
                self.state = "ap_restore"
            else:
                self.state = "party"
        elif name == "t_use_apple":
            self.ap += 3
            self.state = "party"
        elif name == "t_party_start":
            self.state = "support"
        elif name == "t_support_start":
            self.turn = 0
            self.picked = 0
            self.state = "battle"
        elif name == "t_attack":
            base = ["buster", "arts", "quick"]
            shift = (self.nodes_cleared + self.turn) % 3
            self.card_colors = base[shift:] + base[:shift]
            self.picked = 0
            self.state = "battle_cards"
        elif name.startswith("card_"):
            self.picked += 1
            if self.picked >= 3:
                self._resolve_turn()
        elif name == "t_result_continue":
            self.dialog_left = 2
            self.state = "dialog"
        elif name == "t_levelup" or name == "levelup_ok":
            self.state = "stage_select"
        elif name == "t_dialog":
            self._advance_dialog()

    def _resolve_turn(self) -> None:
        self.turn += 1
        if self.turn >= 2:
            self.state = "result"
        else:
            self.state = "battle"

    def _advance_dialog(self) -> None:
        self.dialog_left -= 1
        if self.dialog_left <= 0:
            self._clear_node()

    def _clear_node(self) -> None:
        self.nodes_cleared += 1
        self.ap = max(0, self.ap - 1)
        self.state = "levelup" if self.nodes_cleared % 4 == 0 else "stage_select"

    # -- 渲染 -----------------------------------------------------

    def _cache_key(self) -> tuple:
        return (
            self.state, self.turn, self.picked, self.nodes_cleared,
            self.ap, self.dialog_left, tuple(self.card_colors),
        )

    def render(self) -> np.ndarray:
        key = self._cache_key()
        cached = self._render_cache.get(key)
        if cached is not None:
            return cached
        return self._render_uncached(key)

    def _render_uncached(self, key: tuple) -> np.ndarray:
        from PIL import Image, ImageDraw

        backgrounds = {
            "home": (18, 18, 24),
            "stage_select": (22, 20, 28),
            "party": (20, 22, 26),
            "support": (18, 21, 24),
            "battle": (24, 18, 18),
            "battle_cards": (26, 20, 18),
            "result": (20, 20, 20),
            "dialog": (16, 18, 26),
            "ap_restore": (26, 16, 16),
            "levelup": (24, 22, 16),
        }
        img = Image.new("RGB", (self.width, self.height), backgrounds.get(self.state, (0, 0, 0)))
        draw = ImageDraw.Draw(img)
        for el in self.elements():
            x, y, w, h = el["box"]
            draw.rectangle([x, y, x + w - 1, y + h - 1], fill=el["color"],
                           outline=(235, 235, 235), width=2)
            size = max(12, min(30, int(h * 0.42)))
            font = self._font(size)
            draw.text((x + w // 2, y + h // 2), el["label"], fill=(245, 245, 245),
                      font=font, anchor="mm")
        if self.state == "battle_cards":
            draw.text((self.width // 2, 640), "tap cards", fill=(160, 160, 160),
                      font=self._font(26), anchor="mm")
        array = np.asarray(img, dtype=np.uint8)
        if len(self._render_cache) > 96:
            self._render_cache.clear()
        self._render_cache[key] = array
        return array

    def _font(self, size: int):
        if size not in self._font_cache:
            self._font_cache[size] = _font(size)
        return self._font_cache[size]


def _inside(box, x: int, y: int) -> bool:
    bx, by, bw, bh = box
    return bx <= x < bx + bw and by <= y < by + bh


class MockDevice(Device):
    """把 MockGame 包装成 Device。"""

    name = "mock"
    width = 1280
    height = 720

    def __init__(self, cfg: dict | None = None):
        size = (1280, 720)
        if cfg:
            expected = (cfg.get("device") or {}).get("expected_size")
            if isinstance(expected, (list, tuple)) and len(expected) == 2:
                size = (int(expected[0]), int(expected[1]))
        self.width, self.height = size
        self.game = MockGame(size)

    def screenshot(self) -> np.ndarray:
        time.sleep(0.01)
        return self.game.render()

    def tap(self, x: int, y: int) -> None:
        self.game.tap(int(x), int(y))

    def swipe(self, x1: int, y1: int, x2: int, y2: int, ms: int = 300) -> None:
        time.sleep(min(ms, 300) / 1000.0)

    def key(self, code: int = 4) -> None:
        if code == 4:
            self.game.back()

    # -- 模板导出 -------------------------------------------------

    def export_templates(self, directory: str | Path) -> int:
        """把模拟界面里的元素裁剪成模板，供识别流程使用。"""
        from PIL import Image

        target = Path(directory)
        target.mkdir(parents=True, exist_ok=True)
        saved = 0
        seen: set[str] = set()
        # 遍历每个状态，凡是 t_ 开头的元素都导出（用第一次出现的画面）
        orig = self.game.state
        try:
            for state in (
                "home", "stage_select", "party", "support", "battle",
                "battle_cards", "result", "dialog", "ap_restore", "levelup",
            ):
                self.game.state = state
                self.game.card_colors = ["buster", "arts", "quick"]
                frame = self.game.render()
                for el in self.game.elements():
                    name = el["name"]
                    if not name.startswith("t_") or name in seen:
                        continue
                    x, y, w, h = el["box"]
                    pad = 3
                    x0, y0 = max(0, x - pad), max(0, y - pad)
                    x1, y1 = min(self.width, x + w + pad), min(self.height, y + h + pad)
                    crop = frame[y0:y1, x0:x1]
                    Image.fromarray(crop, mode="RGB").save(target / f"{name}.png")
                    seen.add(name)
                    saved += 1
        finally:
            self.game.state = orig
        return saved


def ensure_mock_templates(device: Device, directory: str | Path) -> int:
    """mock 后端首次运行时自动生成模板。"""
    if not isinstance(device, MockDevice):
        return 0
    target = Path(directory)
    if target.is_dir() and any(target.glob("t_*.png")):
        return 0
    return device.export_templates(target)
