"""视觉层：纯 numpy 的归一化互相关（NCC）模板匹配。

不依赖 OpenCV：
  * FFT 算互相关 + 积分图算窗口均值/方差，等价于 cv2.TM_CCOEFF_NORMED；
  * 粗扫用低分辨率全帧搜索，取 top-K 候选；
  * 候选点在原分辨率上用局部积分图 + 点积精确评分（不做第二次 FFT）；
  * 每帧缓存灰度、缩放图与匹配结果，模板频谱也缓存。

1280x720 下约 6-12ms/模板（不含首帧预处理）。
坐标约定：Match 以左上角 (x, y) + 宽高表示，center 为中心点。
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

try:  # 有 OpenCV 就用它加速缩放，没有也能跑
    import cv2  # type: ignore
except Exception:  # pragma: no cover
    cv2 = None


WORK_TEMPLATE_MAX = 180   # 粗扫时模板最长边的大致上限（像素），控制 FFT 规模
COARSE_CANDIDATES = 3     # 粗扫保留的候选个数
REFINE_MAX_SIDE = 900     # 超过该边长的模板不做精确校验（整块面板类）


# ---------------------------------------------------------------- 基础工具

def to_gray(rgb: np.ndarray) -> np.ndarray:
    """RGB uint8 -> float32 灰度。"""
    a = np.asarray(rgb, dtype=np.float32)
    if a.ndim == 2:
        return a
    if a.shape[2] == 4:
        a = a[:, :, :3]
    return a[:, :, 0] * 0.299 + a[:, :, 1] * 0.587 + a[:, :, 2] * 0.114


def resize_gray(src: np.ndarray, w: int, h: int) -> np.ndarray:
    """缩放灰度图（缩小用面积重采样，放大用双线性）。"""
    w, h = max(2, int(w)), max(2, int(h))
    if (w, h) == (src.shape[1], src.shape[0]):
        return src.astype(np.float32, copy=False)
    if cv2 is not None:
        method = cv2.INTER_AREA if w < src.shape[1] else cv2.INTER_LINEAR
        return cv2.resize(src.astype(np.float32), (w, h), interpolation=method)
    from PIL import Image

    img = Image.fromarray(np.asarray(src, dtype=np.float32), mode="F")
    method = Image.LANCZOS if w < src.shape[1] else Image.BILINEAR
    return np.asarray(img.resize((w, h), method), dtype=np.float32)


def _integral(a: np.ndarray) -> np.ndarray:
    return np.pad(a.cumsum(0).cumsum(1), ((1, 0), (1, 0)), mode="constant")


def _window_sum(integral: np.ndarray, h: int, w: int) -> np.ndarray:
    """积分图上做 h x w 的滑动窗口求和，返回 (H-h+1, W-w+1)。"""
    return (
        integral[h:, w:]
        - integral[:-h, w:]
        - integral[h:, :-w]
        + integral[:-h, :-w]
    )


def _kernel_fft(kernel: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    """零均值模板翻转后的频谱，供互相关复用。"""
    fh, fw = shape
    return np.fft.rfft2(kernel[::-1, ::-1].astype(np.float32), s=(fh, fw))


def ncc(
    image: np.ndarray,
    template: np.ndarray,
    integral: np.ndarray | None = None,
    sq_integral: np.ndarray | None = None,
    kernel_fft: np.ndarray | None = None,
) -> np.ndarray | None:
    """归一化互相关，返回 (H-h+1, W-w+1) 的分数图；尺寸不合法返回 None。

    纯色窗口（方差极小）直接判 0 分：否则 FFT 的舍入误差会把分数放大到 >1。
    """
    H, W = image.shape
    h, w = template.shape
    if h > H or w > W or h < 2 or w < 2:
        return None
    t = np.asarray(template, dtype=np.float32)
    t = t - t.mean()
    t_energy = float(np.square(t, dtype=np.float64).sum())
    if t_energy < 1e-6 or t.std() < 2.0:  # 纯色模板，无法归一化
        return None

    fh, fw = H + h - 1, W + w - 1
    if kernel_fft is None:
        kernel_fft = _kernel_fft(t, (fh, fw))
    f_img = np.fft.rfft2(image.astype(np.float32), s=(fh, fw))
    conv = np.fft.irfft2(f_img * kernel_fft, s=(fh, fw))
    num = conv[h - 1 : H, w - 1 : W].astype(np.float64)

    img = image.astype(np.float64)
    if integral is None:
        integral = _integral(img)
    if sq_integral is None:
        sq_integral = _integral(img * img)
    s1 = _window_sum(integral, h, w)
    s2 = _window_sum(sq_integral, h, w)
    n = float(h * w)
    var = s2 - s1 * s1 / n
    valid = var >= 0.25  # std < 0.5 灰阶的窗口视为无纹理
    denom = np.sqrt(np.where(valid, var, 1.0) * t_energy)
    out = np.where(valid, num / denom, 0.0)
    return np.clip(out, -1.0, 1.0)


# ---------------------------------------------------------------- 数据结构

@dataclass
class Template:
    """一张模板图。gray 为全分辨率灰度，缩放结果按 (w, h) 缓存。"""

    name: str
    gray: np.ndarray
    rgb: np.ndarray
    path: str = ""
    threshold: float | None = None
    region: tuple[int, int, int, int] | None = None
    scales: tuple[float, ...] = (1.0,)
    color_tolerance: float | None = None
    _scaled: dict[Any, np.ndarray] = field(default_factory=dict, repr=False)
    _mean_rgb: np.ndarray | None = field(default=None, repr=False)

    @property
    def width(self) -> int:
        return int(self.gray.shape[1])

    @property
    def height(self) -> int:
        return int(self.gray.shape[0])

    @property
    def mean_rgb(self) -> np.ndarray:
        """模板的平均颜色，用于灰度匹配后的颜色校验。"""
        if self._mean_rgb is None:
            flat = self.rgb.reshape(-1, self.rgb.shape[2])[:, :3]
            self._mean_rgb = flat.astype(np.float64).mean(axis=0)
        return self._mean_rgb

    def at_size(self, w: int, h: int) -> np.ndarray:
        key = (int(w), int(h))
        if key not in self._scaled:
            self._scaled[key] = resize_gray(self.gray, w, h)
        return self._scaled[key]

    def scaled(self, scale: float) -> np.ndarray:
        if abs(scale - 1.0) < 1e-6:
            return self.gray
        return self.at_size(
            int(round(self.width * scale)), int(round(self.height * scale))
        )


@dataclass
class Match:
    """一次匹配结果。score 为 NCC 分数（-1~1）。"""

    name: str
    score: float
    x: int
    y: int
    w: int
    h: int

    @property
    def center(self) -> tuple[int, int]:
        return self.x + self.w // 2, self.y + self.h // 2

    @property
    def box(self) -> tuple[int, int, int, int]:
        return self.x, self.y, self.w, self.h

    def as_dict(self) -> dict:
        return {
            "name": self.name,
            "score": round(float(self.score), 4),
            "box": [self.x, self.y, self.w, self.h],
        }

    def __bool__(self) -> bool:  # 方便 if match:
        return self.score >= 0


class Frame:
    """一帧画面，缓存灰度、缩放图、积分图与匹配结果。"""

    def __init__(self, rgb: np.ndarray):
        self.rgb = np.ascontiguousarray(rgb)
        if self.rgb.ndim != 3 or self.rgb.shape[2] < 3:
            raise ValueError("Frame 需要 HxWx3 的 RGB 图像")
        self.height, self.width = int(self.rgb.shape[0]), int(self.rgb.shape[1])
        self._gray: np.ndarray | None = None
        self._small: dict[float, np.ndarray] = {}
        self._integrals: dict[float, tuple[np.ndarray, np.ndarray]] = {}
        self._cache: dict[tuple, Match] = {}

    @property
    def size(self) -> tuple[int, int]:
        return self.width, self.height

    def gray(self) -> np.ndarray:
        if self._gray is None:
            self._gray = to_gray(self.rgb)
        return self._gray

    def gray_small(self, scale: float) -> np.ndarray:
        if scale >= 0.999:
            return self.gray()
        if scale not in self._small:
            self._small[scale] = resize_gray(
                self.gray(),
                int(round(self.width * scale)),
                int(round(self.height * scale)),
            )
        return self._small[scale]

    def integrals(self, scale: float) -> tuple[np.ndarray, np.ndarray]:
        """该缩放比例下灰度图与灰度平方的积分图（每帧只算一次）。"""
        if scale not in self._integrals:
            g = self.gray_small(scale).astype(np.float64)
            self._integrals[scale] = (_integral(g), _integral(g * g))
        return self._integrals[scale]

    def crop(self, box: tuple[int, int, int, int]) -> np.ndarray:
        x, y, w, h = box
        x0, y0 = max(0, x), max(0, y)
        x1, y1 = min(self.width, x + w), min(self.height, y + h)
        return self.rgb[y0:y1, x0:x1].copy()


# ---------------------------------------------------------------- 匹配器

def normalize_region(
    region, width: int, height: int
) -> tuple[int, int, int, int] | None:
    """(x, y, w, h)，全 <=1 视为归一化。返回像素整数矩形。"""
    if not region:
        return None
    try:
        x, y, w, h = (float(v) for v in region)
    except (TypeError, ValueError):
        return None
    if max(abs(x), abs(y), abs(w), abs(h)) <= 1.0:
        x, y, w, h = x * width, y * height, w * width, h * height
    x, y = int(round(x)), int(round(y))
    w, h = int(round(w)), int(round(h))
    if w <= 1 or h <= 1:
        return None
    x = max(0, min(x, width - 2))
    y = max(0, min(y, height - 2))
    w = min(w, width - x)
    h = min(h, height - y)
    return x, y, w, h


def _crop_integral(
    integral: np.ndarray, x0: int, y0: int, x1: int, y1: int
) -> np.ndarray:
    """把整帧积分图裁成子区域（保持 (h+1, w+1) 形状）。"""
    out = integral[y0 : y1 + 1, x0 : x1 + 1].copy()
    if out.shape[0] < 2 or out.shape[1] < 2:
        return np.zeros((2, 2), dtype=np.float64)
    out -= out[0, :][None, :]
    out -= out[:, 0][:, None]
    return out


class Matcher:
    """模板匹配器。结果按帧缓存，同一帧内不重复计算。"""

    def __init__(
        self,
        min_score: float = 0.86,
        work_scale: float = 0.35,
        color_tolerance: float = 60.0,
    ):
        self.min_score = float(min_score)
        self.work_scale = min(max(float(work_scale), 0.15), 1.0)
        # 灰度 NCC 之后校验平均颜色，避免「同形状不同颜色」的按钮互相误判。
        # 0 或负数表示关闭该校验。
        self.color_tolerance = float(color_tolerance)
        self._kernel_cache: dict[tuple, np.ndarray] = {}

    # -- 对外 -----------------------------------------------------

    def clear_cache(self) -> None:
        """模板重新加载后清掉旧的频谱缓存。"""
        self._kernel_cache.clear()

    def find(
        self,
        frame: Frame,
        template: Template,
        threshold: float | None = None,
    ) -> Match | None:
        m = self.match(frame, template)
        thr = threshold if threshold is not None else (
            template.threshold if template.threshold is not None else self.min_score
        )
        if m.score < thr:
            return None
        # 颜色校验分两档：
        # - 分数一般（<0.93）：色差超过容差就拒绝，防「同形状不同颜色」误判；
        # - 分数很高（>=0.93）：只拒绝色差极大的情况（>硬上限），
        #   因为同一按钮在不同背景/过场里会整体偏色，不能一票否决。
        dist = self._color_distance(frame, template, m)
        hard = float(self.color_tolerance) * 2.0
        if dist is not None:
            if m.score < 0.93 and dist > self.color_tolerance:
                return None
            if dist > hard:
                return None
        return m

    def match(self, frame: Frame, template: Template) -> Match:
        key = (template.name, template.width, template.height, id(template))
        cached = frame._cache.get(key)
        if cached is not None:
            return cached
        result = self._match_uncached(frame, template)
        frame._cache[key] = result
        return result

    # -- 内部实现 -------------------------------------------------

    def color_ok(self, frame: Frame, template: Template, match: Match) -> bool:
        """公开的颜色校验（模板体检时用来区分「分数够但颜色不对」）。"""
        return self._color_ok(frame, template, match)

    def _color_distance(self, frame: Frame, template: Template, match: Match) -> float | None:
        """模板与命中区域的平均颜色距离；无法计算时返回 None。"""
        if self.color_tolerance is None or self.color_tolerance <= 0:
            return None
        if match.w <= 0 or match.h <= 0:
            return None
        x0 = max(0, match.x)
        y0 = max(0, match.y)
        x1 = min(frame.width, match.x + match.w)
        y1 = min(frame.height, match.y + match.h)
        if x1 <= x0 or y1 <= y0:
            return None
        patch = frame.rgb[y0:y1, x0:x1].reshape(-1, frame.rgb.shape[2])[:, :3]
        return float(np.linalg.norm(patch.mean(axis=0) - template.mean_rgb))

    def _color_ok(self, frame: Frame, template: Template, match: Match) -> bool:
        tolerance = (
            template.color_tolerance
            if template.color_tolerance is not None
            else self.color_tolerance
        )
        if tolerance is None or tolerance <= 0 or match.w <= 0 or match.h <= 0:
            return True
        x0 = max(0, match.x)
        y0 = max(0, match.y)
        x1 = min(frame.width, match.x + match.w)
        y1 = min(frame.height, match.y + match.h)
        if x1 <= x0 or y1 <= y0:
            return False
        patch = frame.rgb[y0:y1, x0:x1].reshape(-1, frame.rgb.shape[2])[:, :3]
        diff = patch.astype(np.float64).mean(axis=0) - template.mean_rgb
        return float(np.sqrt((diff * diff).sum())) <= tolerance

    def _match_uncached(self, frame: Frame, template: Template) -> Match:
        region = normalize_region(template.region, frame.width, frame.height)
        best: Match | None = None
        for tscale in template.scales or (1.0,):
            m = self._search(frame, template, tscale, region)
            if m is not None and (best is None or m.score > best.score):
                best = m
        if best is None:
            return Match(template.name, -1.0, 0, 0, 0, 0)
        return best

    def _search(
        self,
        frame: Frame,
        template: Template,
        tscale: float,
        region: tuple[int, int, int, int] | None,
    ) -> Match | None:
        tw = max(2, int(round(template.width * tscale)))
        th = max(2, int(round(template.height * tscale)))
        x0, y0, rw, rh = region or (0, 0, frame.width, frame.height)
        if rw < tw or rh < th:
            return None

        # 1) 低分辨率全帧粗扫，取 top-K 候选
        s = min(self.work_scale, max(0.15, WORK_TEMPLATE_MAX / float(max(tw, th))))
        candidates = self._coarse_candidates(
            frame, template, tscale, s, x0, y0, rw, rh
        )
        if not candidates:
            return None

        score, cx, cy = candidates[0]
        if score <= 0.2 or max(tw, th) > REFINE_MAX_SIDE:
            return Match(template.name, score, int(round(cx)), int(round(cy)), tw, th)

        # 2) 原分辨率精确校验（局部积分图 + 点积，不再做 FFT）
        best: Match | None = None
        for cand in candidates:
            refined = self._refine(
                frame, template, tscale, tw, th, cand, (x0, y0, x0 + rw, y0 + rh)
            )
            if refined is None:
                continue
            rscore, rx, ry = refined
            if best is None or rscore > best.score:
                best = Match(template.name, rscore, rx, ry, tw, th)
            if rscore >= 0.93:  # 基本可以确定位置正确
                break
        if best is None:
            return Match(template.name, score, int(round(cx)), int(round(cy)), tw, th)
        return best

    def _coarse_candidates(
        self,
        frame: Frame,
        template: Template,
        tscale: float,
        scale: float,
        x0: int,
        y0: int,
        rw: int,
        rh: int,
    ) -> list[tuple[float, float, float]]:
        """低分辨率搜索，返回 [(score, x, y)]（全分辨率坐标，score 降序）。"""
        img = frame.gray_small(scale)
        tpl = template.scaled(tscale * scale)
        tph, tpw = tpl.shape
        sx0 = max(0, int(math.floor(x0 * scale)))
        sy0 = max(0, int(math.floor(y0 * scale)))
        sx1 = min(img.shape[1], int(math.ceil((x0 + rw) * scale)))
        sy1 = min(img.shape[0], int(math.ceil((y0 + rh) * scale)))
        sub = img[sy0:sy1, sx0:sx1]
        if sub.shape[0] < tph or sub.shape[1] < tpw:
            return []

        integral, sq_integral = frame.integrals(scale)
        integral = _crop_integral(integral, sx0, sy0, sx1, sy1)
        sq_integral = _crop_integral(sq_integral, sx0, sy0, sx1, sy1)
        fh = sub.shape[0] + tph - 1
        fw = sub.shape[1] + tpw - 1
        cache_key = (id(template), round(tscale * scale, 4), tph, tpw, fh, fw)
        kernel_fft = self._kernel_cache.get(cache_key)
        if kernel_fft is None:
            kernel_fft = _kernel_fft(tpl - float(tpl.mean()), (fh, fw))
            if len(self._kernel_cache) > 64:
                self._kernel_cache.clear()
            self._kernel_cache[cache_key] = kernel_fft

        scores = ncc(sub, tpl, integral, sq_integral, kernel_fft)
        if scores is None or scores.size == 0:
            return []

        flat = scores.copy()
        radius_y = max(3, tph // 2)
        radius_x = max(3, tpw // 2)
        out: list[tuple[float, float, float]] = []
        for _ in range(COARSE_CANDIDATES):
            idx = int(np.argmax(flat))
            v, u = divmod(idx, flat.shape[1])
            sc = float(flat[v, u])
            if sc <= 0.0:
                break
            out.append((sc, (sx0 + u) / scale, (sy0 + v) / scale))
            ys, ye = max(0, v - radius_y), min(flat.shape[0], v + radius_y + 1)
            xs, xe = max(0, u - radius_x), min(flat.shape[1], u + radius_x + 1)
            flat[ys:ye, xs:xe] = -2.0
        out.sort(key=lambda item: -item[0])
        return out

    def _refine(
        self,
        frame: Frame,
        template: Template,
        tscale: float,
        tw: int,
        th: int,
        candidate: tuple[float, float, float],
        bounds: tuple[int, int, int, int],
        pad: int = 3,
    ) -> tuple[float, int, int] | None:
        """在候选点 ±pad 像素内做原分辨率精确 NCC，返回 (score, x, y)。"""
        _, cx, cy = candidate
        gray = frame.gray()
        tpl = template.gray if abs(tscale - 1.0) < 1e-6 else template.scaled(tscale)
        t = tpl.astype(np.float64)
        t -= t.mean()
        t_energy = float((t * t).sum())
        if t_energy < 1e-6:
            return None

        bx, by = int(round(cx)), int(round(cy))
        x0, y0, x1, y1 = bounds
        rx0 = max(x0, bx - pad)
        ry0 = max(y0, by - pad)
        rx1 = min(x1, bx + tw + pad)
        ry1 = min(y1, by + th + pad)
        if rx1 - rx0 < tw or ry1 - ry0 < th:
            return None

        roi = gray[ry0:ry1, rx0:rx1].astype(np.float64)
        ii = _integral(roi)
        ii2 = _integral(roi * roi)
        n = float(tw * th)
        best_score = -2.0
        best_xy = (bx, by)
        for dy in range(-pad, pad + 1):
            py = by + dy - ry0
            if py < 0 or py + th > roi.shape[0]:
                continue
            for dx in range(-pad, pad + 1):
                px = bx + dx - rx0
                if px < 0 or px + tw > roi.shape[1]:
                    continue
                s1 = (
                    ii[py + th, px + tw] - ii[py, px + tw]
                    - ii[py + th, px] + ii[py, px]
                )
                s2 = (
                    ii2[py + th, px + tw] - ii2[py, px + tw]
                    - ii2[py + th, px] + ii2[py, px]
                )
                var = s2 - s1 * s1 / n
                if var < 0.25 * n:
                    continue
                patch = roi[py : py + th, px : px + tw]
                score = float((patch * t).sum()) / math.sqrt(var * t_energy)
                if score > best_score:
                    best_score = score
                    best_xy = (rx0 + px, ry0 + py)
        if best_score <= -1.5:
            return None
        return min(best_score, 1.0), best_xy[0], best_xy[1]
