"""命令行入口。

python -m fgo_auto.cli run --mock          # 无游戏演示
python -m fgo_auto.cli run                 # 连真机/模拟器
python -m fgo_auto.cli check               # 检查模板与配置
python -m fgo_auto.cli shot out.png        # 截一张图确认连接
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

from . import __version__
from .config import ensure_config_file, load_config
from .device import DeviceError
from .engine import Engine, configure_logging
from .templates import template_usage

BASE_DIR = Path(__file__).resolve().parents[1]
LOG = logging.getLogger("fgo_auto")


def _utf8_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
        except Exception:  # pragma: no cover
            pass


def _prepare(args: argparse.Namespace) -> dict:
    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = BASE_DIR / config_path
    ensure_config_file(config_path)
    cfg = load_config(config_path)
    if getattr(args, "mock", False):
        cfg["device"]["backend"] = "mock"
    if getattr(args, "backend", None):
        cfg["device"]["backend"] = args.backend
    if getattr(args, "dry_run", False):
        cfg["runtime"]["dry_run"] = True
    if getattr(args, "minutes", 0):
        cfg["runtime"]["max_minutes"] = float(args.minutes)
    if getattr(args, "steps", 0):
        cfg["runtime"]["max_steps"] = int(args.steps)
    if getattr(args, "plan", ""):
        cfg["battle"]["plan"] = args.plan
    if getattr(args, "mode", ""):
        cfg["loop"]["mode"] = args.mode
    return cfg


def _make_engine(cfg: dict, quiet: bool = False) -> Engine:
    engine = Engine(cfg, base_dir=BASE_DIR)
    if not quiet:
        missing = engine.missing_templates()
        print(f"设备: {engine.device.name}  {engine.device.size[0]}x{engine.device.size[1]}")
        print(f"模板目录: {engine.templates_dir}  已加载 {len(engine.store)} 张")
        if missing:
            print(f"缺失模板({len(missing)}): {', '.join(missing)}")
        for warn in engine.store.warnings:
            print(f"模板告警: {warn}")
    return engine


# ---------------------------------------------------------------- 子命令

def cmd_run(args: argparse.Namespace) -> int:
    cfg = _prepare(args)
    configure_logging(BASE_DIR / str(cfg["runtime"].get("log_dir", "logs")), logging.INFO)
    try:
        engine = _make_engine(cfg)
    except DeviceError as exc:
        print(f"连接设备失败：{exc}")
        return 2
    print("-" * 60)
    try:
        engine.run_forever()
    except KeyboardInterrupt:
        engine.stop()
        print("\n已手动中断")
    stats = engine.stats
    print("-" * 60)
    print(
        f"结束：步数 {stats['steps']}，点击 {stats['taps']}，"
        f"未知画面 {stats['unknown']}，用时 {stats['elapsed']:.0f}s"
    )
    if engine.last_error:
        print(f"错误: {engine.last_error}")
        return 1
    return 0


def cmd_check(args: argparse.Namespace) -> int:
    cfg = _prepare(args)
    usage = template_usage(cfg)
    from .templates import TemplateStore
    from .config import get_path, template_dir

    store = TemplateStore(
        template_dir(cfg, BASE_DIR),
        meta_name=str(get_path(cfg, "templates.meta", "templates.json")),
        default_scales=tuple(get_path(cfg, "vision.scales", [1.0]) or (1.0,)),
    ).reload()

    print(f"配置: {args.config}")
    print(f"后端: {get_path(cfg, 'device.backend')}")
    print(f"模板目录: {store.dir}")
    print(f"已加载 {len(store)} 张，流程 {len(cfg.get('flows', []))} 个")
    missing = store.missing(usage)
    if missing:
        print(f"\n缺失模板 {len(missing)} 张：")
        for name in missing:
            where = ", ".join(usage.get(name) or []) or "—"
            print(f"  - {name:<24} 用于: {where}")
    else:
        print("\n模板齐全。")
    if store.warnings:
        print("\n模板告警：")
        for warn in store.warnings:
            print(f"  - {warn}")
    if store.errors:
        print("\n读取错误：")
        for err in store.errors:
            print(f"  - {err}")
    return 0 if not store.errors else 1


def cmd_probe(args: argparse.Namespace) -> int:
    """截一张图并做完整自检（黑屏/分辨率/界面指纹/模板命中）。"""
    cfg = _prepare(args)
    configure_logging(BASE_DIR / str(cfg["runtime"].get("log_dir", "logs")), logging.WARNING)
    try:
        engine = _make_engine(cfg, quiet=True)
    except DeviceError as exc:
        print(f"连接设备失败：{exc}")
        return 2

    report = engine.inspect_screen()
    print(report.as_text())
    print()
    print(f"设备：{engine.device.name}　界面库样本：{len(engine.scenes)}")

    if args.save:
        from PIL import Image

        out = Path(args.save)
        if not out.is_absolute():
            out = BASE_DIR / out
        out.parent.mkdir(parents=True, exist_ok=True)
        frame = engine.last_frame
        if frame is not None:
            Image.fromarray(frame.rgb, mode="RGB").save(out)
            print(f"截图已保存：{out}")
    return 0


def cmd_scenes(args: argparse.Namespace) -> int:
    """查看 / 清空界面指纹库。"""
    from .config import get_path
    from .scene import SceneLibrary

    cfg = _prepare(args)
    lib = SceneLibrary.load(
        BASE_DIR / "scenes.json",
        threshold=float(get_path(cfg, "scene.threshold", 0.88)),
    )
    if args.clear:
        lib.clear()
        lib.save(force=True)
        print("已清空界面库，scenes.json 已重置。")
        return 0
    if args.forget:
        if lib.remove(args.forget):
            lib.save(force=True)
            print(f"已删除界面「{args.forget}」")
            return 0
        print(f"界面库里没有「{args.forget}」")
        return 1

    print(f"界面库：{lib.path}")
    print(f"阈值 {lib.threshold:.2f}，共 {lib.total()} 个样本 / {len(lib.names())} 个界面")
    if not lib.total():
        print("（空：运行时会自动学习，或在界面里点「学习当前界面」）")
        return 0
    for name, count in lib.summary():
        print(f"  - {name:<20} {count} 个样本")
    return 0


def cmd_devices(args: argparse.Namespace) -> int:
    """自动探测模拟器 / adb / 设备，并给出可直接粘贴的配置。"""
    from .adbscan import describe, scan

    cfg = _prepare(args)
    print("正在探测模拟器与设备（最多 %.0f 秒）…" % float(args.timeout))
    candidates = scan(cfg, deadline=float(args.timeout))
    print(describe(candidates))
    if not candidates and getattr(args, "launch", False):
        from .adbscan import last_emulators, start_and_connect

        emus = last_emulators()
        if emus:
            emu = emus[0]
            wait = float(cfg["device"].get("launch_wait", 120) or 120)
            index = int(cfg["device"].get("emulator_index", 0) or 0)
            print(f"尝试启动 {emu.label}（最多等 {wait:.0f} 秒）…")
            serial, message = start_and_connect(emu, index=index, timeout=wait)
            print(message)
            if serial:
                candidates = scan(cfg, deadline=float(args.timeout))
                print(describe(candidates))

    if not candidates:
        from .adbscan import last_emulators

        emus = last_emulators()
        if emus:
            names = "、".join(f"{e.label}({e.adb_path or '未找到 adb'})" for e in emus)
            print(f"\n检测到模拟器：{names}")
            print("但没有可用设备——请先启动模拟器并进入桌面，再确认开启了 ADB 调试。")
        else:
            print("\n没有探测到模拟器。请确认已安装 MuMu / LDPlayer / BlueStacks / 夜神等，并启动它。")
        return 1
    best = candidates[0]
    print("\n建议写入 config.json 的 device 段：")
    print('  "device": {')
    print('    "backend": "adb",')
    print(f'    "adb_path": {json.dumps(best.adb, ensure_ascii=False)},')
    print(f'    "serial": {json.dumps(best.serial, ensure_ascii=False)}')
    print("  }")
    if best.has_fgo:
        print(f"\n该设备已安装 FGO：{best.fgo_package}")
    return 0


def cmd_shot(args: argparse.Namespace) -> int:
    cfg = _prepare(args)
    configure_logging(BASE_DIR / str(cfg["runtime"].get("log_dir", "logs")), logging.WARNING)
    try:
        engine = _make_engine(cfg, quiet=True)
    except DeviceError as exc:
        print(f"连接设备失败：{exc}")
        return 2
    frame = engine.grab()
    out = Path(args.output)
    if not out.is_absolute():
        out = BASE_DIR / out
    out.parent.mkdir(parents=True, exist_ok=True)
    from PIL import Image

    Image.fromarray(frame.rgb, mode="RGB").save(out)
    print(f"已保存截图 {out}  ({frame.width}x{frame.height})")
    return 0


# ---------------------------------------------------------------- 参数

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="fgo-auto", description="FGO 主线自动推进器（命令行）"
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    def add_common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--config", default="config.json", help="配置文件路径")
        p.add_argument("--mock", action="store_true", help="使用内置模拟游戏")
        p.add_argument(
            "--backend", choices=["adb", "mock"], help="强制指定后端（覆盖配置）"
        )
        p.add_argument("--dry-run", action="store_true", help="只识别不点击")
        p.add_argument("--minutes", type=float, default=0, help="最长运行分钟数")
        p.add_argument("--steps", type=int, default=0, help="最多执行步数")
        p.add_argument("--plan", default="", help="战斗方案 JSON 路径")
        p.add_argument("--mode", choices=["story", "farm"], help="循环模式：推主线 / 刷本")

    run = sub.add_parser("run", help="开始自动推主线")
    add_common(run)
    run.set_defaults(func=cmd_run)

    check = sub.add_parser("check", help="检查模板与配置")
    add_common(check)
    check.set_defaults(func=cmd_check)

    probe = sub.add_parser("probe", help="检测当前模拟器画面（自检）")
    add_common(probe)
    probe.add_argument("--save", default="", help="顺便保存截图到指定路径")
    probe.set_defaults(func=cmd_probe)

    scenes = sub.add_parser("scenes", help="查看 / 清空界面指纹库")
    add_common(scenes)
    scenes.add_argument("--clear", action="store_true", help="清空全部界面指纹")
    scenes.add_argument("--forget", default="", help="删除指定界面")
    scenes.set_defaults(func=cmd_scenes)

    devices = sub.add_parser("devices", help="自动探测模拟器 / adb / 设备")
    add_common(devices)
    devices.add_argument("--timeout", type=float, default=20, help="探测时间上限（秒）")
    devices.add_argument("--launch", action="store_true", help="没有设备时尝试启动模拟器并等待")
    devices.set_defaults(func=cmd_devices)

    shot = sub.add_parser("shot", help="截图（验证连接）")
    add_common(shot)
    shot.add_argument("output", nargs="?", default="logs/shot.png")
    shot.set_defaults(func=cmd_shot)
    return parser


def main(argv: list[str] | None = None) -> int:
    _utf8_console()
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
