"""主循环：截屏 -> 识别流程 -> 执行动作 -> 异常恢复。

Engine 既可以被 CLI 直接 run()，也可以在 GUI 里 start()/stop()/单步。
"""

from __future__ import annotations

import hashlib
import json
import logging
import random
import threading
import time
from pathlib import Path
from typing import Any

import numpy as np

from . import actions as actions_mod
from .actions import ActionError, Ctx
from .config import get_path, template_dir
from .device import Device, DeviceError, create_device
from .plan import BattlePlan
from .report import Report
from .scene import SceneLibrary, fingerprint
from .templates import TemplateStore, collect_template_names
from .vision import Frame, Match, Matcher

LOG = logging.getLogger("fgo_auto")

_LEVELS = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warn": logging.WARNING,
    "warning": logging.WARNING,
    "error": logging.ERROR,
}


def flow_sort_key(flows: list[dict], index: int, hint: int | None = None) -> tuple:
    """流程排序键：优先级高 → 条件更具体 → 上次命中提示 → 配置顺序。

    早期实现把「上次命中的流程」无条件提到最前，导致「跳过」会把刚弹出的
    「跳过确认」压在后面，出现连续点跳过却点不到确认的死循环。
    """
    flow = flows[index] if 0 <= index < len(flows) else {}
    rule = flow.get("detect") or {}
    specific = (
        len(rule.get("any") or []) + len(rule.get("all") or []) + len(rule.get("none") or [])
    )
    priority = float(flow.get("priority", 0) or 0)
    hinted = 0 if hint is not None and index == hint else 1
    return (-priority, -specific, hinted, index)


def story_limit_reached(clears: int, limit: int) -> bool:
    """MaaFgo 风格：自动推主线按「推进关数」计数，达到上限就停。"""
    return int(limit) > 0 and int(clears) >= int(limit)


def unknown_screen_key(rgb: np.ndarray) -> str:
    """未知界面聚类键：粗采样 + 量化，容忍轻微动画/亮度波动。"""
    # 32px 采样 + 强量化：只保留「布局级」特征，忽略动画/亮度抖动
    sig = np.asarray(rgb[::32, ::32, :3], dtype=np.int16)
    quant = np.clip(sig // 32, 0, 7).astype(np.uint8)
    return hashlib.md5(quant.tobytes()).hexdigest()[:12]


def screen_is_dynamic(prev_sig, sig, threshold: float = 3.0) -> bool:
    """画面在明显变化 = 战斗动画/过场，不该按「卡住」处理。"""
    if prev_sig is None:
        return False
    return _sig_diff(sig, prev_sig) > float(threshold)


def unknown_stuck(prev_sig, sig, count: int, threshold: float = 3.0, limit: int = 5) -> bool:
    """连续未识别、且画面几乎没变 → 认为卡在一个没有模板的界面。"""
    if prev_sig is None or int(count) < int(limit):
        return False
    return _sig_diff(sig, prev_sig) < float(threshold)


def enabled_flows(flows: list[dict], skip_story: bool = True) -> list[dict]:
    """过滤掉显式关闭的流程（enabled: false）；skip_story=False 时关掉剧情跳过类流程。"""
    result = []
    for flow in flows:
        if not isinstance(flow, dict) or not flow.get("enabled", True):
            continue
        if not skip_story and str(flow.get("name", "")).startswith("剧情跳过"):
            continue
        result.append(flow)
    return result


class EngineHalt(RuntimeError):
    """需要停止整个自动化流程的错误。"""


def _signature(rgb: np.ndarray) -> np.ndarray:
    """画面指纹：隔 16 像素采样，用于判断两帧是否几乎相同。"""
    return rgb[::16, ::16, :3].astype(np.int16)


def _sig_diff(a: np.ndarray, b: np.ndarray) -> float:
    if a.shape != b.shape:
        return 999.0
    return float(np.abs(a - b).mean())


def configure_logging(log_dir: str | Path | None = None, level: int = logging.INFO) -> None:
    """配置基础日志（文件 + 控制台），GUI 会额外挂自己的 handler。"""
    root = logging.getLogger("fgo_auto")
    root.setLevel(level)
    if not any(isinstance(h, logging.StreamHandler) and not isinstance(h, logging.FileHandler)
               for h in root.handlers):
        console = logging.StreamHandler()
        console.setFormatter(logging.Formatter("%(asctime)s %(levelname)-5s %(message)s", "%H:%M:%S"))
        root.addHandler(console)
    if log_dir:
        path = Path(log_dir)
        path.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(path / "fgo_auto.log", encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)-5s %(message)s"))
        root.addHandler(fh)


class Engine:
    def __init__(
        self,
        cfg: dict[str, Any],
        base_dir: str | Path | None = None,
        device: Device | None = None,
    ):
        self.cfg = cfg
        self.base_dir = Path(base_dir) if base_dir else Path.cwd()
        self.log_dir = self.base_dir / str(get_path(cfg, "runtime.log_dir", "logs"))
        self.templates_dir = template_dir(cfg, self.base_dir)
        self.device = device or create_device(cfg)
        # mock 后端首次运行自动生成模板，保证开箱即用
        export = getattr(self.device, "export_templates", None)
        if callable(export) and not any(self.templates_dir.glob("*.png")):
            export(self.templates_dir)
        self.store = TemplateStore(
            self.templates_dir,
            meta_name=str(get_path(cfg, "templates.meta", "templates.json")),
            default_scales=tuple(get_path(cfg, "vision.scales", [1.0]) or (1.0,)),
        ).reload()
        self.matcher = Matcher(
            min_score=float(get_path(cfg, "vision.min_score", 0.86)),
            work_scale=float(get_path(cfg, "vision.work_scale", 0.35)),
            color_tolerance=float(get_path(cfg, "vision.color_tolerance", 60)),
        )
        self.dry_run = bool(get_path(cfg, "runtime.dry_run", False))

        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._lock = threading.RLock()
        self._last_flow_ts: dict[str, float] = {}
        self._warned: set[str] = set()
        self._unknown_screens: dict[str, dict] = {}
        # 识别加速：画面几乎没变时复用上次结果；上次命中的流程优先复测
        self._last_sig: np.ndarray | None = None
        self._last_detection: tuple[dict, dict[str, Match]] | None = None
        self._flow_hint: int | None = None

        self.stats: dict[str, Any] = {
            "steps": 0,
            "taps": 0,
            "unknown": 0,
            "consecutive_unknown": 0,
            "flows": {},
            "cards_picked": 0,
            "card_colors": 0,
            "started_at": None,
            "elapsed": 0.0,
        }
        self.battle_turn = 0
        self.last_frame: Frame | None = None
        self.last_flow: str | None = None
        self.last_matches: list[Match] = []
        self.last_error: str | None = None
        self.running = False

        actions_mod.load_builtin_calls()
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.report = Report(
            self.log_dir, enabled=bool(get_path(cfg, "runtime.report", True))
        )
        self.battle_plan: BattlePlan | None = None
        self._load_plan_from_cfg()

        # 界面自动识别
        self.auto_learn = bool(get_path(cfg, "scene.auto_learn", True))
        self.scene_margin = float(get_path(cfg, "scene.margin", 0.05))
        self.scenes = SceneLibrary.load(
            self.base_dir / "scenes.json",
            threshold=float(get_path(cfg, "scene.threshold", 0.88)),
        )
        self.scenes.enabled = bool(get_path(cfg, "scene.enabled", True))
        self.last_scene: tuple[str, float] | None = None
        self.last_via: str | None = None
        self._flow_index: dict[str, dict] = {
            str(flow.get("name")): flow
            for flow in (cfg.get("flows") or [])
            if isinstance(flow, dict) and flow.get("name")
        }

    # ------------------------------------------------------------ 战斗方案

    def _load_plan_from_cfg(self) -> None:
        spec = get_path(self.cfg, "battle.plan", "")
        if not spec:
            return
        try:
            self.set_plan(spec)
        except (ValueError, OSError) as exc:
            self.log(f"战斗方案加载失败，改用旧技能轴：{exc}", "error")
            self.battle_plan = None

    def set_plan(self, spec) -> BattlePlan | None:
        """加载战斗方案：路径字符串 / dict / BattlePlan 对象，None 表示清除。"""
        if spec in (None, ""):
            self.battle_plan = None
            logging_cfg = self.cfg.setdefault("battle", {})
            logging_cfg["plan"] = ""
            self.log("已清除战斗方案，回到旧技能轴")
            return None
        if isinstance(spec, BattlePlan):
            plan = spec
        elif isinstance(spec, dict):
            plan = BattlePlan.from_dict(spec)
        else:
            path = Path(str(spec))
            if not path.is_absolute():
                path = self.base_dir / path
            plan = BattlePlan.load(path)
        self.battle_plan = plan
        self.log(f"已加载战斗方案「{plan.name}」：{plan.describe()}")
        return plan

    # ------------------------------------------------------------ 画面自检

    def inspect_screen(self, frame: Frame | None = None):
        """截图并做一次完整自检（黑屏/分辨率/界面指纹/模板/缺失）。"""
        from .diagnose import inspect

        return inspect(self, frame)

    # ------------------------------------------------------------ 界面识别

    def learn_scene(self, name: str, frame: Frame | None = None) -> bool:
        """把当前画面学成指定界面（界面上的「学习当前界面」）。"""
        target = frame if frame is not None else self.last_frame
        if target is None:
            return False
        added = self.scenes.learn(name, fingerprint(target))
        if added:
            self.scenes.save(force=True)
            self.log(f"已学习界面「{name}」（样本 {self.scenes.count(name)}）")
        else:
            self.log(f"界面「{name}」已有几乎相同的样本，跳过", "debug")
        return added

    def scene_summary(self) -> list[tuple[str, int]]:
        return self.scenes.summary()

    def forget_scene(self, name: str) -> bool:
        removed = self.scenes.remove(name)
        if removed:
            self.scenes.save(force=True)
            self.log(f"已删除界面「{name}」")
        return removed

    # ------------------------------------------------------------ 模板体检

    def check_templates(self, frame: Frame | None = None) -> list[dict]:
        """对当前画面跑一遍所有模板，返回分数与判定，用于校准。

        color_rejected=True 表示灰度分数够但颜色不符——通常是抓到了同形状的另一个按钮。
        """
        frame = frame if frame is not None else self.grab()
        default_threshold = float(get_path(self.cfg, "vision.min_score", 0.86))
        rows: list[dict] = []
        for name in self.store.names():
            template = self.store.get(name)
            if template is None:
                continue
            match = self.matcher.match(frame, template)
            threshold = (
                template.threshold
                if template.threshold is not None
                else default_threshold
            )
            score_ok = match.score >= threshold
            color_ok = self.matcher.color_ok(frame, template, match) if score_ok else True
            rows.append(
                {
                    "name": name,
                    "score": round(float(match.score), 4),
                    "threshold": round(float(threshold), 3),
                    "ok": bool(score_ok and color_ok),
                    "color_rejected": bool(score_ok and not color_ok),
                    "width": template.width,
                    "height": template.height,
                }
            )
        rows.sort(key=lambda row: -row["score"])
        return rows

    # ------------------------------------------------------------ 基本信息

    @property
    def size(self) -> tuple[int, int]:
        return self.device.size

    def missing_templates(self) -> list[str]:
        return self.store.missing(collect_template_names(self.cfg))

    def reload_templates(self) -> None:
        self.store.reload()
        self.matcher.clear_cache()

    # ------------------------------------------------------------ 日志

    def log(self, message: str, level: str = "info") -> None:
        LOG.log(_LEVELS.get(str(level).lower(), logging.INFO), message)

    # ------------------------------------------------------------ 采集 / 识别

    def grab(self) -> Frame:
        frame = Frame(self.device.screenshot())
        note = str(getattr(self.device, "last_prefix", "") or "")
        if note and not getattr(self, "_shot_note_warned", False):
            self._shot_note_warned = True
            self.log(f"截图输出带前置提示（已自动忽略）：{note[:120]}", "warn")
        with self._lock:
            self.last_frame = frame
        return frame

    def find(self, frame: Frame, name: str, threshold: float | None = None) -> Match | None:
        tpl = self.store.get(name)
        if tpl is None:
            if name not in self._warned:
                self._warned.add(name)
                self.log(f"模板缺失: {name}（本轮首次，后续不再重复）", "debug")
            return None
        return self.matcher.find(frame, tpl, threshold)

    def explain_unknown(self, frame: Frame, top: int = 3) -> list[tuple[str, float]]:
        """对未知画面给出「最接近的模板 + 分数」，让日志能自解释。"""
        scores: list[tuple[str, float]] = []
        for name in self.store.names():
            tpl = self.store.get(name)
            if tpl is None:
                continue
            try:
                match = self.matcher.match(frame, tpl)
            except Exception:  # noqa: BLE001 - 诊断失败不影响主流程
                continue
            scores.append((name, float(match.score)))
        scores.sort(key=lambda item: item[1], reverse=True)
        return scores[:top]

    def detect(
        self, frame: Frame, use_scene: bool = True
    ) -> tuple[dict | None, dict[str, Match], bool]:
        """返回 (命中的流程, 匹配结果, 是否处于冷却)。

        use_scene=False 时跳过界面指纹，强制走模板（自检/诊断用）。
        """
        signature = _signature(frame.rgb)
        recently_acted = (time.time() - getattr(self, "_last_exec_ts", 0.0)) < 0.6
        if (
            not recently_acted
            and self._last_detection is not None
            and self._last_sig is not None
            and _sig_diff(signature, self._last_sig) < 1.5
        ):
            flow, matches = self._last_detection
            name = str(flow.get("name", ""))
            cooldown = float(
                flow.get("cooldown", get_path(self.cfg, "runtime.flow_cooldown", 0.25))
            )
            skip = (time.time() - self._last_flow_ts.get(name, -1e9)) < cooldown
            return flow, matches, skip

        # 1) 界面指纹：一次比对约 0.2ms，认出来就直接执行对应流程
        if use_scene and self.scenes.enabled and len(self.scenes):
            name, score, second = self.scenes.match_detailed(fingerprint(frame))
            self.last_scene = (name, score) if name else None
            if name and self.scenes.confident(score, second, self.scene_margin):
                flow = self._flow_index.get(name)
                if flow is not None:
                    cooldown = float(
                        flow.get("cooldown", get_path(self.cfg, "runtime.flow_cooldown", 0.25))
                    )
                    skip = (time.time() - self._last_flow_ts.get(name, -1e9)) < cooldown
                    self.last_via = "scene"
                    self._flow_hint = None
                    return flow, {}, skip

        # 2) 模板流程：按 优先级 → 特异性 → 上次命中 排序
        flows = enabled_flows(
            self.cfg.get("flows") or [],
            skip_story=bool(get_path(self.cfg, "runtime.skip_story", True)),
        )
        order = sorted(range(len(flows)), key=lambda i: flow_sort_key(flows, i, self._flow_hint))

        min_score = float(get_path(self.cfg, "vision.min_score", 0.86))
        for index in order:
            flow = flows[index]
            rule = flow.get("detect") or {}
            if not isinstance(rule, dict):
                continue
            any_list = [str(x) for x in (rule.get("any") or [])]
            all_list = [str(x) for x in (rule.get("all") or [])]
            none_list = [str(x) for x in (rule.get("none") or [])]
            if not any_list and not all_list:
                continue
            threshold = float(rule.get("min_score", min_score))
            matches: dict[str, Match] = {}

            def hit(name: str) -> bool:
                m = self.find(frame, name, threshold)
                if m is not None:
                    matches[name] = m
                return m is not None

            if all_list and not all(hit(n) for n in all_list):
                continue
            if any_list and not any(hit(n) for n in any_list):
                continue
            if none_list and any(hit(n) for n in none_list):
                continue

            name = str(flow.get("name", ""))
            cooldown = float(
                flow.get("cooldown", get_path(self.cfg, "runtime.flow_cooldown", 0.25))
            )
            skip = (time.time() - self._last_flow_ts.get(name, -1e9)) < cooldown
            self._flow_hint = index
            self._last_detection = (flow, matches)
            self._last_sig = signature
            self.last_via = "template"
            return flow, matches, skip
        self._flow_hint = None
        self._last_detection = None
        return None, {}, False

    # ------------------------------------------------------------ 单步

    def step(self) -> str | None:
        frame = self.grab()
        flow, matches, skip = self.detect(frame)
        with self._lock:
            self.last_flow = str(flow.get("name")) if flow else None
            self.last_matches = list(matches.values())

        if flow is None:
            self._recover(frame)
            return None

        self.stats["consecutive_unknown"] = 0
        name = str(flow.get("name", "?"))
        if skip:
            self.sleep(float(get_path(self.cfg, "runtime.poll_interval", 0.35)) * 0.5)
            return name

        self._last_flow_ts[name] = time.time()
        self._last_exec_ts = time.time()
        self.stats["steps"] += 1
        self.stats["flows"][name] = self.stats["flows"].get(name, 0) + 1
        self.log(f"▶ 流程「{name}」")

        ctx = Ctx(self, flow, frame, dict(matches))
        try:
            actions_mod.run_actions(ctx, flow.get("actions", []))
        except ActionError as exc:
            self.last_error = str(exc)
            self.save_debug(frame, "action_error")
            self.log(f"流程「{name}」执行失败: {exc}", "error")
            raise EngineHalt(str(exc)) from exc

        self._check_stuck(frame, flow, name)

        # 模板给到很高分，说明这一屏看得很准，顺手把它学进界面库
        if self.auto_learn and self.last_via == "template":
            best = max((m.score for m in matches.values()), default=0.0)
            if best >= 0.95:
                try:
                    if self.scenes.learn(name, fingerprint(frame)):
                        self.scenes.save()
                except Exception:  # noqa: BLE001 - 学习失败不影响主流程
                    pass
        return name

    def _dump_unknown(self, key: str, frame: Frame, entry: dict) -> None:
        """把未知界面记到 logs/unknown.jsonl，方便事后补模板。"""
        try:
            path = Path(self.log_dir) / "unknown.jsonl"
            path.parent.mkdir(parents=True, exist_ok=True)
            record = {
                "ts": round(entry["first"], 3),
                "key": key,
                "size": list(frame.rgb.shape[1::-1]),
                "top": entry["top"],
            }
            with path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:  # noqa: BLE001 - 记录失败不影响主流程
            pass

    def _check_stuck(self, frame: Frame, flow: dict, name: str) -> None:
        """卡住检测：同一流程连续执行、且画面几乎没变 → 换备用动作，再不行就停。

        实测「跳过确认」没弹出来时，旧逻辑会一直点同一个按钮（8 次空转），
        这里把这种「点了没反应」的情况显式识别出来。
        """
        signature = _signature(frame.rgb)
        prev_sig = getattr(self, "_stuck_sig", None)
        same = (
            name == getattr(self, "_stuck_name", None)
            and prev_sig is not None
            and _sig_diff(signature, prev_sig) < 0.6
        )
        self._stuck_count = (getattr(self, "_stuck_count", 0) + 1) if same else 0
        self._stuck_name = name
        self._stuck_sig = signature

        limit = int(flow.get("max_repeat", get_path(self.cfg, "runtime.max_repeat", 8)) or 8)
        if limit <= 0 or self._stuck_count < limit:
            return
        alt = flow.get("alt_actions") or []
        if alt and self._stuck_count < limit * 2:
            self.log(f"「{name}」连续 {self._stuck_count} 次没有推进，改用备用动作", "warn")
            ctx = Ctx(self, flow, frame, {})
            try:
                actions_mod.run_actions(ctx, alt)
            except (ActionError, DeviceError) as exc:
                self.log(f"备用动作失败: {exc}", "warn")
            self._stuck_count = 0
            return
        raise EngineHalt(
            f"「{name}」连续 {self._stuck_count} 次执行后画面没有变化，已停止。"
            "通常是模板抓错/按钮位置不对，或界面弹了别的窗口。"
        )

    def _recover(self, frame: Frame) -> None:
        self.stats["unknown"] += 1
        self.stats["consecutive_unknown"] += 1
        n = int(self.stats["consecutive_unknown"])
        signature = _signature(frame.rgb)
        if screen_is_dynamic(getattr(self, "_last_unknown_sig", None), signature):
            # 战斗/过场动画：继续等待，不累计「未知」次数，也不乱点
            self.stats["consecutive_unknown"] = 0
            self._last_unknown_sig = signature
            self.log("画面在动（战斗/过场），继续等待", "debug")
            self.sleep(float(get_path(self.cfg, "runtime.unknown_wait", 1.2)))
            return
        self._last_unknown_sig = signature
        key = unknown_screen_key(frame.rgb)
        entry = self._unknown_screens.get(key)
        if entry is None:
            top = self.explain_unknown(frame)
            entry = {
                "count": 0,
                "top": [[name, round(score, 3)] for name, score in top],
                "first": time.time(),
            }
            self._unknown_screens[key] = entry
            hint = "，".join(f"{name}={score:.2f}" for name, score in top) or "没有模板可对比"
            self.log(f"? 未识别画面（新界面）最接近：{hint}", "warn")
            self._dump_unknown(key, frame, entry)
        else:
            self.log(f"? 未识别画面（同一屏第 {entry['count'] + 1} 次，连续 {n} 次）", "debug")
        entry["count"] = int(entry["count"]) + 1
        if bool(get_path(self.cfg, "runtime.save_debug_frames", True)) and n <= 3:
            self.save_debug(frame, f"unknown_{n}")

        # 过场/加载画面（几乎纯色）不要乱点，等它自己过去
        try:
            small = np.asarray(frame.rgb[::8, ::8], dtype=np.float32)
            blank = float(small.mean(axis=2).std()) < 8.0
        except Exception:  # noqa: BLE001
            blank = False
        if blank:
            self.log("画面接近纯色（过场/加载），等待…", "debug")
            self.sleep(float(get_path(self.cfg, "runtime.unknown_wait", 1.2)))
            max_unknown = int(get_path(self.cfg, "runtime.max_unknown", 10))
            if n >= max_unknown:
                raise EngineHalt(
                    f"连续 {n} 次停在过场/加载画面，已停止。可能是网络卡住或剧情没有推进。"
                )
            return

        unknown_sig = _signature(frame.rgb)
        prev = getattr(self, "_unknown_sig", None)
        if unknown_stuck(prev, unknown_sig, n):
            self.save_debug(frame, "unknown_stuck")
            top = self._unknown_screens.get(unknown_screen_key(frame.rgb), {}).get("top") or []
            hint = "，".join(f"{name}={score:.2f}" for name, score in top) or "无"
            raise EngineHalt(
                f"连续 {n} 次停在同一个未知界面，画面没有变化。"
                f"最接近的模板：{hint}。"
                "请在界面里用「抓取模板模式」补一张（可先用「检测画面」看它属于哪个流程）。"
            )
        self._unknown_sig = unknown_sig

        recovery = self.cfg.get("recovery") or {}
        ctx = Ctx(self, {"name": "recovery"}, frame, {})
        try:
            actions_mod.run_actions(ctx, recovery.get("actions", []))
        except ActionError as exc:
            self.log(f"恢复动作失败: {exc}", "warn")
        except DeviceError as exc:
            self.log(f"恢复动作导致设备错误: {exc}", "error")

        back_after = int(recovery.get("back_after", 0) or 0)
        if recovery.get("allow_back") and back_after and n % back_after == 0:
            try:
                self.device.key(4)
                self.log("按返回键尝试退出当前界面", "warn")
            except DeviceError:
                pass

        max_unknown = int(get_path(self.cfg, "runtime.max_unknown", 10))
        if n >= max_unknown:
            raise EngineHalt(
                f"连续 {n} 次无法识别画面，已停止以免乱点。"
                "请检查模板是否抓取正确（界面里的「诊断」可以看当前识别分数）。"
            )
        self.sleep(float(get_path(self.cfg, "runtime.unknown_wait", 1.2)))

    # ------------------------------------------------------------ 运行控制

    def run_forever(self) -> None:
        runtime = self.cfg.get("runtime") or {}
        poll = float(runtime.get("poll_interval", 0.35))
        max_minutes = float(runtime.get("max_minutes", 0) or 0)
        max_steps = int(runtime.get("max_steps", 0) or 0)
        missing = self.store.missing(collect_template_names(self.cfg))
        if missing:
            self.log(
                f"缺 {len(missing)} 张模板：{', '.join(missing)}；"
                "缺的流程会走兜底坐标或跳过（详见「缺失模板清单」）",
                "warn",
            )
        self.stats["started_at"] = time.time()
        self.running = True
        self._stop.clear()
        self.report = Report(
            self.log_dir, enabled=bool(get_path(self.cfg, "runtime.report", True))
        )
        loop_mode = str(get_path(self.cfg, "loop.mode", "story"))
        self.report.event(
            "start",
            device=self.device.name,
            size=f"{self.size[0]}x{self.size[1]}",
            mode=loop_mode,
            plan=self.battle_plan.name if self.battle_plan is not None else None,
        )
        size_note = str(getattr(self.device, "size_note", "") or "")
        self.log(
            f"开始运行：设备 {self.device.name} {self.size[0]}x{self.size[1]}"
            + (f"（{size_note}）" if size_note else "")
            + f" / 模式 {loop_mode}"
            f"{' / 方案 ' + self.battle_plan.name if self.battle_plan is not None else ''}"
            f"{'（干跑，不点击）' if self.dry_run else ''}"
        )
        try:
            while not self._stop.is_set():
                elapsed = time.time() - float(self.stats["started_at"])
                self.stats["elapsed"] = elapsed
                if max_minutes and elapsed >= max_minutes * 60:
                    self.log(f"达到运行时长上限 {max_minutes} 分钟，正常结束")
                    break
                if max_steps and self.stats["steps"] >= max_steps:
                    self.log(f"达到步数上限 {max_steps}，正常结束")
                    break
                limit = int(get_path(self.cfg, "loop.max_story_clears", 0) or 0)
                if story_limit_reached(int(self.stats.get("story_clears", 0)), limit):
                    self.log(f"已推进 {limit} 关，达到设定上限，正常结束")
                    break
                self.step()
                self._stop.wait(poll)
        except EngineHalt as exc:
            self.last_error = str(exc)
            self.log(f"已停止: {exc}", "error")
        except DeviceError as exc:
            self.last_error = f"设备错误: {exc}"
            self.log(f"设备错误，已停止: {exc}", "error")
        except Exception as exc:  # pragma: no cover - 兜底
            self.last_error = f"未预期错误: {exc}"
            LOG.exception("未预期错误")
        finally:
            self.running = False
            self.stats["elapsed"] = time.time() - float(self.stats["started_at"])
            self.report.write_summary(
                {
                    "steps": self.stats["steps"],
                    "taps": self.stats["taps"],
                    "unknown": self.stats["unknown"],
                    "cards_picked": self.stats.get("cards_picked", 0),
                    "error": self.last_error,
                }
            )
            self.log(self.report.summary_line())
            self.log("运行结束")

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self.last_error = None
        self._thread = threading.Thread(target=self.run_forever, name="fgo-engine", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def join(self, timeout: float | None = None) -> None:
        if self._thread:
            self._thread.join(timeout)

    @property
    def is_running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    # ------------------------------------------------------------ 设备操作

    def tap(self, x: int, y: int, jitter: bool | None = None) -> None:
        runtime = self.cfg.get("runtime") or {}
        humanize = bool(runtime.get("humanize", True))
        amount = int(runtime.get("tap_jitter", 3) or 0)
        if jitter is False or not humanize:
            amount = 0
        if amount:
            x += random.randint(-amount, amount)
            y += random.randint(-amount, amount)
        x = max(0, min(int(x), self.size[0] - 1))
        y = max(0, min(int(y), self.size[1] - 1))
        if self.dry_run:
            self.log(f"[干跑] 点击 ({x}, {y})", "debug")
            return
        self.device.tap(x, y)
        self.stats["taps"] += 1
        if humanize:
            low, high = (runtime.get("click_delay") or [0.05, 0.14])[:2]
            self.sleep(random.uniform(float(low), float(high)))

    def sleep(self, seconds: float) -> None:
        if seconds > 0:
            self._stop.wait(seconds)

    # ------------------------------------------------------------ 调试

    def save_debug(self, frame: Frame, tag: str) -> Path | None:
        if not bool(get_path(self.cfg, "runtime.save_debug_frames", True)):
            return None
        try:
            from PIL import Image

            self.log_dir.mkdir(parents=True, exist_ok=True)
            safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in str(tag))
            path = self.log_dir / f"{time.strftime('%Y%m%d_%H%M%S')}_{safe}.png"
            Image.fromarray(frame.rgb, mode="RGB").save(path)
            self._prune_debug()
            return path
        except Exception as exc:  # pragma: no cover
            self.log(f"保存调试截图失败: {exc}", "warn")
            return None

    def _prune_debug(self, keep: int = 300) -> None:
        try:
            files = sorted(self.log_dir.glob("*.png"), key=lambda p: p.stat().st_mtime)
            for path in files[:-keep]:
                path.unlink(missing_ok=True)
        except OSError:
            pass

    def snapshot(self) -> dict[str, Any]:
        """给 GUI 用的线程安全快照。"""
        with self._lock:
            frame = self.last_frame
            return {
                "frame": None if frame is None else frame.rgb.copy(),
                "flow": self.last_flow,
                "matches": [m.as_dict() for m in self.last_matches],
                "stats": {
                    "steps": self.stats["steps"],
                    "taps": self.stats["taps"],
                    "unknown": self.stats["unknown"],
                    "elapsed": self.stats["elapsed"],
                    "cards_picked": self.stats.get("cards_picked", 0),
                    "card_colors": self.stats.get("card_colors", 0),
                    "flows": dict(self.stats["flows"]),
                },
                "running": self.is_running,
                "error": self.last_error,
                "device": self.device.name,
                "size": self.size,
                "templates": len(self.store),
                "missing": self.missing_templates(),
                "report": self.report.summary(),
                "plan": self.battle_plan.name if self.battle_plan is not None else None,
                "scene": self.last_scene[0] if self.last_scene else None,
                "scene_score": round(self.last_scene[1], 3) if self.last_scene else 0.0,
                "via": self.last_via,
                "scene_count": len(self.scenes),
            }
