"""FGO 主线自动推进工具。

模块划分::

    config    配置（默认值 + config.json 覆盖）
    device    设备抽象（ADB 真机/模拟器，mock 演示后端）
    vision    模板匹配（numpy FFT 版 NCC，无需 OpenCV）
    templates 模板仓库与元数据
    actions   动作解释器（配置里的 actions 列表）
    battle    战斗策略（技能、宝具、选卡）
    engine    主循环：截屏 -> 识别 -> 执行 -> 异常恢复
    gui       Tkinter 图形界面
    fakegame  内置模拟游戏（用于无游戏环境下验证）

设计原则：所有游戏 UI 元素都用模板识别，坐标只作为模板缺失时的兜底，
因此换分辨率 / 换服 / 换语言不需要改代码，重新抓一次模板即可。
"""

__version__ = "0.8.0"
__all__ = ["__version__"]
