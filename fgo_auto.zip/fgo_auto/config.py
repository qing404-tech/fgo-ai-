"""配置：内置默认值 + config.json 覆盖。

所有可调参数都在这里给出默认值，用户配置只需要写想改的键（深合并）。
坐标统一使用 0~1 的归一化值，因此与原分辨率无关。
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------- 默认配置

DEFAULT_CONFIG: dict[str, Any] = {
    "version": 1,
    "device": {
        # backend: "adb" 真机/模拟器 | "mock" 内置模拟游戏（无游戏也能跑通全流程）
        "backend": "adb",
        "adb_path": "",       # 留空则自动在 PATH / 常见模拟器目录里找
        "serial": "",         # 留空则自动选第一个在线设备
        "connect": "",        # 例如 "127.0.0.1:16384"（MuMu 12 默认端口）
        "auto_display": True, # 多显示器时自动抓「游戏所在屏」（MuMu 必需）
        "display_id": "",     # 手动指定显示器 uid（留空 = 自动）
        "auto_detect": True,  # 没填 adb/序列号时自动探测模拟器
        "detect_timeout": 20, # 自动探测的时间上限（秒）
        "auto_launch": False, # 检测到模拟器没启动时，是否自动拉起
        "launch_wait": 120,   # 启动后等待设备就绪的秒数
        "emulator_index": 0,  # 多开时用第几个实例
        "expected_size": [1280, 720],
    },
    "runtime": {
        "poll_interval": 0.35,     # 每轮截图间隔（秒）
        "flow_cooldown": 0.25,     # 同一流程连续触发的冷却，防止连点
        "dry_run": False,          # True = 只识别不点击
        "humanize": True,          # 点击抖动 + 随机延迟
        "tap_jitter": 3,           # 点击随机偏移（像素）
        "click_delay": [0.05, 0.14],
        "max_unknown": 10,         # 连续无法识别的次数上限，超过即停止并报警
        "unknown_wait": 1.2,
        "max_minutes": 0,          # 0 = 不限制运行时长
        "max_steps": 0,            # 0 = 不限制步数
        "save_debug_frames": True,
        "report": True,          # 写 logs/report.jsonl 与 summary.json
        "log_dir": "logs",
    },
    "vision": {
        "min_score": 0.86,     # 模板匹配阈值
        "work_scale": 0.35,    # 先降采样粗匹配，再原图精修
        "scales": [1.0],       # 多尺度搜索（分辨率与模板不一致时可用）
        # 灰度匹配后再比平均颜色，避免同形状不同颜色的按钮互相误判。
        # 0 = 关闭。游戏画面偏色/滤镜较重时可调大到 80 左右。
        "color_tolerance": 60,
    },
    "templates": {
        "dir": "templates",
        "meta": "templates.json",   # 可选的每模板阈值/搜索区域
    },
    # 界面自动识别：用画面指纹认「现在是哪一屏」，可自学习
    "scene": {
        "enabled": True,
        "threshold": 0.88,   # 相似度阈值（0.86~0.92 之间比较合适）
        "margin": 0.05,      # 还要比第二名像这么多，才敢认
        "auto_learn": True,  # 模板高置信命中时自动把该界面学进 scenes.json
    },
    # 循环模式：story = 推主线（每次打下一个新关卡）；farm = 固定关卡刷本
    "loop": {
        "mode": "story",
        "farm_node_tpl": "",     # farm 模式下要点的关卡（模板名，优先）
        "farm_node_point": "",   # 没有模板时用的坐标（params 路径或 [x, y]）
    },
    # AP 管理：AP 不足时按顺序尝试吃苹果
    "ap": {
        "apple_order": ["gold", "silver", "bronze", "quartz"],
        "apple_points": {},      # 例 {"gold": [0.50, 0.42]}
        "apple_ap": {"gold": 0, "silver": 0, "bronze": 0, "quartz": 0},
        "max_per_run": 0,        # 本次运行最多吃几个，0 = 不限
        "keep_min": 0,           # 保留 AP 下限，低于该值才吃苹果
    },
    "battle": {
        "attack_tpl": "t_attack",
        "cards_tpl": "t_cards",
        "np_tpl": "t_np",
        "use_np": False,
        # 战斗方案 JSON（bbchannel 风格）；留空则用下面的 skill_plan 旧逻辑
        "plan": "",
        # 技能/宝具按钮坐标：模板 t_skill_<从者>_<技能> / t_np_<从者> 优先，
        # 找不到才用这里的坐标（归一化，需要按自己的分辨率校准一次）
        "skill_grid": {"x": [0.19, 0.30, 0.41], "y": [0.62, 0.72, 0.82]},
        "np_grid": {"x": [0.19, 0.30, 0.41], "y": 0.90},
        # auto = 先按卡片颜色判断，判断不出来就按从左到右
        "card_mode": "auto",
        "card_slots": [[0.20, 0.80], [0.39, 0.80], [0.58, 0.80]],
        "card_box": [0.105, 0.24],              # 单张卡片的宽高（占屏幕比例）
        "sample": [0.08, 0.04, 0.92, 0.40],     # 卡片内取样区（相对卡片框）
        # Hue 采用 0~360 度（不是 OpenCV 的 0~180），范围 [Hmin,Smin,Vmin,Hmax,Smax,Vmax]
        "hsv": {
            "buster": [[0, 120, 90, 15, 255, 255], [340, 120, 90, 360, 255, 255]],
            "arts": [[195, 90, 80, 260, 255, 255]],
            "quick": [[95, 90, 70, 175, 255, 255]],
        },
        "priority": ["buster", "arts", "quick"],
        "min_classify": 0.35,     # 取样区里同色像素占比达到该值才认定颜色
        "pick_delay": [0.25, 0.45],
        "wait_after_attack": 0.7,   # 点攻击后等动画
        "wait_cards_timeout": 3.0,  # 等选卡界面出现的超时
        "wait_after_pick": 0.8,     # 选完三张卡后等出手
        # 技能轴：回合号 -> 要点的坐标列表（归一化）。例如 {"1": [[0.35,0.55]]}
        "skill_plan": {},
        "np_point": [0.55, 0.55],
    },
    # 模板缺失时的兜底坐标（按 1280x720 的 CN 服布局估的，首次使用请校准）
    "params": {
        "popup_ok": [0.50, 0.86],
        "dialog_tap": [0.50, 0.55],
        "continue_decline": [0.35, 0.62],
        "support_start": [0.86, 0.92],
        "party_start": [0.86, 0.92],
        "nav": {
            "terminal": [0.50, 0.93],
            "main_record": [0.50, 0.32],
            "chapter": [[0.50, 0.50]],
            "node": [0.50, 0.62],
        },
    },
    "recovery": {
        # 出现未知画面时依次尝试的动作（点屏幕中间推进剧情 / 关闭弹窗）
        "actions": [
            {"tap_xy": [0.5, 0.55]},
            {"wait": 0.8},
            {"tap_xy": [0.06, 0.06]},
            {"wait": 0.8},
        ],
        "back_after": 4,   # 尝试 N 轮后按一次返回键
    },
    "flows": [
        # ---------------- 异常 / 弹窗（优先级最高） ----------------
        {
            "name": "连接重试",
            "cooldown": 3.0,
            "detect": {"any": ["t_conn_retry"]},
            "actions": [{"tap": "t_conn_retry"}, {"wait": 2.0}],
        },
        {
            "name": "升级弹窗",
            "cooldown": 1.0,
            "detect": {"any": ["t_levelup"]},
            "actions": [
                {"tap": "t_levelup", "fallback": "popup_ok"},
                {"wait": 0.8},
            ],
        },
        {
            "name": "通用确认弹窗",
            "cooldown": 1.0,
            "detect": {"any": ["t_confirm_ok"]},
            "actions": [{"tap": "t_confirm_ok", "fallback": "popup_ok"}, {"wait": 0.7}],
        },
        {
            "name": "AP不足",
            "cooldown": 2.0,
            "detect": {"any": ["t_ap_restore"]},
            "actions": [{"call": "use_apple"}, {"wait": 1.2}],
        },
        # ---------------- 剧情 ----------------
        {
            "name": "剧情跳过确认",
            "cooldown": 1.0,
            "detect": {"any": ["t_skip_confirm"]},
            "actions": [{"tap": "t_skip_confirm"}, {"wait": 0.7}],
        },
        {
            "name": "剧情跳过",
            "cooldown": 1.0,
            "detect": {"any": ["t_skip"]},
            "actions": [{"tap": "t_skip"}, {"wait": 0.7}],
        },
        {
            "name": "剧情对话",
            "detect": {"any": ["t_dialog"]},
            "actions": [
                {
                    "tap_until_gone": {
                        "tpl": "t_dialog",
                        "point": "dialog_tap",
                        "interval": 0.45,
                        "max": 400,
                        "until_any": [
                            "t_stage_select",
                            "t_result_continue",
                            "t_attack",
                            "t_party_start",
                        ],
                    }
                }
            ],
        },
        # ---------------- 战斗 ----------------
        {
            "name": "战斗回合",
            "detect": {"any": ["t_attack"]},
            "actions": [{"call": "battle_attack"}],
        },
        {
            "name": "选卡界面",
            "detect": {"any": ["t_cards"]},
            "actions": [{"call": "pick_cards"}],
        },
        {
            "name": "战斗开始",
            "cooldown": 1.5,
            "detect": {"any": ["t_battle_start"]},
            "actions": [{"tap": "t_battle_start"}, {"wait": 1.5}],
        },
        {
            "name": "支援选择",
            "cooldown": 1.5,
            "detect": {"any": ["t_support_start"]},
            "actions": [
                {"tap": "t_support_start", "fallback": "support_start"},
                {"wait": 1.5},
            ],
        },
        {
            "name": "队伍确认",
            "cooldown": 1.5,
            "detect": {"any": ["t_party_start"]},
            "actions": [
                {"tap": "t_party_start", "fallback": "party_start"},
                {"wait": 1.5},
            ],
        },
        {
            "name": "战利品结算",
            "cooldown": 1.0,
            "detect": {"any": ["t_result_continue"]},
            "actions": [
                {"tap": "t_result_continue"},
                {"wait": 1.2},
                {"call": "record_result"},
            ],
        },
        # ---------------- 导航 ----------------
        {
            "name": "关卡列表",
            "cooldown": 0.8,
            "detect": {"any": ["t_stage_select"]},
            "actions": [
                {"call": "pick_node"},
                {"wait": 1.2},
            ],
        },
        {
            "name": "主界面",
            "cooldown": 0.8,
            "detect": {"any": ["t_home"]},
            "actions": [
                {"tap": "t_terminal", "fallback": "nav.terminal"},
                {"wait": 1.2},
            ],
        },
    ],
}


# ---------------------------------------------------------------- 读写

def default_config() -> dict[str, Any]:
    return copy.deepcopy(DEFAULT_CONFIG)


def deep_merge(base: dict, override: dict) -> dict:
    """把 override 深合并进 base 的副本。列表整体替换。"""
    out = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    cfg = default_config()
    if path:
        p = Path(path)
        if p.is_file():
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
            except json.JSONDecodeError as exc:
                raise ValueError(f"配置文件不是合法 JSON: {p} ({exc})") from exc
            if not isinstance(data, dict):
                raise ValueError(f"配置文件顶层必须是对象: {p}")
            cfg = deep_merge(cfg, data)
            # 相对路径统一锚定到配置文件所在目录，避免 GUI 与命令行在不同 cwd 下
            # 把日志/模板写到两个地方（曾经导致「日志里看不到刚跑的那次」）。
            base = p.resolve().parent
            for key in ("log_dir",):
                value = (cfg.get("runtime") or {}).get(key)
                if value and not Path(value).is_absolute():
                    cfg["runtime"][key] = str((base / value).resolve())
            tdir = (cfg.get("templates") or {}).get("dir")
            if tdir and not Path(tdir).is_absolute():
                cfg["templates"]["dir"] = str((base / tdir).resolve())
    return cfg


def save_config(cfg: dict[str, Any], path: str | Path) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return p


def ensure_config_file(path: str | Path) -> Path:
    p = Path(path)
    if not p.exists():
        save_config(default_config(), p)
    return p


# ---------------------------------------------------------------- 取值工具

def get_path(cfg: dict[str, Any], dotted: str, default: Any = None) -> Any:
    """按 "a.b.c" 取值，取不到返回 default。"""
    cur: Any = cfg
    for part in str(dotted).split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return default
    return cur


def template_dir(cfg: dict[str, Any], base: Path | None = None) -> Path:
    """模板目录；mock 后端使用独立子目录，避免污染真机模板。"""
    root = Path(base) if base else Path.cwd()
    d = root / str(get_path(cfg, "templates.dir", "templates"))
    if get_path(cfg, "device.backend", "adb") == "mock":
        d = d / "mock"
    return d


def resolve_cli_path(value: str, base: Path) -> Path:
    p = Path(value)
    return p if p.is_absolute() else (base / p)
