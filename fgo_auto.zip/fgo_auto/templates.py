"""模板仓库：加载 templates/*.png、保存新模板、统计缺失模板。"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

import numpy as np

from .vision import Template, to_gray


class TemplateStore:
    """templates 目录下的 PNG，文件名即模板名。

    可选同目录 templates.json 为单个模板配置阈值 / 搜索区域 / 多尺度::

        {"t_attack": {"threshold": 0.9, "region": [0.5, 0.5, 0.5, 0.5],
                      "scales": [1.0, 1.05]}}
    """

    def __init__(
        self,
        directory: str | Path,
        meta_name: str = "templates.json",
        default_scales: Iterable[float] = (1.0,),
    ):
        self.dir = Path(directory)
        self.meta_name = meta_name
        self.default_scales = tuple(default_scales) or (1.0,)
        self.templates: dict[str, Template] = {}
        self.errors: list[str] = []
        self.warnings: list[str] = []

    # -- 加载 -----------------------------------------------------

    def reload(self) -> "TemplateStore":
        self.templates.clear()
        self.errors.clear()
        self.warnings.clear()
        meta: dict[str, Any] = {}
        meta_path = self.dir / self.meta_name
        if meta_path.is_file():
            try:
                data = json.loads(meta_path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    meta = data
            except (json.JSONDecodeError, OSError) as exc:
                self.errors.append(f"{meta_path.name}: {exc}")

        if not self.dir.is_dir():
            return self

        from PIL import Image

        for path in sorted(self.dir.glob("*.png")):
            name = path.stem
            try:
                with Image.open(path) as im:
                    rgb = np.asarray(im.convert("RGB"), dtype=np.uint8)
            except OSError as exc:
                self.errors.append(f"{path.name}: 无法读取 ({exc})")
                continue
            if rgb.size == 0:
                continue
            gray = to_gray(rgb)
            h, w = gray.shape
            if max(w, h) > 700:
                self.warnings.append(
                    f"{name}: 模板过大（{w}x{h}），识别慢且容易误判；建议改抓局部元素"
                )
            if float(gray.std()) < 3.0:
                self.warnings.append(f"{name}: 模板几乎是纯色，无法可靠匹配")
            info = meta.get(name, {}) if isinstance(meta.get(name), dict) else {}
            region = info.get("region")
            if isinstance(region, (list, tuple)) and len(region) == 4:
                region = tuple(float(v) for v in region)  # type: ignore[assignment]
            else:
                region = None
            scales = info.get("scales")
            if not isinstance(scales, (list, tuple)) or not scales:
                scales = self.default_scales
            threshold = info.get("threshold")
            color_tolerance = info.get("color_tolerance")
            self.templates[name] = Template(
                name=name,
                gray=gray,
                rgb=rgb,
                path=str(path),
                threshold=float(threshold) if threshold is not None else None,
                region=region,  # type: ignore[arg-type]
                scales=tuple(float(s) for s in scales),
                color_tolerance=(
                    float(color_tolerance) if color_tolerance is not None else None
                ),
            )
        return self

    # -- 查询 -----------------------------------------------------

    def get(self, name: str) -> Template | None:
        return self.templates.get(name)

    def names(self) -> list[str]:
        return sorted(self.templates)

    def missing(self, names: Iterable[str]) -> list[str]:
        return [n for n in names if n not in self.templates]

    def __len__(self) -> int:
        return len(self.templates)

    def __contains__(self, name: object) -> bool:
        return name in self.templates

    # -- 写入 -----------------------------------------------------

    def add(self, name: str, rgb: np.ndarray) -> Path:
        """把一块 RGB 区域存成模板 PNG。"""
        from PIL import Image

        safe = _safe_name(name)
        if not safe:
            raise ValueError("模板名不能为空")
        self.dir.mkdir(parents=True, exist_ok=True)
        path = self.dir / f"{safe}.png"
        Image.fromarray(np.asarray(rgb, dtype=np.uint8), mode="RGB").save(path)
        self.reload()
        return path

    def remove(self, name: str) -> bool:
        tpl = self.templates.get(name)
        if not tpl or not tpl.path:
            return False
        try:
            Path(tpl.path).unlink()
        except OSError:
            return False
        self.reload()
        return True


def _safe_name(name: str) -> str:
    bad = '<>:"/\\|?*\n\r\t'
    out = "".join("_" if c in bad else c for c in str(name)).strip(" .")
    return out[:80]


# ---------------------------------------------------------------- 依赖分析

def collect_template_names(cfg: dict) -> list[str]:
    """扫描配置里引用到的所有模板名（用于启动前检查清单）。"""
    found: set[str] = set()

    def walk(actions: Any) -> None:
        if isinstance(actions, list):
            for a in actions:
                walk(a)
            return
        if not isinstance(actions, dict):
            return
        for key in ("tpl",):
            if isinstance(actions.get(key), str):
                found.add(actions[key])
        tap = actions.get("tap")
        if isinstance(tap, str):
            found.add(tap)
        elif isinstance(tap, dict) and isinstance(tap.get("tpl"), str):
            found.add(tap["tpl"])
        for key in ("wait_tpl", "tap_until_gone", "tap_points_until"):
            spec = actions.get(key)
            if isinstance(spec, dict):
                if isinstance(spec.get("tpl"), str):
                    found.add(spec["tpl"])
                for n in spec.get("until_any", []) or []:
                    if isinstance(n, str):
                        found.add(n)
        if isinstance(actions.get("until_any"), list):
            for n in actions["until_any"]:
                if isinstance(n, str):
                    found.add(n)
        cond = actions.get("if")
        if isinstance(cond, dict):
            if isinstance(cond.get("tpl"), str):
                found.add(cond["tpl"])
            walk(cond.get("then", []))
            walk(cond.get("else", []))
        rep = actions.get("repeat")
        if isinstance(rep, dict):
            walk(rep.get("actions", []))

    for flow in cfg.get("flows", []) or []:
        detect = flow.get("detect", {}) if isinstance(flow, dict) else {}
        for key in ("any", "all", "none"):
            for n in detect.get(key, []) or []:
                if isinstance(n, str):
                    found.add(n)
        walk(flow.get("actions", []))
    walk(cfg.get("recovery", {}).get("actions", []))

    battle = cfg.get("battle", {}) or {}
    for key in ("attack_tpl", "cards_tpl"):
        if isinstance(battle.get(key), str):
            found.add(battle[key])
    if battle.get("use_np") and isinstance(battle.get("np_tpl"), str):
        found.add(battle["np_tpl"])
    return sorted(found)


def template_usage(cfg: dict) -> dict[str, list[str]]:
    """模板名 -> 用到它的流程名列表（用于「缺哪些模板」提示）。"""
    usage: dict[str, list[str]] = {}

    def add(name: Any, where: str) -> None:
        if isinstance(name, str) and name:
            usage.setdefault(name, [])
            if where not in usage[name]:
                usage[name].append(where)

    def walk(actions: Any, where: str) -> None:
        if isinstance(actions, list):
            for a in actions:
                walk(a, where)
            return
        if not isinstance(actions, dict):
            return
        add(actions.get("tpl"), where)
        tap = actions.get("tap")
        if isinstance(tap, str):
            add(tap, where)
        elif isinstance(tap, dict):
            add(tap.get("tpl"), where)
        for key in ("wait_tpl", "tap_until_gone", "tap_points_until"):
            spec = actions.get(key)
            if isinstance(spec, dict):
                add(spec.get("tpl"), where)
                for n in spec.get("until_any", []) or []:
                    add(n, where)
        for n in actions.get("until_any", []) or []:
            add(n, where)
        cond = actions.get("if")
        if isinstance(cond, dict):
            add(cond.get("tpl"), where)
            walk(cond.get("then", []), where)
            walk(cond.get("else", []), where)
        rep = actions.get("repeat")
        if isinstance(rep, dict):
            walk(rep.get("actions", []), where)

    for flow in cfg.get("flows", []) or []:
        if not isinstance(flow, dict):
            continue
        where = str(flow.get("name", "?"))
        detect = flow.get("detect") or {}
        for key in ("any", "all", "none"):
            for n in detect.get(key, []) or []:
                add(n, where)
        walk(flow.get("actions", []), where)
    for name in collect_template_names(cfg):
        usage.setdefault(name, [])
    battle = cfg.get("battle", {}) or {}
    keys = ["attack_tpl", "cards_tpl"]
    if battle.get("use_np"):
        keys.append("np_tpl")
    for key in keys:
        if isinstance(battle.get(key), str):
            usage.setdefault(battle[key], [])
            if "战斗" not in usage[battle[key]]:
                usage[battle[key]].append("战斗")
    return usage
