"""界面自动识别（场景指纹）。

思路：不依赖用户手抓模板，直接把整帧画面压缩成一个紧凑指纹——

  * 32x18 的归一化灰度缩略图（看布局）；
  * 24 段色相直方图（看配色）；
  * 16x9 的边缘密度图（看结构线）；
  * 3x3 区块的平均 RGB（看分区配色）；
  * 宽高比（横竖屏/分辨率变化）。

识别时用加权相似度做最近邻，返回「像哪个界面、像多少」。跑图过程中如果某个界面
以很高的模板分数被识别出来，会自动把它学进 `scenes.json`——用得越久认界面越准，
而且比逐个模板匹配快得多（一次比对约 0.2ms，不用做任何 FFT）。

指纹只描述「长什么样」，**不包含点击目标**；具体点哪里仍然由 flows 里的模板/坐标决定。
两者互补：指纹负责快速判断「现在是哪一屏」，模板负责「这一屏该点哪」。
"""

from __future__ import annotations

import base64
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np

from .vision import Frame, resize_gray

THUMB_W, THUMB_H = 32, 18
EDGE_W, EDGE_H = 16, 9
HIST_BINS = 24
GRID = 3
MAX_PER_SCENE = 6


# ---------------------------------------------------------------- 编码工具

def _b64_uint8(array: np.ndarray) -> str:
    return base64.b64encode(np.ascontiguousarray(array, dtype=np.uint8).tobytes()).decode("ascii")


def _from_b64(text: str, shape: tuple[int, ...]) -> np.ndarray:
    raw = base64.b64decode(text.encode("ascii"))
    return np.frombuffer(raw, dtype=np.uint8).reshape(shape)


def _norm(array: np.ndarray) -> np.ndarray:
    a = np.asarray(array, dtype=np.float32)
    mean = float(a.mean())
    std = float(a.std()) or 1.0
    return (a - mean) / std


def _downsample(array: np.ndarray, width: int, height: int) -> np.ndarray:
    return resize_gray(np.asarray(array, dtype=np.float32), width, height)


# ---------------------------------------------------------------- 指纹

def fingerprint(frame: Frame) -> dict[str, Any]:
    """把一帧画面压成可序列化的指纹。"""
    width, height = frame.size

    # 1) 灰度缩略图（归一化，抵消亮度/对比度差异）
    thumb = _norm(_downsample(frame.gray(), THUMB_W, THUMB_H))
    thumb_q = np.clip(thumb * 32.0 + 128.0, 0, 255).astype(np.uint8)

    # 2) 边缘密度（从缩略图算梯度，再降采样）
    gx = np.abs(np.diff(thumb, axis=1, prepend=thumb[:, :1]))
    gy = np.abs(np.diff(thumb, axis=0, prepend=thumb[:1, :]))
    edge = gx + gy
    peak = float(edge.max()) or 1.0
    edge = _downsample(edge / peak, EDGE_W, EDGE_H)
    edge_q = np.clip(edge * 255.0, 0, 255).astype(np.uint8)

    # 3) 色相直方图（饱和度加权）
    px = frame.rgb[::8, ::8, :3]
    if px.size == 0:
        px = frame.rgb[:, :, :3]
    hsv_in = px.astype(np.float32) / 255.0
    h = hsv_in[..., 0] * 0.0
    # 直接算 hue，避免依赖 battle 模块
    r, g, b = hsv_in[..., 0], hsv_in[..., 1], hsv_in[..., 2]
    mx = hsv_in.max(axis=-1)
    mn = hsv_in.min(axis=-1)
    d = mx - mn
    safe = np.where(d > 1e-6, d, 1.0)
    mask_r = (mx == r) & (d > 1e-6)
    mask_g = (mx == g) & (d > 1e-6) & ~mask_r
    mask_b = (mx == b) & (d > 1e-6) & ~mask_r & ~mask_g
    h[mask_r] = ((g - b)[mask_r] / safe[mask_r]) % 6.0
    h[mask_g] = ((b - r)[mask_g] / safe[mask_g]) + 2.0
    h[mask_b] = ((r - g)[mask_b] / safe[mask_b]) + 4.0
    h *= 60.0
    saturation = np.where(mx > 1e-6, d / np.where(mx > 1e-6, mx, 1.0), 0.0)
    weights = (saturation * mx).reshape(-1)
    hist, _ = np.histogram(h.reshape(-1), bins=HIST_BINS, range=(0.0, 360.0), weights=weights)
    total = float(hist.sum()) or 1.0
    hist = (hist / total).round(5)

    # 4) 3x3 区块平均色
    grid: list[float] = []
    for gy_i in range(GRID):
        for gx_i in range(GRID):
            block = frame.rgb[
                height * gy_i // GRID : height * (gy_i + 1) // GRID,
                width * gx_i // GRID : width * (gx_i + 1) // GRID,
                :3,
            ]
            grid.append(round(float(block.mean()) / 255.0, 4) if block.size else 0.0)

    return {
        "thumb": _b64_uint8(thumb_q),
        "edge": _b64_uint8(edge_q),
        "hist": [float(v) for v in hist],
        "grid": grid,
        "aspect": round(width / height, 4) if height else 1.0,
    }


# ---------------------------------------------------------------- 相似度

def _thumb_from(item: dict) -> np.ndarray:
    arr = _from_b64(item["thumb"], (THUMB_H, THUMB_W)).astype(np.float32)
    return _norm((arr - 128.0) / 32.0)


def _edge_from(item: dict) -> np.ndarray:
    return _from_b64(item["edge"], (EDGE_H, EDGE_W)).astype(np.float32) / 255.0


def _smooth_hist(hist: np.ndarray) -> np.ndarray:
    """把 24 段合并成 12 段：对压缩噪声、轻微色偏更稳。"""
    h = np.asarray(hist, dtype=np.float32)
    if h.size >= 2 and h.size % 2 == 0:
        h = h.reshape(-1, 2).sum(axis=1)
    return h


def similarity(a: dict, b: dict) -> float:
    """两个指纹的相似度，0~1。

    四个分量都做了「拉开动态范围」的处理：缩略图用相关系数，直方图用平滑后的
    交集，边缘用相关系数，区块色用指数衰减——避免某个分量恒定偏高把总分撑起来。
    """
    try:
        if abs(float(a.get("aspect", 1.0)) - float(b.get("aspect", 1.0))) > 0.06:
            return 0.0

        ta, tb = _thumb_from(a), _thumb_from(b)
        corr = float((ta * tb).mean())
        corr = max(-1.0, min(1.0, corr))
        thumb_sim = (corr + 1.0) / 2.0

        ha = _smooth_hist(a.get("hist", []))
        hb = _smooth_hist(b.get("hist", []))
        hist_sim = float(np.minimum(ha, hb).sum()) if ha.size == hb.size and ha.size else 0.0

        ea, eb = _edge_from(a), _edge_from(b)
        if ea.shape == eb.shape and ea.size:
            e_corr = float((_norm(ea) * _norm(eb)).mean())
            edge_sim = (max(-1.0, min(1.0, e_corr)) + 1.0) / 2.0
        else:
            edge_sim = 0.0

        ga = np.asarray(a.get("grid", []), dtype=np.float32)
        gb = np.asarray(b.get("grid", []), dtype=np.float32)
        if ga.size == gb.size and ga.size:
            grid_sim = float(np.exp(-6.0 * np.abs(ga - gb).mean()))
        else:
            grid_sim = 0.0

        score = (
            0.50 * thumb_sim
            + 0.18 * max(0.0, min(1.0, hist_sim))
            + 0.16 * max(0.0, min(1.0, edge_sim))
            + 0.16 * max(0.0, min(1.0, grid_sim))
        )
        return float(max(0.0, min(1.0, score)))
    except (KeyError, ValueError, TypeError):
        return 0.0


# ---------------------------------------------------------------- 场景库

@dataclass
class SceneLibrary:
    """界面指纹库：学习、匹配、持久化。"""

    path: Path
    threshold: float = 0.90
    scenes: dict[str, list[dict]] = field(default_factory=dict)
    enabled: bool = True
    last_saved: float = 0.0
    dirty: bool = False

    # -- 读写 -----------------------------------------------------

    @classmethod
    def load(cls, path: str | Path, threshold: float = 0.90) -> "SceneLibrary":
        lib = cls(path=Path(path), threshold=threshold)
        try:
            data = json.loads(lib.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return lib
        if not isinstance(data, dict):
            return lib
        lib.threshold = float(data.get("threshold", threshold))
        raw = data.get("scenes")
        if isinstance(raw, dict):
            for name, items in raw.items():
                if isinstance(items, list):
                    lib.scenes[str(name)] = [x for x in items if isinstance(x, dict) and "thumb" in x]
        return lib

    def save(self, force: bool = False) -> bool:
        now = time.time()
        if not force and now - self.last_saved < 3.0:
            return False
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "version": 1,
                "threshold": self.threshold,
                "scenes": self.scenes,
            }
            self.path.write_text(
                json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n",
                encoding="utf-8",
            )
            self.last_saved = now
            self.dirty = False
            return True
        except OSError:
            return False

    # -- 学习 / 匹配 ----------------------------------------------

    def learn(self, name: str, fp: dict, tolerance: float = 0.985) -> bool:
        """学一个样本；和已有样本几乎一样就跳过，返回是否新增。"""
        name = str(name).strip()
        if not name or not isinstance(fp, dict):
            return False
        items = self.scenes.setdefault(name, [])
        for old in items:
            if similarity(old, fp) >= tolerance:
                return False
        items.append(fp)
        if len(items) > MAX_PER_SCENE:
            del items[0 : len(items) - MAX_PER_SCENE]
        self.dirty = True
        return True

    def match(self, fp: dict) -> tuple[str, float]:
        """返回最像的界面名与分数；库为空返回 ("", 0)。"""
        name, score, _second = self.match_detailed(fp)
        return name, score

    def match_detailed(self, fp: dict) -> tuple[str, float, float]:
        """返回 (最佳界面, 最佳分数, 第二好的不同界面分数)。"""
        scores: dict[str, float] = {}
        for name, items in self.scenes.items():
            best = 0.0
            for item in items:
                value = similarity(item, fp)
                if value > best:
                    best = value
            scores[name] = best
        if not scores:
            return "", 0.0, 0.0
        ordered = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
        best_name, best_score = ordered[0]
        second = ordered[1][1] if len(ordered) > 1 else 0.0
        return best_name, best_score, second

    def confident(self, score: float, second: float, margin: float = 0.04) -> bool:
        """够像，且明显比第二名像，才认为识别可信。"""
        return score >= self.threshold and (score - second) >= margin

    def match_frame(self, frame: Frame) -> tuple[str, float]:
        return self.match(fingerprint(frame))

    # -- 管理 -----------------------------------------------------

    def __len__(self) -> int:
        return sum(len(v) for v in self.scenes.values())

    def names(self) -> list[str]:
        return sorted(self.scenes)

    def count(self, name: str) -> int:
        return len(self.scenes.get(name, []))

    def remove(self, name: str) -> bool:
        if name in self.scenes:
            del self.scenes[name]
            self.dirty = True
            return True
        return False

    def clear(self) -> None:
        self.scenes.clear()
        self.dirty = True

    def summary(self) -> list[tuple[str, int]]:
        return [(name, len(items)) for name, items in sorted(self.scenes.items())]

    def total(self) -> int:
        return len(self)
