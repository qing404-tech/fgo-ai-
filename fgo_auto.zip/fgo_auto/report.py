"""运行报告：把「打了多少场、用掉多少苹果、清了多少节点、跑了多久」记下来。

输出两个文件（都在 logs/ 下）：
  * report.jsonl  逐条事件，方便自己再分析
  * summary.json  本次运行的汇总，退出时写一次

设计成「失败也不影响主流程」——所有写盘都吞异常。
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

MAX_REPORT_BYTES = 8 * 1024 * 1024  # 超过就滚动一次，避免无限增长


@dataclass
class Report:
    log_dir: Path
    enabled: bool = True
    started_at: float = field(default_factory=time.time)
    run_id: str = field(default_factory=lambda: time.strftime("%Y%m%d_%H%M%S"))
    counters: dict[str, int] = field(default_factory=dict)
    events: int = 0
    last_event: str = ""

    # -- 路径 -----------------------------------------------------

    @property
    def events_path(self) -> Path:
        return Path(self.log_dir) / "report.jsonl"

    @property
    def summary_path(self) -> Path:
        return Path(self.log_dir) / "summary.json"

    # -- 记录 -----------------------------------------------------

    def event(self, name: str, **fields: Any) -> None:
        self.counters[name] = self.counters.get(name, 0) + 1
        self.events += 1
        self.last_event = name
        if not self.enabled:
            return
        payload = {
            "ts": round(time.time(), 3),
            "t": round(time.time() - self.started_at, 1),
            "run": self.run_id,
            "event": name,
        }
        payload.update({k: v for k, v in fields.items() if v is not None})
        try:
            self.log_dir.mkdir(parents=True, exist_ok=True)
            self._rotate_if_needed()
            with self.events_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(payload, ensure_ascii=False) + "\n")
        except OSError:
            pass  # 报告失败不影响自动化

    def battle(self, **fields: Any) -> None:
        self.event("battle", **fields)

    def result(self, **fields: Any) -> None:
        self.event("result", **fields)

    def apple(self, kind: str = "", ap: int = 0) -> None:
        if ap:
            self.counters["ap_spent"] = self.counters.get("ap_spent", 0) + int(ap)
        self.event("apple", kind=kind or None, ap=ap or None)

    def error(self, message: str) -> None:
        self.event("error", message=str(message)[:300])

    # -- 汇总 -----------------------------------------------------

    def summary(self) -> dict:
        return {
            "run": self.run_id,
            "elapsed": round(time.time() - self.started_at, 1),
            "battles": self.counters.get("battle", 0),
            "cleared": self.counters.get("result", 0),
            "apples": self.counters.get("apple", 0),
            "ap_spent": self.counters.get("ap_spent", 0),
            "errors": self.counters.get("error", 0),
            "events": self.events,
            "last_event": self.last_event,
        }

    def summary_line(self) -> str:
        s = self.summary()
        return (
            f"跑了 {s['elapsed']:.0f}s：战斗 {s['battles']} 场 / 清理 {s['cleared']} 次 / "
            f"苹果 {s['apples']} 个 / 消耗 AP {s['ap_spent']} / 错误 {s['errors']}"
        )

    def write_summary(self, extra: dict | None = None) -> None:
        if not self.enabled:
            return
        data = self.summary()
        if extra:
            data.update(extra)
        try:
            self.log_dir.mkdir(parents=True, exist_ok=True)
            self.summary_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
            )
        except OSError:
            pass

    # -- 内部 -----------------------------------------------------

    def _rotate_if_needed(self) -> None:
        try:
            path = self.events_path
            if path.is_file() and path.stat().st_size > MAX_REPORT_BYTES:
                path.replace(path.with_suffix(".jsonl.1"))
        except OSError:
            pass
