"""界面主题：明日方舟风格的深色工业视觉（原创实现，不使用游戏素材）。

特征：近黑底、细灰线、橙色强调、切角色块、等宽小字标签、直角无圆角、低饱和面板。
只改外观，不改任何功能。
"""

from __future__ import annotations

import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk

# ---------------------------------------------------------------- 调色板

BG = "#0A0B0D"          # 主背景（近黑）
BG_ALT = "#101218"      # 次级背景（标题条/画布）
PANEL = "#14171C"       # 面板
PANEL_HI = "#1C2129"    # 悬停/选中面板
LINE = "#2B3038"        # 分隔线
TEXT = "#E7E9EC"        # 主文字
MUTED = "#8A919B"       # 次要文字
ACCENT = "#F2A33C"      # 强调橙
ACCENT_HOVER = "#FFB755"
ACCENT_DIM = "#6E4C1E"
DANGER = "#D9534F"
OK = "#6FCF97"

# ---------------------------------------------------------------- 字体

_FALLBACK = ("Microsoft YaHei UI",)
_font_cache: dict[str, tuple] = {}


def _has(families: set[str], name: str) -> bool:
    return name.lower() in families


def _pick(families: set[str], preferred: list[str], size: int, weight: str = "normal") -> tuple:
    for name in preferred:
        if _has(families, name):
            return (name, size, weight) if weight != "normal" else (name, size)
    return ("Microsoft YaHei UI", size, weight) if weight != "normal" else ("Microsoft YaHei UI", size)


def font_latin(size: int = 10, weight: str = "normal") -> tuple:
    """压缩体拉丁/数字（标题、按钮、状态）。"""
    key = f"latin-{size}-{weight}"
    if key not in _font_cache:
        families = {f.lower() for f in tkfont.families()}
        _font_cache[key] = _pick(
            families,
            ["Bahnschrift SemiCondensed", "Bahnschrift Condensed", "Bahnschrift", "Segoe UI"],
            size,
            weight,
        )
    return _font_cache[key]


def font_cn(size: int = 10, weight: str = "normal") -> tuple:
    """中文正文。"""
    key = f"cn-{size}-{weight}"
    if key not in _font_cache:
        families = {f.lower() for f in tkfont.families()}
        _font_cache[key] = _pick(
            families, ["Microsoft YaHei UI", "Microsoft YaHei", "SimHei"], size, weight
        )
    return _font_cache[key]


def font_mono(size: int = 9) -> tuple:
    """等宽小字（标签、日志、坐标）。"""
    key = f"mono-{size}"
    if key not in _font_cache:
        families = {f.lower() for f in tkfont.families()}
        _font_cache[key] = _pick(
            families, ["Consolas", "Cascadia Mono", "Courier New"], size
        )
    return _font_cache[key]


# ---------------------------------------------------------------- ttk 样式

def apply_theme(root: tk.Misc) -> ttk.Style:
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:  # pragma: no cover
        pass

    root.option_add("*Font", font_cn(10))
    try:
        root.configure(bg=BG)
    except tk.TclError:  # pragma: no cover
        pass

    # 基础
    style.configure(
        ".",
        background=BG,
        foreground=TEXT,
        fieldbackground=PANEL,
        bordercolor=LINE,
        lightcolor=BG,
        darkcolor=BG,
        troughcolor=BG,
        selectbackground=ACCENT_DIM,
        selectforeground=TEXT,
        focuscolor=ACCENT,
        font=font_cn(10),
        borderwidth=0,
    )
    style.configure("TFrame", background=BG)
    style.configure("Panel.TFrame", background=PANEL)
    style.configure("Strip.TFrame", background=BG_ALT)
    style.configure("Line.TFrame", background=LINE)

    # 文字
    style.configure("TLabel", background=BG, foreground=TEXT)
    style.configure("Panel.TLabel", background=PANEL, foreground=TEXT)
    style.configure("Muted.TLabel", foreground=MUTED, font=font_mono(9))
    style.configure("Label.TLabel", foreground=MUTED, font=font_latin(9))
    style.configure("Accent.TLabel", foreground=ACCENT, font=font_latin(10, "bold"))
    style.configure("Title.TLabel", foreground=TEXT, font=font_latin(19, "bold"))

    # 按钮：直角、细边、悬停变亮
    style.configure(
        "TButton",
        background=PANEL_HI,
        foreground=TEXT,
        bordercolor=LINE,
        lightcolor=PANEL_HI,
        darkcolor=PANEL_HI,
        relief="flat",
        padding=(11, 5),
        font=font_latin(10),
    )
    style.map(
        "TButton",
        background=[("pressed", ACCENT), ("active", "#252B34"), ("disabled", "#15181D")],
        foreground=[("pressed", BG), ("active", TEXT), ("disabled", "#5A616B")],
        bordercolor=[("active", ACCENT), ("pressed", ACCENT)],
    )
    style.configure(
        "Accent.TButton",
        background=ACCENT,
        foreground=BG,
        bordercolor=ACCENT,
        lightcolor=ACCENT,
        darkcolor=ACCENT,
        padding=(16, 6),
        font=font_latin(11, "bold"),
    )
    style.map(
        "Accent.TButton",
        background=[("active", ACCENT_HOVER), ("pressed", "#D98D28"), ("disabled", "#3A2E1C")],
        foreground=[("disabled", "#7A6A4A")],
    )
    style.configure(
        "Danger.TButton",
        background="#241618",
        foreground="#E7908C",
        bordercolor="#3C2528",
        lightcolor="#241618",
        darkcolor="#241618",
    )
    style.map(
        "Danger.TButton",
        background=[("active", "#2F1B1E"), ("pressed", DANGER)],
        foreground=[("pressed", BG)],
        bordercolor=[("active", "#5A3338")],
    )
    style.configure(
        "Ghost.TButton",
        background=BG,
        foreground=MUTED,
        bordercolor=LINE,
        lightcolor=BG,
        darkcolor=BG,
    )
    style.map("Ghost.TButton", foreground=[("active", ACCENT)], bordercolor=[("active", ACCENT)])

    # 输入
    style.configure(
        "TEntry",
        fieldbackground=BG_ALT,
        foreground=TEXT,
        insertcolor=ACCENT,
        bordercolor=LINE,
        lightcolor=LINE,
        darkcolor=LINE,
        padding=4,
        font=font_mono(9),
    )
    style.map("TEntry", bordercolor=[("focus", ACCENT)])
    style.configure(
        "TCombobox",
        fieldbackground=BG_ALT,
        background=BG_ALT,
        foreground=TEXT,
        arrowcolor=ACCENT,
        bordercolor=LINE,
        lightcolor=LINE,
        darkcolor=LINE,
        padding=3,
    )
    style.map(
        "TCombobox",
        fieldbackground=[("readonly", BG_ALT)],
        foreground=[("readonly", TEXT)],
        bordercolor=[("focus", ACCENT)],
    )

    # 复选
    style.configure(
        "TCheckbutton",
        background=BG,
        foreground=MUTED,
        indicatorcolor=BG_ALT,
        indicatorbackground=BG_ALT,
        bordercolor=LINE,
        focuscolor=BG,
        font=font_cn(9),
    )
    style.map(
        "TCheckbutton",
        background=[("active", BG)],
        foreground=[("active", TEXT)],
        indicatorcolor=[("selected", ACCENT), ("active", PANEL_HI)],
    )

    # 标签页
    style.configure("TNotebook", background=BG, borderwidth=0, tabmargins=(0, 0, 0, 0))
    style.configure(
        "TNotebook.Tab",
        background=BG_ALT,
        foreground=MUTED,
        padding=(16, 6),
        borderwidth=0,
        font=font_latin(10),
    )
    style.map(
        "TNotebook.Tab",
        background=[("selected", PANEL_HI)],
        foreground=[("selected", ACCENT)],
        expand=[("selected", (0, 0, 0, 0))],
    )

    # 表格
    style.configure(
        "Treeview",
        background=PANEL,
        fieldbackground=PANEL,
        foreground=TEXT,
        bordercolor=LINE,
        rowheight=24,
        font=font_cn(9),
    )
    style.map(
        "Treeview",
        background=[("selected", ACCENT_DIM)],
        foreground=[("selected", "#FFF3DF")],
    )
    style.configure(
        "Treeview.Heading",
        background=BG_ALT,
        foreground=MUTED,
        relief="flat",
        font=font_latin(9),
        bordercolor=LINE,
    )
    style.map("Treeview.Heading", background=[("active", PANEL_HI)])

    style.configure("TPanedwindow", background=BG, sashwidth=4)
    style.configure("TSeparator", background=LINE)
    style.configure("TScrollbar", background=BG_ALT, troughcolor=BG, arrowcolor=MUTED, borderwidth=0)
    style.map("TScrollbar", background=[("active", LINE)])

    return style


# ---------------------------------------------------------------- 画布装饰

def draw_header(canvas: tk.Canvas, width: int, height: int, title: str, subtitle: str) -> None:
    """顶部标题条：切角色块 + 主标题 + 等宽副标题 + 底部细线。"""
    canvas.delete("header")
    canvas.configure(bg=BG_ALT)
    canvas.create_rectangle(0, 0, width, height, fill=BG_ALT, outline="", tags="header")

    # 左侧橙色切角色块
    canvas.create_polygon(
        0, 0, 104, 0, 82, height, 0, height,
        fill=ACCENT, outline="", tags="header",
    )
    canvas.create_text(
        16, height / 2 - 2, text="FGO", anchor="w",
        fill=BG, font=font_latin(24, "bold"), tags="header",
    )
    # 主标题 + 副标题
    canvas.create_text(
        124, height / 2 - 12, text=title, anchor="w",
        fill=TEXT, font=font_latin(19, "bold"), tags="header",
    )
    canvas.create_text(
        126, height / 2 + 14, text=subtitle, anchor="w",
        fill=MUTED, font=font_mono(9), tags="header",
    )

    # 右侧装饰刻度
    right = width - 18
    for i in range(7):
        x = right - i * 12
        canvas.create_line(x, 16, x, 28, fill=LINE, tags="header")
    canvas.create_text(
        right, height - 26, text="SYSTEM // ONLINE", anchor="e",
        fill=ACCENT_DIM if width < 900 else ACCENT, font=font_mono(8), tags="header",
    )

    # 底部细线 + 左侧短橙线
    canvas.create_line(0, height - 1, width, height - 1, fill=LINE, tags="header")
    canvas.create_line(0, height - 1, 180, height - 1, fill=ACCENT, tags="header")


def draw_brackets(
    canvas: tk.Canvas, x: float, y: float, w: float, h: float,
    color: str = ACCENT, size: float = 16, tag: str = "decor",
) -> None:
    """四角折线（取景框）。"""
    s = size
    for (px, py, dx, dy) in (
        (x, y, 1, 1),
        (x + w, y, -1, 1),
        (x, y + h, 1, -1),
        (x + w, y + h, -1, -1),
    ):
        canvas.create_line(px, py, px + dx * s, py, fill=color, width=2, tags=tag)
        canvas.create_line(px, py, px, py + dy * s, fill=color, width=2, tags=tag)


def draw_grid(
    canvas: tk.Canvas, x: float, y: float, w: float, h: float,
    color: str = "#1A1E24", step: int = 40, tag: str = "decor",
) -> None:
    """淡色坐标网格。"""
    gx = x
    while gx < x + w:
        canvas.create_line(gx, y, gx, y + h, fill=color, tags=tag)
        gx += step
    gy = y
    while gy < y + h:
        canvas.create_line(x, gy, x + w, gy, fill=color, tags=tag)
        gy += step


def canvas_colors() -> tuple[str, str, str]:
    """(画布底色, 网格色, 提示文字色)。"""
    return BG_ALT, "#1A1E24", MUTED
