"""战斗方案（bbchannel 风格的作战脚本）。

用一份 JSON 描述「第几回合、开哪些技能、放哪些宝具、选什么卡」，与画面识别解耦，
因此可以从外部工具（例如把 Chaldea 的队伍导出转成 JSON）生成后直接导入。

示例::

    {
      "name": "3T 周回",
      "cards": {
        "mode": "color",
        "priority": ["buster", "arts", "quick"],
        "per_turn": {"3": ["arts", "arts", "buster"]}
      },
      "turns": [
        {"turn": 1, "skills": ["1-1", "1-2", "2-1"], "np": [1]},
        {"turn": 2, "skills": ["3-1"], "np": [2]},
        {"turn": 3, "skills": [], "np": []}
      ]
    }

约定：
  * 从者编号、技能位都是 1 开始的整数；
  * 技能写成 "从者-技能"（也接受 [从者, 技能] 或 {"servant": 1, "slot": 2}）；
  * 缺省的回合表示「只攻击，不放技能/宝具」。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

VALID_CARDS = ("buster", "arts", "quick")


def _to_int(value: Any, what: str) -> int:
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{what} 不是整数: {value!r}") from exc


def _parse_skill(item: Any) -> tuple[int, int]:
    """把 "1-2" / [1, 2] / {"servant":1,"slot":2} 统一成 (从者, 技能)。"""
    if isinstance(item, str):
        text = item.strip().replace(":", "-").replace("/", "-")
        if "-" not in text:
            raise ValueError(f"技能写法应为 '从者-技能'，例如 '1-2'，收到: {item!r}")
        servant, slot = text.split("-", 1)
        return _to_int(servant, "从者编号"), _to_int(slot, "技能位")
    if isinstance(item, (list, tuple)) and len(item) == 2:
        return _to_int(item[0], "从者编号"), _to_int(item[1], "技能位")
    if isinstance(item, dict):
        if "servant" in item and "slot" in item:
            return _to_int(item["servant"], "从者编号"), _to_int(item["slot"], "技能位")
    raise ValueError(f"无法解析技能: {item!r}")


def _clean_cards(value: Any, what: str = "卡色") -> list[str]:
    out: list[str] = []
    for item in value or []:
        card = str(item).strip().lower()
        if card not in VALID_CARDS:
            raise ValueError(f"{what} 只能是 {VALID_CARDS}，收到: {item!r}")
        out.append(card)
    return out


@dataclass
class BattlePlan:
    """一份战斗方案。"""

    name: str = "未命名方案"
    turns: dict[int, dict] = field(default_factory=dict)
    cards_mode: str = "color"
    cards_priority: list[str] = field(default_factory=lambda: ["buster", "arts", "quick"])
    cards_per_turn: dict[int, list[str]] = field(default_factory=dict)
    cards_policy: str = "priority"  # priority / same_color / full_chain

    # -- 构造 -----------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict) -> "BattlePlan":
        if not isinstance(data, dict):
            raise ValueError("战斗方案必须是 JSON 对象")
        plan = cls(name=str(data.get("name") or "未命名方案"))

        cards = data.get("cards")
        if isinstance(cards, dict):
            mode = str(cards.get("mode") or "color").lower()
            plan.cards_mode = "fixed" if mode == "fixed" else "color"
            priority = _clean_cards(cards.get("priority"))
            if priority:
                plan.cards_priority = priority
            policy = str(cards.get("policy") or "priority").lower()
            plan.cards_policy = policy if policy in ("priority", "same_color", "full_chain") else "priority"
            per_turn = cards.get("per_turn")
            if isinstance(per_turn, dict):
                for key, value in per_turn.items():
                    plan.cards_per_turn[_to_int(key, "回合号")] = _clean_cards(value)

        turns = data.get("turns")
        if turns is not None and not isinstance(turns, list):
            raise ValueError("turns 必须是数组")
        for index, raw in enumerate(turns or [], start=1):
            if not isinstance(raw, dict):
                raise ValueError(f"turns[{index}] 必须是对象")
            turn = _to_int(raw.get("turn", index), "回合号")
            skills = [_parse_skill(x) for x in (raw.get("skills") or [])]
            np_list = [_to_int(x, "宝具从者编号") for x in (raw.get("np") or [])]
            plan.turns[turn] = {"skills": skills, "np": np_list}
        if not plan.turns:
            plan.turns[1] = {"skills": [], "np": []}
        return plan

    @classmethod
    def load(cls, path: str | Path) -> "BattlePlan":
        p = Path(path)
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"战斗方案不是合法 JSON: {p} ({exc})") from exc
        plan = cls.from_dict(data)
        if not plan.name or plan.name == "未命名方案":
            plan.name = p.stem
        return plan

    def save(self, path: str | Path) -> Path:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(
            json.dumps(self.to_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        return p

    # -- 序列化 ---------------------------------------------------

    def to_dict(self) -> dict:
        turns = []
        for turn in sorted(self.turns):
            item = self.turns[turn]
            turns.append(
                {
                    "turn": turn,
                    "skills": [f"{s}-{k}" for s, k in item.get("skills", [])],
                    "np": list(item.get("np", [])),
                }
            )
        data: dict[str, Any] = {
            "name": self.name,
            "cards": {
                "mode": self.cards_mode,
                "priority": list(self.cards_priority),
            },
            "turns": turns,
        }
        if self.cards_per_turn:
            data["cards"]["per_turn"] = {
                str(k): list(v) for k, v in sorted(self.cards_per_turn.items())
            }
        return data

    # -- 查询 -----------------------------------------------------

    def skills_for(self, turn: int) -> list[tuple[int, int]]:
        return list(self.turns.get(turn, {}).get("skills", []))

    def np_for(self, turn: int) -> list[int]:
        return list(self.turns.get(turn, {}).get("np", []))

    def cards_for(self, turn: int) -> list[str] | None:
        """该回合指定的卡色顺序；None 表示交给默认策略。"""
        return self.cards_per_turn.get(turn)

    def describe(self, turns: int = 5) -> str:
        parts = []
        for turn in range(1, turns + 1):
            skills = self.skills_for(turn)
            np_list = self.np_for(turn)
            cards = self.cards_for(turn)
            bits = []
            if skills:
                bits.append("技能 " + ", ".join(f"{s}-{k}" for s, k in skills))
            if np_list:
                bits.append("宝具 " + ", ".join(str(n) for n in np_list))
            if cards:
                bits.append("选卡 " + "/".join(cards))
            parts.append(f"T{turn}: " + ("；".join(bits) if bits else "平砍"))
        return " | ".join(parts)


def load_plan(path: str | Path) -> BattlePlan:
    return BattlePlan.load(path)


def empty_plan() -> BattlePlan:
    return BattlePlan(name="默认（不开技能）", turns={1: {"skills": [], "np": []}})
