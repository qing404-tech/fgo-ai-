"""战斗策略：战斗方案（bbchannel 风格）、技能、宝具、选卡。

优先级：
  1. 有战斗方案（battle.plan / --plan）就按方案执行：第几回合开哪些技能、放哪些宝具、
     选什么卡色；
  2. 没有方案时退回旧的 `battle.skill_plan`（按回合点坐标）与 `use_np`；
  3. 选卡颜色识别不可靠时自动退化为从左到右，保证不卡死。
"""

from __future__ import annotations

import random
import time

import numpy as np

from .actions import ActionError, Ctx
from .plan import BattlePlan

# ---------------------------------------------------------------- 颜色识别

def rgb_to_hsv(rgb: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """RGB(0-255) -> (H 0-360, S 0-1, V 0-1)。"""
    a = np.asarray(rgb, dtype=np.float32) / 255.0
    if a.ndim == 2:
        a = np.repeat(a[:, :, None], 3, axis=2)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    mx = a.max(axis=-1)
    mn = a.min(axis=-1)
    d = mx - mn
    safe = np.where(d > 1e-6, d, 1.0)
    h = np.zeros_like(mx)
    mr = (mx == r) & (d > 1e-6)
    mg = (mx == g) & (d > 1e-6) & ~mr
    mb = (mx == b) & (d > 1e-6) & ~mr & ~mg
    h[mr] = ((g - b)[mr] / safe[mr]) % 6.0
    h[mg] = ((b - r)[mg] / safe[mg]) + 2.0
    h[mb] = ((r - g)[mb] / safe[mb]) + 4.0
    h *= 60.0
    s = np.where(mx > 1e-6, d / np.where(mx > 1e-6, mx, 1.0), 0.0)
    return h, s, mx


def classify_color(
    rgb: np.ndarray, hsv_cfg: dict, min_ratio: float = 0.35
) -> str | None:
    """按 HSV 区间判断这块像素最像哪种卡色，占比不足返回 None。"""
    if rgb is None or rgb.size == 0:
        return None
    h, s, v = rgb_to_hsv(rgb)
    total = float(h.size) or 1.0
    best: str | None = None
    best_ratio = 0.0
    for name, ranges in (hsv_cfg or {}).items():
        mask = np.zeros(h.shape, dtype=bool)
        for rng in ranges or []:
            if len(rng) != 6:
                continue
            hmin, smin, vmin, hmax, smax, vmax = (float(x) for x in rng)
            mask |= (
                (h >= hmin) & (h <= hmax)
                & (s * 255.0 >= smin) & (s * 255.0 <= smax)
                & (v * 255.0 >= vmin) & (v * 255.0 <= vmax)
            )
        ratio = float(mask.sum()) / total
        if ratio > best_ratio:
            best, best_ratio = name, ratio
    return best if best_ratio >= min_ratio else None


# ---------------------------------------------------------------- 坐标

def _sample_box(cfg: dict, index: int, size: tuple[int, int]) -> tuple[int, int, int, int]:
    """第 index 张卡的取样矩形（像素）。"""
    width, height = size
    slots = cfg["card_slots"]
    cx, cy = float(slots[index][0]), float(slots[index][1])
    bw = float(cfg["card_box"][0]) * width
    bh = float(cfg["card_box"][1]) * height
    x = cx * width - bw / 2.0
    y = cy * height - bh / 2.0
    sx0, sy0, sx1, sy1 = (float(v) for v in cfg["sample"])
    bx = int(round(x + sx0 * bw))
    by = int(round(y + sy0 * bh))
    bwd = max(1, int(round((sx1 - sx0) * bw)))
    bhd = max(1, int(round((sy1 - sy0) * bh)))
    return bx, by, bwd, bhd


def _grid_point(grid: dict, column: int, row_index: int | None, size: tuple[int, int]):
    """从 skill_grid / np_grid 取一个归一化坐标点；越界返回 None。"""
    width, height = size
    xs = [float(v) for v in (grid.get("x") or [])]
    ys = grid.get("y")
    if column < 0 or column >= len(xs):
        return None
    x = xs[column] * width
    if isinstance(ys, (list, tuple)):
        if row_index is None or row_index < 0 or row_index >= len(ys):
            return None
        y = float(ys[row_index]) * height
    else:
        if ys is None:
            return None
        y = float(ys) * height
    return int(round(x)), int(round(y))


# ---------------------------------------------------------------- 技能 / 宝具

def _tap_skill(ctx: Ctx, servant: int, slot: int) -> bool:
    """点「从者 servant 的第 slot 个技能」：模板优先，坐标兜底。"""
    cfg = ctx.cfg.get("battle") or {}
    match = ctx.find(f"t_skill_{servant}_{slot}")
    if match is not None:
        ctx.tap_match(match)
        ctx.sleep(0.35)
        return True
    point = _grid_point(cfg.get("skill_grid") or {}, servant - 1, slot - 1, ctx.device.size)
    if point is None:
        return False
    ctx.tap_point(point)
    ctx.sleep(0.35)
    return True


def _tap_np(ctx: Ctx, servant: int) -> bool:
    """放从者 servant 的宝具：模板优先，坐标兜底。"""
    cfg = ctx.cfg.get("battle") or {}
    match = ctx.find(f"t_np_{servant}")
    if match is not None:
        ctx.tap_match(match)
        ctx.sleep(0.9)
        return True
    point = _grid_point(cfg.get("np_grid") or {}, servant - 1, None, ctx.device.size)
    if point is None:
        return False
    ctx.tap_point(point)
    ctx.sleep(0.9)
    return True


def _run_plan_turn(ctx: Ctx, plan: BattlePlan, turn: int) -> None:
    skills = plan.skills_for(turn)
    for servant, slot in skills:
        if _tap_skill(ctx, servant, slot):
            ctx.log(f"T{turn} 技能 {servant}-{slot}")
        else:
            ctx.log(f"T{turn} 技能 {servant}-{slot} 没有模板也没有可用坐标", "warn")
    if skills:
        ctx.sleep(0.3)

    for servant in plan.np_for(turn):
        if _tap_np(ctx, servant):
            ctx.log(f"T{turn} 宝具 {servant}")
        else:
            ctx.log(f"T{turn} 宝具 {servant} 没点成功", "warn")


# ---------------------------------------------------------------- 选卡

def order_cards(
    colors: list[str | None],
    priority: list[str],
    policy: str = "priority",
    forced: list[str] | None = None,
) -> list[int]:
    """按策略给出出卡顺序（索引列表）。

    - forced：方案指定的卡色顺序，优先匹配；
    - priority：按卡色优先级排序；
    - same_color：首卡选定后，优先同色（FGO 同色连携有加成）；
    - full_chain：能凑出三同色时优先凑满三连，否则退回 priority。
    """
    total = len(colors)
    rank = {str(c): i for i, c in enumerate(priority)}

    def key(i: int) -> tuple:
        return (rank.get(str(colors[i]), len(rank)), i)

    if forced:
        order: list[int] = []
        used: set[int] = set()
        for color in forced[:3]:
            for i, got in enumerate(colors):
                if i not in used and got == color:
                    order.append(i)
                    used.add(i)
                    break
        order += [i for i in range(total) if i not in used]
        return order

    if all(c is None for c in colors):
        return list(range(total))

    if policy == "full_chain":
        counts: dict[str, int] = {}
        for color in colors:
            if color is not None:
                counts[color] = counts.get(color, 0) + 1
        best = max(counts, key=lambda c: (counts[c], -rank.get(c, len(rank))), default=None)
        if best is not None and counts.get(best, 0) >= 3:
            same = [i for i, c in enumerate(colors) if c == best]
            rest = sorted([i for i in range(total) if i not in same], key=key)
            return same + rest

    if policy == "same_color":
        first = min(range(total), key=key)
        same = [i for i in range(total) if i != first and colors[i] == colors[first]]
        other = sorted([i for i in range(total) if i != first and colors[i] != colors[first]], key=key)
        return [first] + same + other

    return sorted(range(total), key=key)


def pick_cards(
    ctx: Ctx,
    spec: dict | None = None,
    forced_colors: list[str] | None = None,
) -> None:
    """在当前选卡界面按策略点三张卡。

    forced_colors：战斗方案里指定的卡色顺序，例如 ["arts", "arts", "buster"]。
    """
    cfg = ctx.cfg.get("battle") or {}
    slots = cfg.get("card_slots") or []
    if len(slots) < 3:
        raise ActionError("battle.card_slots 至少需要 3 个坐标")
    width, height = ctx.device.size
    plan: BattlePlan | None = getattr(ctx.engine, "battle_plan", None)
    turn = int(getattr(ctx.engine, "battle_turn", 0))

    if forced_colors is None and plan is not None:
        forced_colors = plan.cards_for(turn)
    mode = str(cfg.get("card_mode", "auto")).lower()
    if plan is not None:
        mode = plan.cards_mode
    priority = list(cfg.get("priority") or ["buster", "arts", "quick"])
    if plan is not None and plan.cards_priority:
        priority = list(plan.cards_priority)

    colors: list[str | None] = []
    for i in range(len(slots)):
        if mode == "fixed":
            colors.append(None)
            continue
        box = _sample_box(cfg, i, (width, height))
        patch = ctx.frame.crop(box)
        colors.append(
            classify_color(patch, cfg.get("hsv") or {}, float(cfg.get("min_classify", 0.35)))
        )

    policy = str(getattr(plan, "cards_policy", "priority") if plan is not None else "priority")
    if mode == "fixed":
        order = list(range(len(slots)))
        ctx.log(f"选卡：固定顺序 {order}")
    else:
        order = order_cards(
            colors[: len(slots)],
            priority,
            policy=policy,
            forced=forced_colors[:3] if forced_colors else None,
        )
        ctx.log(f"选卡（{policy}）：颜色 {colors} -> 顺序 {order[:3]}")

    low, high = (cfg.get("pick_delay") or [0.25, 0.45])[:2]
    for i in order[:3]:
        pt = (int(round(float(slots[i][0]) * width)), int(round(float(slots[i][1]) * height)))
        ctx.tap_point(pt)
        ctx.sleep(random.uniform(float(low), float(high)))

    stats = ctx.engine.stats
    stats["last_cards"] = {
        "turn": turn,
        "policy": policy,
        "colors": list(colors),
        "order": order[:3],
    }
    stats["cards_picked"] = int(stats.get("cards_picked", 0)) + 1
    if any(c is not None for c in colors):
        stats["card_colors"] = int(stats.get("card_colors", 0)) + 1
    if turn == 1:
        report = getattr(ctx.engine, "report", None)
        if report is not None:
            report.battle(plan=plan.name if plan is not None else None)
    ctx.sleep(float(cfg.get("wait_after_pick", 0.8)))


# ---------------------------------------------------------------- 回合

def use_skills(ctx: Ctx, spec: dict | None = None) -> None:
    """旧的技能轴：按 skill_plan 点本回合技能（没有战斗方案时使用）。"""
    cfg = ctx.cfg.get("battle") or {}
    plan = cfg.get("skill_plan") or {}
    turn = str(getattr(ctx.engine, "battle_turn", 0))
    points = plan.get(turn)
    if not points:
        return
    width, height = ctx.device.size
    for raw in points:
        x, y = float(raw[0]), float(raw[1])
        if abs(x) <= 1.0 and abs(y) <= 1.0:
            x, y = x * width, y * height
        ctx.tap_point((int(round(x)), int(round(y))))
        ctx.log(f"回合 {turn} 开技能 @ {(int(x), int(y))}")
        ctx.sleep(0.45)
    ctx.sleep(0.3)


def battle_attack(ctx: Ctx, spec: dict | None = None) -> None:
    """一整个战斗回合：技能/宝具 -> 攻击 -> 选卡。"""
    cfg = ctx.cfg.get("battle") or {}
    engine = ctx.engine
    engine.battle_turn = int(getattr(engine, "battle_turn", 0)) + 1
    turn = int(engine.battle_turn)
    plan: BattlePlan | None = getattr(engine, "battle_plan", None)
    suffix = f"（方案：{plan.name}）" if plan is not None else ""
    ctx.log(f"—— 第 {turn} 回合{suffix} ——")

    if plan is not None:
        _run_plan_turn(ctx, plan, turn)
    else:
        use_skills(ctx, {})
        if cfg.get("use_np"):
            np_tpl = cfg.get("np_tpl")
            if np_tpl:
                match = ctx.find(str(np_tpl))
                if match is not None:
                    ctx.tap_match(match)
                    ctx.log("使用宝具")
                    ctx.sleep(1.2)
                    ctx.refresh()

    attack_tpl = cfg.get("attack_tpl")
    if not attack_tpl:
        raise ActionError("battle.attack_tpl 未配置")
    attack = ctx.find(str(attack_tpl))
    if attack is None:
        ctx.log(f"未识别到攻击按钮 {attack_tpl}，跳过本回合", "warn")
        return
    ctx.tap_match(attack)
    ctx.sleep(float(cfg.get("wait_after_attack", 0.7)))
    ctx.refresh()

    cards_tpl = cfg.get("cards_tpl")
    if cards_tpl:
        deadline = time.time() + float(cfg.get("wait_cards_timeout", 3.0))
        while ctx.find(str(cards_tpl)) is None and time.time() < deadline:
            ctx.sleep(0.3)
            ctx.refresh()
        if ctx.find(str(cards_tpl)) is None:
            ctx.log("点击攻击后没进入选卡界面", "warn")
            return
    pick_cards(ctx, {})


def reset_battle(ctx: Ctx, spec: dict | None = None) -> None:
    ctx.engine.battle_turn = 0
    ctx.log("战斗计数已重置")


def wait_battle_idle(ctx: Ctx, spec: dict | None = None) -> None:
    """等待战斗动画结束（攻击按钮和选卡界面都消失）。"""
    cfg = ctx.cfg.get("battle") or {}
    timeout = float((spec or {}).get("timeout", 15))
    attack = str(cfg.get("attack_tpl") or "")
    cards = str(cfg.get("cards_tpl") or "")
    if not attack and not cards:
        ctx.sleep(min(timeout, 1.0))
        return
    deadline = time.time() + timeout
    while time.time() < deadline:
        ctx.refresh()
        busy = (ctx.find(attack) is not None) if attack else False
        if not busy and cards:
            busy = ctx.find(cards) is not None
        if not busy:
            return
        ctx.sleep(0.4)
