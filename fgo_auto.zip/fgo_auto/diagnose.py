"""画面自检：一次性回答「现在这一屏是什么、能不能跑」。

GUI 的「检测画面」按钮和 CLI 的 `probe` 子命令都走这里。检查项：

  * 画面本身：尺寸、与期望分辨率是否一致、亮度/饱和度、是否黑屏/白屏/纯色；
  * 界面指纹：认成哪个界面、相似度多少、第二名多少、是否可信；
  * 模板流程：按模板匹配命中了哪个流程、关键模板分数；
  * 模板库存：一共加载多少、哪些必需模板缺失；
  * 结论与建议：一句话说明现在能不能跑、不能跑该做什么。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from .config import get_path
from .scene import fingerprint
from .templates import collect_template_names
from .vision import Frame


@dataclass
class ScreenReport:
    width: int = 0
    height: int = 0
    expected: tuple[int, int] = (1280, 720)
    brightness: float = 0.0
    saturation: float = 0.0
    uniformity: float = 0.0
    blank: bool = False

    scene_name: str = ""
    scene_score: float = 0.0
    scene_second: float = 0.0
    scene_confident: bool = False

    flow_name: str = ""
    flow_templates: list[tuple[str, float]] = field(default_factory=list)
    found: int = 0
    total: int = 0
    missing: list[str] = field(default_factory=list)

    verdict: str = ""
    hints: list[str] = field(default_factory=list)

    @property
    def size_text(self) -> str:
        return f"{self.width}x{self.height}"

    def as_text(self) -> str:
        lines = []
        size_note = ""
        if (self.width, self.height) != self.expected:
            size_note = f"（与期望 {self.expected[0]}x{self.expected[1]} 不同，模板可能需重抓）"
        lines.append(f"画面：{self.size_text}{size_note}")
        lines.append(
            f"亮度 {self.brightness:.2f} · 饱和度 {self.saturation:.2f} · 均匀度 {self.uniformity:.2f}"
            + ("（接近纯色）" if self.blank else "")
        )

        if self.scene_name:
            mark = "可信" if self.scene_confident else "不够可信"
            lines.append(
                f"界面指纹：{self.scene_name} {self.scene_score:.2f}"
                f"（第二名 {self.scene_second:.2f}，{mark}）"
            )
        else:
            lines.append("界面指纹：未命中（还没学过这一屏）")

        if self.flow_name:
            detail = "，".join(f"{n} {s:.2f}" for n, s in self.flow_templates[:3])
            lines.append(f"模板流程：{self.flow_name}" + (f"（{detail}）" if detail else ""))
        else:
            lines.append("模板流程：未命中")

        lines.append(
            f"必需模板：{self.found}/{self.total} 就绪"
            + (f"；缺 {len(self.missing)} 个" if self.missing else "")
        )
        if self.missing:
            lines.append("　缺失：" + "、".join(self.missing[:8]) + ("…" if len(self.missing) > 8 else ""))

        lines.append("")
        lines.append(f"结论：{self.verdict}")
        for hint in self.hints:
            lines.append(f"  - {hint}")
        return "\n".join(lines)

    def as_dict(self) -> dict[str, Any]:
        return {
            "size": [self.width, self.height],
            "expected": list(self.expected),
            "brightness": round(self.brightness, 3),
            "saturation": round(self.saturation, 3),
            "blank": self.blank,
            "scene": self.scene_name,
            "scene_score": round(self.scene_score, 3),
            "scene_second": round(self.scene_second, 3),
            "scene_confident": self.scene_confident,
            "flow": self.flow_name,
            "found": self.found,
            "total": self.total,
            "missing": self.missing,
            "verdict": self.verdict,
            "hints": self.hints,
        }


def _frame_stats(rgb: np.ndarray) -> tuple[float, float, float]:
    """返回 (亮度 0~1, 饱和度 0~1, 均匀度 0~1)。"""
    small = rgb[::8, ::8, :3].astype(np.float32) / 255.0
    if small.size == 0:
        return 0.0, 0.0, 1.0
    mx = small.max(axis=-1)
    mn = small.min(axis=-1)
    brightness = float(mx.mean())
    saturation = float(np.where(mx > 1e-6, (mx - mn) / np.where(mx > 1e-6, mx, 1.0), 0.0).mean())
    gray = small.mean(axis=-1)
    uniformity = 1.0 - float(min(1.0, gray.std() / 0.25))
    return brightness, saturation, uniformity


def inspect(engine, frame: Frame | None = None) -> ScreenReport:
    """对一帧画面做完整自检。"""
    target = frame if frame is not None else engine.grab()
    cfg = engine.cfg
    report = ScreenReport(width=target.width, height=target.height)

    expected = get_path(cfg, "device.expected_size", [1280, 720]) or [1280, 720]
    try:
        report.expected = (int(expected[0]), int(expected[1]))
    except (TypeError, ValueError, IndexError):
        report.expected = (1280, 720)

    brightness, saturation, uniformity = _frame_stats(target.rgb)
    report.brightness, report.saturation, report.uniformity = brightness, saturation, uniformity
    report.blank = uniformity > 0.93

    # 界面指纹
    try:
        if len(engine.scenes):
            name, score, second = engine.scenes.match_detailed(fingerprint(target))
            report.scene_name = name
            report.scene_score = score
            report.scene_second = second
            report.scene_confident = bool(
                name and engine.scenes.confident(score, second, engine.scene_margin)
            )
            if name and not report.scene_confident:
                report.scene_name = name  # 保留最像的，但标记不可信
    except Exception:  # noqa: BLE001 - 自检不能因为指纹出错而失败
        pass

    # 模板流程（强制走模板，不受界面指纹加速影响）
    try:
        flow, matches, _skip = engine.detect(target, use_scene=False)
    except TypeError:
        flow, matches, _skip = engine.detect(target)
    except Exception:  # noqa: BLE001
        flow, matches = None, {}
    if flow is not None:
        report.flow_name = str(flow.get("name", ""))
        report.flow_templates = sorted(
            ((m.name, float(m.score)) for m in matches.values()), key=lambda kv: -kv[1]
        )

    # 模板库存（只看配置里真正用到的模板）
    required = collect_template_names(cfg)
    report.missing = engine.store.missing(required)
    report.total = len(required)
    report.found = report.total - len(report.missing)

    # 结论与建议
    hints: list[str] = []
    if report.blank:
        if brightness < 0.08:
            report.verdict = "画面几乎全黑：模拟器可能没启动、锁屏了，或游戏还在加载。"
            hints.append("先点「启动模拟器」，等进入游戏画面再检测。")
        elif brightness > 0.92:
            report.verdict = "画面几乎全白：可能停在启动页/白屏加载。"
            hints.append("等几秒再检测，或手动点一下画面。")
        else:
            report.verdict = "画面几乎是纯色：可能被弹窗/遮罩挡住，或分辨率不对。"
            hints.append("保存截图看看实际画面（按钮「保存截图」）。")
    elif report.scene_confident:
        report.verdict = (
            f"可以直接跑：当前是「{report.scene_name}」"
            f"（相似度 {report.scene_score:.2f}）。"
        )
        if report.missing:
            hints.append(f"但还缺 {len(report.missing)} 个必需模板，缺的那几步会走兜底坐标。")
    elif report.flow_name:
        report.verdict = f"模板认出「{report.flow_name}」，但界面指纹还没学过这一屏。"
        hints.append("点「学习当前界面」把它记下来，下次识别会更快。")
        if report.missing:
            hints.append("仍缺：" + "、".join(report.missing[:6]))
    else:
        report.verdict = "没认出这一屏：可能是新界面、加载动画、弹窗，或模板/分辨率不匹配。"
        hints.append("点「模板体检」看每个模板的分数；或先「学习当前界面」建个指纹。")
        if (report.width, report.height) != report.expected:
            hints.append(
                f"画面是 {report.width}x{report.height}，与期望 {report.expected[0]}x{report.expected[1]} 不同，"
                "模板需要按这个分辨率重抓。"
            )
        if report.missing:
            hints.append("当前缺 " + str(len(report.missing)) + " 个模板：" + "、".join(report.missing[:6]))

    if (report.width, report.height) != report.expected and not report.blank and report.flow_name:
        hints.append(
            f"注意：画面 {report.width}x{report.height} 与期望 "
            f"{report.expected[0]}x{report.expected[1]} 不一致，点击坐标按画面尺寸缩放，模板需同分辨率抓取。"
        )

    report.hints = hints
    return report
