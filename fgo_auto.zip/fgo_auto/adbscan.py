"""ADB 与模拟器自动探测。

目标：用户什么都不用填，点「自动检测」就能找到模拟器自带的 adb、连上设备，
并判断哪个设备装了 FGO。

探测来源（按可靠性排序）：
  1. 正在运行的模拟器进程（能确定厂商，优先用同一套 adb，避免 adb 版本冲突）；
  2. 注册表卸载项里的 InstallLocation（能处理装在 D:/E:/F: 的情况）；
  3. 常见安装目录 / 各驱动器的 Program Files；
  4. PATH 里的 adb（作为最后兜底）。

端口来源：厂商 CLI 查询（MuMuManager / BlueStacks 配置）+ 各厂商的端口规律，
连不上再逐个 `adb connect` 试。

所有外部命令都带超时和全局 deadline，探测失败只返回空列表，不抛异常。
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable, Sequence

# 各服的 FGO 包名，用来判断「这个设备能不能用来推图」
FGO_PACKAGES = {
    "com.bilibili.fatego": "国服(B服)",
    "com.tencent.tmgp.fgo": "国服(腾讯包名/多开)",
    "com.aniplex.fategrandorder": "日服",
    "com.aniplex.fategrandorder.en": "美服",
    "com.aniplex.fategrandorder.tw": "台服",
    "com.aniplex.fategrandorder.kr": "韩服",
}

VENDOR_WORDS = (
    "mumu", "netease", "ldplayer", "leidian", "雷电",
    "bluestacks", "nox", "夜神", "memu", "microvirt", "逍遥",
)

ADB_NAMES = ("adb.exe", "adb", "hd-adb.exe", "adb_server.exe")

# 每个厂商的进程名、adb 相对位置提示、默认端口
VENDORS: dict[str, dict] = {
    "mumu": {
        "label": "MuMu 模拟器",
        "processes": ("mumuplayer.exe", "mumunxdevice.exe", "mumuvmmheadless.exe", "mumuplayer12.exe"),
        "adb_hints": ("nx_main\\adb.exe", "shell\\adb.exe", "emulator\\nemu\\vmonitor\\bin\\adb_server.exe"),
        "ports": (16384, 16416, 16448, 7555),
    },
    "ldplayer": {
        "label": "雷电模拟器",
        "processes": ("dnplayer.exe", "ldvboxheadless.exe", "ld9boxheadless.exe"),
        "adb_hints": ("adb.exe",),
        "ports": (5555, 5557, 5559, 5561),
    },
    "bluestacks": {
        "label": "BlueStacks",
        "processes": ("hd-player.exe", "bluestacks.exe"),
        "adb_hints": ("hd-adb.exe",),
        "ports": (5555, 5556, 5565),
    },
    "nox": {
        "label": "夜神模拟器",
        "processes": ("nox.exe", "noxconsole.exe"),
        "adb_hints": ("bin\\adb.exe",),
        "ports": (62001, 62025, 62026),
    },
    "memu": {
        "label": "逍遥模拟器",
        "processes": ("memu.exe", "memuconsole.exe"),
        "adb_hints": ("adb.exe",),
        "ports": (21503, 21513),
    },
}

PRUNE_DIRS = {"vms", "data", "cache", "logs", "node_modules", "products", "__pycache__", "temp"}

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0


# ---------------------------------------------------------------- 数据结构

@dataclass
class Emulator:
    kind: str
    label: str
    install_dir: str
    adb_path: str = ""
    ports: list[int] = field(default_factory=list)
    running: bool = False
    source: str = ""


_last_emulators: list["Emulator"] = []


def last_emulators() -> list["Emulator"]:
    """最近一次 scan() 里发现的模拟器（用于解释「为什么没有设备」）。"""
    return list(_last_emulators)


@dataclass
class Candidate:
    """一个可用的「adb + 设备」组合。"""

    emulator: str
    adb: str
    serial: str = ""
    model: str = ""
    size: str = ""
    has_fgo: bool = False
    fgo_package: str = ""
    running: bool = False
    note: str = ""

    @property
    def ready(self) -> bool:
        return bool(self.adb and self.serial)

    def as_dict(self) -> dict:
        return {
            "emulator": self.emulator,
            "adb": self.adb,
            "serial": self.serial,
            "model": self.model,
            "size": self.size,
            "has_fgo": self.has_fgo,
            "fgo_package": self.fgo_package,
            "running": self.running,
            "note": self.note,
        }


# ---------------------------------------------------------------- 基础工具

from contextlib import contextmanager, suppress


@contextmanager
def _using(runner: Callable[..., tuple[int, str, str]] | None):
    """临时替换模块级 _run（测试注入用）。"""
    global _run
    if runner is None:
        yield
        return
    original = _run
    _run = runner  # type: ignore[assignment]
    try:
        yield
    finally:
        _run = original


def _run(cmd: Sequence[str], timeout: float = 6.0) -> tuple[int, str, str]:
    """跑外部命令，永不抛异常。"""
    try:
        proc = subprocess.run(
            list(cmd),
            capture_output=True,
            timeout=timeout,
            creationflags=_NO_WINDOW,
        )
    except subprocess.TimeoutExpired:
        return -1, "", "timeout"
    except OSError as exc:
        return -2, "", str(exc)
    out = proc.stdout.decode("utf-8", "replace")
    err = proc.stderr.decode("utf-8", "replace")
    return proc.returncode, out, err


def list_process_names() -> set[str]:
    """当前进程名（小写）。tasklist 被安全软件挡住时退回 wmic / PowerShell。"""
    if os.name != "nt":
        return set()

    def parse_tasklist(text: str) -> set[str]:
        names: set[str] = set()
        for line in text.splitlines():
            line = line.strip().strip('"')
            if not line:
                continue
            name = line.split('","')[0].strip('"')
            if name:
                names.add(name.lower())
        return names

    code, out, _ = _run(["tasklist", "/fo", "csv", "/nh"], timeout=8)
    if code == 0 and out.strip():
        return parse_tasklist(out)

    code, out, _ = _run(["wmic", "process", "get", "name"], timeout=10)
    if code == 0 and out.strip():
        names = {line.strip().lower() for line in out.splitlines() if line.strip()}
        names.discard("name")
        if names:
            return names

    code, out, _ = _run(
        ["powershell", "-NoProfile", "-Command", "Get-Process | Select-Object -ExpandProperty Name"],
        timeout=10,
    )
    if code == 0 and out.strip():
        return {line.strip().lower() for line in out.splitlines() if line.strip()}
    return set()


def registry_installs() -> list[tuple[str, str]]:
    """注册表卸载项里的 (显示名, 安装目录)，用于发现装在非 C 盘的模拟器。"""
    if os.name != "nt":
        return []
    try:
        import winreg
    except ImportError:  # pragma: no cover - 非 Windows
        return []
    roots = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
    ]
    found: list[tuple[str, str]] = []
    for hive, path in roots:
        try:
            key = winreg.OpenKey(hive, path)
        except OSError:
            continue
        with key:
            index = 0
            while True:
                try:
                    sub_name = winreg.EnumKey(key, index)
                    index += 1
                except OSError:
                    break
                try:
                    with winreg.OpenKey(key, sub_name) as sub:
                        display = str(winreg.QueryValueEx(sub, "DisplayName")[0])
                        if not _matches_vendor(display):
                            continue
                        try:
                            location = str(winreg.QueryValueEx(sub, "InstallLocation")[0])
                        except OSError:
                            location = ""
                        if location and os.path.isdir(location):
                            found.append((display, location))
                except OSError:
                    continue
    return found


def _matches_vendor(text: str) -> bool:
    low = text.lower()
    return any(word in low for word in VENDOR_WORDS)


def _vendor_of(text: str) -> str | None:
    low = text.lower()
    for kind, info in VENDORS.items():
        if any(p.replace(".exe", "") in low for p in info["processes"]):
            return kind
        if kind in low:
            return kind
    if "netease" in low or "mumu" in low:
        return "mumu"
    if "leidian" in low or "ldplayer" in low:
        return "ldplayer"
    if "夜神" in low or "nox" in low:
        return "nox"
    if "microvirt" in low or "memu" in low:
        return "memu"
    return None


def _iter_drive_roots() -> list[str]:
    roots: list[str] = []
    if os.name != "nt":
        return roots
    try:
        import string

        for letter in string.ascii_uppercase:
            drive = f"{letter}:\\"
            if os.path.exists(drive):
                roots.append(drive)
    except Exception:  # pragma: no cover
        pass
    return roots


def _iter_install_dirs(limit_seconds: float = 0.8) -> list[str]:
    """注册表 + 常见目录 + 各驱动器浅层扫描，返回候选安装目录。"""
    deadline = time.time() + limit_seconds
    dirs: list[str] = []

    def add(path: str) -> None:
        if path and os.path.isdir(path) and path not in dirs:
            dirs.append(path)

    for _name, location in registry_installs():
        add(location)
        # 注册表给的是父目录（例如 ...\Netease），再往下找一层
        try:
            for child in os.listdir(location):
                full = os.path.join(location, child)
                if _matches_vendor(child) and os.path.isdir(full):
                    add(full)
        except OSError:
            pass

    bases: list[str] = []
    for env in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA", "APPDATA"):
        value = os.environ.get(env)
        if value:
            bases.append(value)
    for drive in _iter_drive_roots():
        bases.append(os.path.join(drive, "Program Files"))
        bases.append(os.path.join(drive, "Program Files (x86)"))
        bases.append(drive)

    for base in bases:
        if time.time() > deadline:
            break
        try:
            entries = os.listdir(base)
        except OSError:
            continue
        for name in entries:
            if not _matches_vendor(name):
                continue
            full = os.path.join(base, name)
            if not os.path.isdir(full):
                continue
            add(full)
            # 再下一层：Netease\MuMu 这种
            try:
                for child in os.listdir(full):
                    child_full = os.path.join(full, child)
                    if _matches_vendor(child) and os.path.isdir(child_full):
                        add(child_full)
            except OSError:
                pass
    return dirs


def find_adb_in(root: str, max_depth: int = 5, limit: float = 2.5) -> list[str]:
    """在安装目录里找 adb 可执行文件（广度优先，限制深度和耗时）。"""
    deadline = time.time() + limit
    found: list[str] = []
    queue: list[tuple[str, int]] = [(root, 0)]
    while queue and time.time() < deadline:
        current, depth = queue.pop(0)
        if depth > max_depth:
            continue
        try:
            entries = os.scandir(current)
        except OSError:
            continue
        with entries:
            for entry in entries:
                if time.time() > deadline:
                    break
                try:
                    if entry.is_dir(follow_symlinks=False):
                        if entry.name.lower() in PRUNE_DIRS:
                            continue
                        queue.append((entry.path, depth + 1))
                    elif entry.name.lower() in ADB_NAMES:
                        found.append(entry.path)
                except OSError:
                    continue
    # adb.exe 优先于 adb_server.exe
    found.sort(key=lambda p: (0 if p.lower().endswith("adb.exe") else 1, len(p)))
    return found


def detect_emulators(
    processes: Iterable[str] | None = None,
    installs: Iterable[tuple[str, str]] | None = None,
    deadline: float = 10.0,
) -> list[Emulator]:
    """探测已安装/正在运行的模拟器。"""
    start = time.time()
    procs = {p.lower() for p in (processes if processes is not None else list_process_names())}
    found: dict[str, Emulator] = {}

    def ensure(kind: str, install_dir: str, source: str) -> Emulator:
        key = kind
        emu = found.get(key)
        if emu is None:
            emu = Emulator(
                kind=kind,
                label=VENDORS.get(kind, {}).get("label", kind),
                install_dir=install_dir,
                ports=list(VENDORS.get(kind, {}).get("ports", [])),
                source=source,
            )
            found[key] = emu
        elif not emu.install_dir and install_dir:
            emu.install_dir = install_dir
        return emu

    # 1) 正在运行的进程
    for kind, info in VENDORS.items():
        if any(p in procs for p in info["processes"]):
            emu = ensure(kind, "", "process")
            emu.running = True

    # 2) 注册表 / 常见目录
    dirs = list(installs) if installs is not None else [
        (name, loc) for name, loc in registry_installs()
    ]
    candidates: list[tuple[str, str]] = list(dirs)
    if installs is None:
        for path in _iter_install_dirs(max(1.0, deadline - (time.time() - start))):
            candidates.append((os.path.basename(path), path))

    for name, location in candidates:
        if time.time() - start > deadline:
            break
        kind = _vendor_of(name) or _vendor_of(location)
        if kind is None:
            continue
        emu = ensure(kind, location, "install")
        if not emu.adb_path and location:
            adbs = find_adb_in(location, max_depth=5, limit=1.5)
            if adbs:
                emu.adb_path = adbs[0]

    # 3) 正在运行但没找到安装目录的：从进程路径补
    if os.name == "nt":
        for kind, emu in found.items():
            if emu.adb_path or not emu.running:
                continue
            exe = _process_path(VENDORS[kind]["processes"])
            if exe:
                emu.install_dir = os.path.dirname(exe)
                adbs = find_adb_in(emu.install_dir, max_depth=5, limit=1.5)
                if adbs:
                    emu.adb_path = adbs[0]

    result = [e for e in found.values() if e.adb_path or e.running]
    result.sort(key=lambda e: (not e.running, not e.adb_path, e.label))
    return result


def _process_path(names: Sequence[str]) -> str:
    """取某个进程的可执行文件路径（Windows）。"""
    if os.name != "nt":
        return ""
    script = (
        "$n=@('" + "','".join(n.replace('.exe', '') for n in names) + "');"
        "Get-CimInstance Win32_Process | Where-Object { $n -contains $_.Name.Replace('.exe','') } |"
        " Select-Object -First 1 -ExpandProperty ExecutablePath"
    )
    code, out, _ = _run(["powershell", "-NoProfile", "-Command", script], timeout=8)
    return out.strip().splitlines()[0].strip() if code == 0 and out.strip() else ""


# ---------------------------------------------------------------- 端口

def mumu_ports(mumu_dir: str, index: int = 0, timeout: float = 5.0) -> list[int]:
    """问 MuMuManager 要实例的 adb 端口；拿不到就用公式。"""
    ports: list[int] = []
    manager = os.path.join(mumu_dir, "nx_main", "MuMuManager.exe")
    if not os.path.isfile(manager):
        manager = os.path.join(mumu_dir, "shell", "MuMuManager.exe")
    if os.path.isfile(manager):
        code, out, _ = _run([manager, "info", "-v", str(index)], timeout=timeout)
        if code == 0:
            try:
                data = json.loads(out)
            except json.JSONDecodeError:
                data = {}
            for key in ("adb_port", "port", "adbPort"):
                value = data.get(key) if isinstance(data, dict) else None
                if value:
                    try:
                        ports.append(int(value))
                    except (TypeError, ValueError):
                        pass
            host = data.get("adb_host_ip") if isinstance(data, dict) else None
            if host and not ports:
                port = data.get("adb_port")
                if port:
                    ports.append(int(port))
        code, out, _ = _run([manager, "adb", "-v", str(index)], timeout=timeout)
        if code == 0:
            for match in re.findall(r"127\.0\.0\.1:(\d{2,5})", out):
                ports.append(int(match))
    for i in range(4):
        ports.append(16384 + 32 * i)
    # 去重保序
    seen: set[int] = set()
    unique: list[int] = []
    for port in ports:
        if port not in seen:
            seen.add(port)
            unique.append(port)
    return unique


def bluestacks_ports() -> list[int]:
    """BlueStacks 把自己的 adb 端口写在 bluestacks.conf 里。"""
    ports: list[int] = []
    candidates = [
        Path(os.environ.get("ProgramData", r"C:\ProgramData")) / "BlueStacks_nxt" / "bluestacks.conf",
        Path(os.environ.get("ProgramData", r"C:\ProgramData")) / "BlueStacks" / "bluestacks.conf",
    ]
    for path in candidates:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for match in re.finditer(r"adb_port\s*=\s*\"?(\d{2,5})\"?", text):
            ports.append(int(match.group(1)))
    return ports


def emulator_ports(emu: Emulator) -> list[int]:
    if emu.kind == "mumu" and emu.install_dir:
        return mumu_ports(emu.install_dir)
    if emu.kind == "bluestacks":
        found = bluestacks_ports()
        if found:
            return found
    return list(emu.ports)


# ---------------------------------------------------------------- 设备

def list_devices(adb: str, timeout: float = 8.0) -> list[str]:
    """`adb devices` 里状态为 device 的序列号。"""
    code, out, _ = _run([adb, "devices"], timeout=timeout)
    if code != 0:
        return []
    serials: list[str] = []
    for line in out.splitlines():
        line = line.strip()
        if not line or line.startswith("List of devices") or line.startswith("*"):
            continue
        parts = line.split()
        if len(parts) >= 2 and parts[1] == "device":
            serials.append(parts[0])
    return serials


def connect(adb: str, target: str, timeout: float = 6.0) -> bool:
    code, out, err = _run([adb, "connect", target], timeout=timeout)
    text = (out + err).lower()
    return code == 0 and ("connected" in text or "already" in text)


def device_details(adb: str, serial: str, timeout: float = 8.0) -> dict:
    """设备型号、分辨率、是否装了 FGO。"""
    info: dict = {"model": "", "size": "", "has_fgo": False, "fgo_package": ""}

    code, out, _ = _run([adb, "-s", serial, "shell", "getprop", "ro.product.model"], timeout=timeout)
    if code == 0:
        info["model"] = out.strip()

    code, out, _ = _run([adb, "-s", serial, "shell", "wm", "size"], timeout=timeout)
    if code == 0:
        sizes = re.findall(r"(\d{3,5})x(\d{3,5})", out)
        if sizes:
            info["size"] = f"{sizes[-1][0]}x{sizes[-1][1]}"

    code, out, _ = _run([adb, "-s", serial, "shell", "pm", "list", "packages"], timeout=timeout)
    if code == 0:
        packages = {line.replace("package:", "").strip() for line in out.splitlines()}
        for pkg, label in FGO_PACKAGES.items():
            if pkg in packages:
                info["has_fgo"] = True
                info["fgo_package"] = pkg
                info["fgo_server"] = label
                break
    return info


def scan(
    cfg: dict | None = None,
    *,
    deadline: float = 20.0,
    adb_override: str = "",
    processes: Iterable[str] | None = None,
    installs: Iterable[tuple[str, str]] | None = None,
    runner: Callable[..., tuple[int, str, str]] | None = None,
) -> list[Candidate]:
    """完整探测：找 adb → 连端口 → 取设备信息，按「能直接用」排序。"""
    with suppress(Exception), _using(runner):
        start = time.time()
        adb_candidates: list[str] = []

        def add_adb(path: str) -> None:
            if path and os.path.isfile(path) and path not in adb_candidates:
                adb_candidates.append(path)

        if adb_override:
            add_adb(adb_override)
        for name in ("FGO_ADB",):
            value = os.environ.get(name, "")
            if value:
                add_adb(value)
        which = shutil.which("adb")
        if which:
            add_adb(which)

        raw_procs = list_process_names() if processes is None else set(processes)
        procs_known = bool(raw_procs)
        emulators = detect_emulators(
            processes=raw_procs, installs=installs, deadline=min(10.0, deadline)
        )
        _last_emulators[:] = emulators
        for emu in emulators:
            add_adb(emu.adb_path)

        if not adb_candidates:
            return []

        candidates: list[Candidate] = []
        seen_serials: set[str] = set()
        for adb in adb_candidates:
            if time.time() - start > deadline:
                break
            emu = next((e for e in emulators if e.adb_path == adb), None)
            label = emu.label if emu else "系统 adb"
            running = bool(emu and emu.running)

            serials = list_devices(adb)
            # 只在「模拟器在跑」或「拿不到进程列表」时尝试连端口，
            # 避免没启动时白等十几秒。
            should_probe = bool(emu is not None and (emu.running or not procs_known))
            if not serials and should_probe:
                for port in emulator_ports(emu)[:3]:
                    if time.time() - start > deadline:
                        break
                    target = f"127.0.0.1:{port}"
                    if connect(adb, target, timeout=2.5):
                        serials = list_devices(adb)
                        if serials:
                            break
            for serial in serials:
                if serial in seen_serials:
                    continue
                seen_serials.add(serial)
                details = device_details(adb, serial)
                candidates.append(
                    Candidate(
                        emulator=label,
                        adb=adb,
                        serial=serial,
                        model=details.get("model", ""),
                        size=details.get("size", ""),
                        has_fgo=bool(details.get("has_fgo")),
                        fgo_package=details.get("fgo_package", ""),
                        running=running,
                        note=details.get("fgo_server", ""),
                    )
                )
        # 装了 FGO 的优先，其次正在运行的，再其次有型号信息的
        candidates.sort(key=lambda c: (not c.has_fgo, not c.running, not c.model, c.emulator))
        return candidates
    return []  # 探测永远不该炸：真出异常时返回空列表


def find_adb_binary(deadline: float = 8.0) -> str:
    """只找 adb 可执行文件（不连设备）。"""
    for name in ("FGO_ADB",):
        value = os.environ.get(name, "")
        if value and os.path.isfile(value):
            return value
    which = shutil.which("adb")
    if which:
        return which
    emulators = detect_emulators(deadline=deadline)
    for emu in emulators:
        if emu.adb_path:
            return emu.adb_path
    return ""


def describe(candidates: Sequence[Candidate]) -> str:
    if not candidates:
        return "没有探测到可用的模拟器/设备"
    lines = []
    for c in candidates:
        bits = [c.emulator, c.serial or "(无序列号)"]
        if c.model:
            bits.append(c.model)
        if c.size:
            bits.append(c.size)
        bits.append("已装FGO" if c.has_fgo else "未装FGO")
        if c.running:
            bits.append("运行中")
        lines.append("  - " + " | ".join(bits) + f"\n    adb: {c.adb}")
    return "\n".join(lines)


# ---------------------------------------------------------------- 启动模拟器

LAUNCH_EXES = {
    "mumu": ("MuMuManager.exe", "MuMuPlayer.exe", "MuMuPlayer12.exe"),
    "ldplayer": ("ldconsole.exe", "dnconsole.exe", "dnplayer.exe"),
    "bluestacks": ("HD-Player.exe", "BlueStacks.exe"),
    "nox": ("NoxConsole.exe", "Nox.exe"),
    "memu": ("MEmuConsole.exe", "MEmu.exe"),
}


def find_exe(install_dir: str, names: Sequence[str], max_depth: int = 4) -> str:
    """在安装目录里找指定的可执行文件。"""
    wanted = {n.lower() for n in names}
    if not install_dir or not os.path.isdir(install_dir):
        return ""
    queue: list[tuple[str, int]] = [(install_dir, 0)]
    while queue:
        current, depth = queue.pop(0)
        if depth > max_depth:
            continue
        try:
            entries = os.scandir(current)
        except OSError:
            continue
        with entries:
            for entry in entries:
                try:
                    if entry.is_dir(follow_symlinks=False):
                        if entry.name.lower() in PRUNE_DIRS:
                            continue
                        queue.append((entry.path, depth + 1))
                    elif entry.name.lower() in wanted:
                        return entry.path
                except OSError:
                    continue
    return ""


def bluestacks_instance() -> str:
    """BlueStacks 的实例名（如 Nougat64），从 bluestacks.conf 读。"""
    for base in (r"C:\ProgramData\BlueStacks_nxt", r"C:\ProgramData\BlueStacks"):
        path = os.path.join(base, "bluestacks.conf")
        try:
            text = open(path, "r", encoding="utf-8", errors="replace").read()
        except OSError:
            continue
        match = re.search(r"bst\.instance\.([^.]+)\.status\.adb_port", text)
        if match:
            return match.group(1)
    return ""


def launch_command(emu: "Emulator", index: int = 0) -> list[str]:
    """生成启动模拟器的命令；不认识就返回空列表。"""
    if emu.kind == "mumu":
        manager = find_exe(emu.install_dir, ("MuMuManager.exe",))
        if manager:
            return [manager, "control", "-v", str(index), "launch"]
        player = find_exe(emu.install_dir, ("MuMuPlayer.exe", "MuMuPlayer12.exe"))
        if player:
            return [player, "-v", str(index)]
    elif emu.kind == "ldplayer":
        console = find_exe(emu.install_dir, ("ldconsole.exe", "dnconsole.exe"))
        if console:
            return [console, "launch", "--index", str(index)]
        player = find_exe(emu.install_dir, ("dnplayer.exe",))
        if player:
            return [player, "index:" + str(index)]
    elif emu.kind == "bluestacks":
        player = find_exe(emu.install_dir, ("HD-Player.exe",))
        if player:
            instance = bluestacks_instance()
            return [player, "--instance", instance] if instance else [player]
    elif emu.kind == "nox":
        console = find_exe(emu.install_dir, ("NoxConsole.exe",))
        if console:
            return [console, "launch", "-name:Nox_" + str(index)]
        nox = find_exe(emu.install_dir, ("Nox.exe",))
        if nox:
            return [nox, "-clone:Nox_" + str(index)]
    elif emu.kind == "memu":
        console = find_exe(emu.install_dir, ("MEmuConsole.exe",))
        if console:
            return [console, "launch", "-index", str(index)]
        exe = find_exe(emu.install_dir, ("MEmu.exe",))
        if exe:
            return [exe, "-v", str(index)]
    return []


def launch_emulator(
    emu: "Emulator",
    index: int = 0,
    runner: Callable[..., tuple[int, str, str]] | None = None,
) -> tuple[bool, list[str], str]:
    """启动模拟器，返回 (是否成功, 命令, 说明)。"""
    cmd = launch_command(emu, index)
    if not cmd:
        return False, [], f"{emu.label}：没找到启动器（MuMuManager / ldconsole / HD-Player 等）"
    with _using(runner):
        code, out, err = _run(cmd, timeout=25)
    text = (out + " " + err).strip()
    ok = code == 0
    # MuMuManager 用 JSON 报错，例如 {"errcode": -1, "errmsg": ...}
    if ok and '"errcode"' in text:
        try:
            data = json.loads(text[text.index("{"):])
            if isinstance(data, dict) and int(data.get("errcode", 0)) != 0:
                ok = False
                text = str(data.get("errmsg", text))
        except (ValueError, TypeError):
            pass
    return ok, cmd, (text[:200] or ("已发送启动命令" if ok else "启动失败"))


def wait_for_device(
    adb: str,
    ports: Sequence[int],
    timeout: float = 120.0,
    poll: float = 2.0,
    runner: Callable[..., tuple[int, str, str]] | None = None,
    progress: Callable[[float], None] | None = None,
) -> str:
    """等模拟器启动完成并连上设备，返回序列号（超时返回空串）。"""
    start = time.time()
    deadline = start + timeout
    with _using(runner):
        while time.time() < deadline:
            serials = list_devices(adb)
            if serials:
                return serials[0]
            if ports:
                for port in ports[:4]:
                    target = f"127.0.0.1:{port}"
                    if connect(adb, target, timeout=2.0):
                        serials = list_devices(adb)
                        if serials:
                            return serials[0]
                        break
            if progress is not None:
                progress(time.time() - start)
            if poll > 0:
                time.sleep(poll)
            else:
                break
    return ""


def start_and_connect(
    emu: "Emulator",
    index: int = 0,
    timeout: float = 120.0,
    poll: float = 2.0,
    runner: Callable[..., tuple[int, str, str]] | None = None,
) -> tuple[str, str]:
    """启动模拟器并等它连上，返回 (序列号, 说明)。"""
    ok, cmd, message = launch_emulator(emu, index=index, runner=runner)
    if not ok:
        return "", message
    adb = emu.adb_path or find_adb_binary()
    if not adb:
        return "", "启动命令已发出，但没找到 adb，无法等待设备"
    ports = emulator_ports(emu)
    serial = wait_for_device(adb, ports, timeout=timeout, poll=poll, runner=runner)
    if serial:
        return serial, f"已启动并连接 {serial}"
    return "", f"启动命令已发出（{cmd[-1]}），但 {timeout:.0f} 秒内没等到设备"
