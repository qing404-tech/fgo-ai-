"""动作解释器：把 config.json 里的 actions 列表翻译成设备操作。

支持的动作（都写在流程的 actions 里）::

    {"tap": "t_attack"}                 按模板点击，找不到则用 fallback 坐标
    {"tap_xy": [0.5, 0.55]}             按坐标点击（<=1 视为归一化）
    {"wait": 0.8}                       等待
    {"wait_tpl": {"tpl": "t_ok", "timeout": 8}}
    {"swipe": {"from": [..], "to": [..], "ms": 300}}
    {"tap_until_gone": {"tpl": "t_dialog", "point": "dialog_tap",
                        "interval": 0.45, "max": 400,
                        "until_any": ["t_stage_select"]}}
    {"tap_points_until": {"points": "nav.chapter", "until_any": [...]}}
    {"if": {"tpl": "t_use_apple", "then": [...], "else": [...]}}
    {"repeat": {"times": 3, "actions": [...]}}
    {"call": "battle_attack"}           调用 Python 里的具名策略
    {"log": "文字"}
    {"error": "直接失败并报警"}
    {"back": true}                      按返回键
    {"screenshot": "tag"}               存一张调试截图
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .config import get_path
from .vision import Frame, Match

MAX_WAIT = 600.0
ActionFn = Callable[["Ctx", dict], None]


class ActionError(RuntimeError):
    """动作执行失败（配置错误 / 必需模板缺失）。"""


# ---------------------------------------------------------------- 上下文

@dataclass
class Ctx:
    """一次流程执行期间的上下文，负责把动作映射到当前画面。"""

    engine: Any
    flow: dict
    frame: Frame
    matches: dict[str, Match] = field(default_factory=dict)

    # -- 基础 -----------------------------------------------------

    @property
    def cfg(self) -> dict:
        return self.engine.cfg

    @property
    def device(self):
        return self.engine.device

    def log(self, message: str, level: str = "info") -> None:
        self.engine.log(message, level)

    def sleep(self, seconds: float) -> None:
        seconds = max(0.0, min(float(seconds), MAX_WAIT))
        if seconds:
            self.engine.sleep(seconds)

    def refresh(self) -> Frame:
        self.frame = self.engine.grab()
        self.matches = {}
        return self.frame

    # -- 定位 -----------------------------------------------------

    def find(self, name: str, threshold: float | None = None) -> Match | None:
        if not name:
            return None
        if name in self.matches:
            cached = self.matches[name]
            if cached is None:
                return None
            return cached if threshold is None or cached.score >= threshold else None
        m = self.engine.find(self.frame, name, threshold)
        self.matches[name] = m
        return m

    def point(self, spec: Any) -> tuple[int, int]:
        """把坐标配置解析成像素点。"""
        raw = spec
        if isinstance(raw, str):
            raw = get_path(self.cfg, f"params.{raw}")
            if raw is None:
                raise ActionError(f"配置里找不到坐标 params.{spec}")
        if (
            isinstance(raw, (list, tuple))
            and len(raw) >= 1
            and isinstance(raw[0], (list, tuple))
        ):
            raw = raw[0]
        if not isinstance(raw, (list, tuple)) or len(raw) != 2:
            raise ActionError(f"坐标格式不对: {spec!r}")
        x, y = float(raw[0]), float(raw[1])
        width, height = self.device.size
        if abs(x) <= 1.0 and abs(y) <= 1.0:
            x, y = x * width, y * height
        return int(round(x)), int(round(y))

    def points(self, spec: Any) -> list[tuple[int, int]]:
        raw = spec
        if isinstance(raw, str):
            raw = get_path(self.cfg, f"params.{spec}")
            if raw is None:
                raise ActionError(f"配置里找不到坐标列表 params.{spec}")
        if isinstance(raw, (list, tuple)) and raw and not isinstance(raw[0], (list, tuple)):
            raw = [raw]
        if not isinstance(raw, (list, tuple)):
            raise ActionError(f"坐标列表格式不对: {spec!r}")
        return [self.point(p) for p in raw]

    # -- 操作 -----------------------------------------------------

    def tap_point(self, pt: tuple[int, int], jitter: bool | None = None) -> None:
        self.engine.tap(pt[0], pt[1], jitter=jitter)

    def tap_match(self, match: Match, jitter: bool | None = None) -> None:
        self.tap_point(match.center, jitter=jitter)


# ---------------------------------------------------------------- 执行器

def run_actions(ctx: Ctx, actions: Any) -> None:
    for spec in actions or []:
        if not isinstance(spec, dict):
            ctx.log(f"忽略非法动作: {spec!r}", "warn")
            continue
        run_action(ctx, spec)


def run_action(ctx: Ctx, spec: dict) -> None:
    for key, handler in _HANDLERS:
        if key in spec:
            handler(ctx, spec)
            return
    ctx.log(f"未知动作: {spec}", "warn")


# -- 具体动作 -----------------------------------------------------

def _tap(ctx: Ctx, spec: dict) -> None:
    value = spec["tap"]
    if isinstance(value, str):
        opt: dict = {"tpl": value}
    elif isinstance(value, dict):
        opt = dict(value)
    else:
        raise ActionError(f"tap 参数非法: {value!r}")

    tpl_name = opt.get("tpl")
    match = None
    if tpl_name:
        timeout = float(opt.get("timeout", 0) or 0)
        deadline = time.time() + max(0.0, timeout)
        while True:
            match = ctx.find(str(tpl_name))
            if match is not None or time.time() >= deadline:
                break
            ctx.sleep(0.15)
            ctx.refresh()

    if match is not None:
        offset = opt.get("offset")
        if isinstance(offset, (list, tuple)) and len(offset) == 2:
            width, height = ctx.device.size
            scale = width / 1600.0
            point = (
                int(round(match.center[0] + float(offset[0]) * scale)),
                int(round(match.center[1] + float(offset[1]) * scale)),
            )
            point = (max(0, min(point[0], width - 1)), max(0, min(point[1], height - 1)))
            ctx.tap_point(point, jitter=opt.get("jitter"))
            ctx.log(
                f"点击 {tpl_name} 标记 @ {match.center} + 偏移{tuple(offset)} -> {point}"
                f" (score={match.score:.3f})"
            )
        else:
            ctx.tap_match(match, jitter=opt.get("jitter"))
            ctx.log(f"点击 {tpl_name} @ {match.center} (score={match.score:.3f})")
    elif opt.get("fallback"):
        pt = ctx.point(opt["fallback"])
        ctx.tap_point(pt, jitter=opt.get("jitter"))
        ctx.log(f"模板 {tpl_name} 未命中，使用兜底坐标 {pt}", "warn")
    elif opt.get("required"):
        raise ActionError(f"必需模板未命中: {tpl_name}")
    else:
        ctx.log(f"模板 {tpl_name} 未命中，跳过", "warn")

    if opt.get("wait"):
        ctx.sleep(float(opt["wait"]))


def _tap_xy(ctx: Ctx, spec: dict) -> None:
    value = spec["tap_xy"]
    wait = 0.0
    jitter = None
    if isinstance(value, dict):
        point_spec = value.get("point", value.get("xy"))
        wait = float(value.get("wait", 0) or 0)
        jitter = value.get("jitter")
        if point_spec is None:
            raise ActionError(f"tap_xy 缺少坐标: {value!r}")
    else:
        point_spec = value
    pt = ctx.point(point_spec)
    ctx.tap_point(pt, jitter=jitter)
    if wait:
        ctx.sleep(wait)


def _wait(ctx: Ctx, spec: dict) -> None:
    ctx.sleep(float(spec["wait"]))


def _wait_tpl(ctx: Ctx, spec: dict) -> None:
    value = spec["wait_tpl"]
    if isinstance(value, str):
        value = {"tpl": value}
    name = value.get("tpl")
    timeout = float(value.get("timeout", 10) or 10)
    deadline = time.time() + timeout
    while time.time() < deadline:
        ctx.refresh()
        if ctx.find(name) is not None:
            return
        ctx.sleep(0.25)
    if value.get("required", False):
        raise ActionError(f"等待模板超时: {name}")
    ctx.log(f"等待模板 {name} 超时 {timeout:.1f}s，继续", "warn")


def _swipe(ctx: Ctx, spec: dict) -> None:
    value = spec["swipe"] or {}
    start = ctx.point(value.get("from", [0.5, 0.8]))
    end = ctx.point(value.get("to", [0.5, 0.2]))
    ms = int(value.get("ms", 300))
    ctx.device.swipe(start[0], start[1], end[0], end[1], ms)
    ctx.sleep(0.2)


def _tap_until_gone(ctx: Ctx, spec: dict) -> None:
    value = spec["tap_until_gone"] or {}
    name = value.get("tpl")
    interval = float(value.get("interval", 0.5))
    limit = int(value.get("max", 200))
    until_any = [str(x) for x in (value.get("until_any") or []) if x]
    point_spec = value.get("point")

    for i in range(limit):
        ctx.refresh()
        for other in until_any:
            if ctx.find(other) is not None:
                ctx.log(f"已推进到 {other}，停止连点（{i} 次）")
                return
        match = ctx.find(name)
        if match is None:
            return
        pt = ctx.point(point_spec) if point_spec else match.center
        ctx.tap_point(pt)
        ctx.sleep(interval)
    ctx.log(f"{name} 连点 {limit} 次仍未消失", "warn")


def _tap_points_until(ctx: Ctx, spec: dict) -> None:
    value = spec["tap_points_until"] or {}
    points = ctx.points(value.get("points", []))
    interval = float(value.get("interval", 1.0))
    until_any = [str(x) for x in (value.get("until_any") or []) if x]
    limit = int(value.get("max", len(points)))
    for i, pt in enumerate(points[:limit]):
        ctx.tap_point(pt)
        ctx.log(f"尝试坐标 {pt} ({i + 1}/{limit})")
        ctx.sleep(interval)
        ctx.refresh()
        for other in until_any:
            if ctx.find(other) is not None:
                return
    if until_any:
        ctx.log(f"尝试了 {limit} 个坐标，仍未出现 {until_any}", "warn")


def _if(ctx: Ctx, spec: dict) -> None:
    value = spec["if"] or {}
    tpl = value.get("tpl")
    threshold = value.get("min_score")
    hit = ctx.find(str(tpl), float(threshold) if threshold else None) is not None
    run_actions(ctx, value.get("then" if hit else "else", []))


def _repeat(ctx: Ctx, spec: dict) -> None:
    value = spec["repeat"] or {}
    times = int(value.get("times", 1))
    for _ in range(max(0, times)):
        run_actions(ctx, value.get("actions", []))
        delay = float(value.get("interval", 0) or 0)
        if delay:
            ctx.sleep(delay)


def _call(ctx: Ctx, spec: dict) -> None:
    name = spec.get("call")
    fn = CALLS.get(str(name))
    if fn is None:
        raise ActionError(f"未知策略调用: {name}（已注册: {', '.join(sorted(CALLS))}）")
    fn(ctx, spec)


def _log(ctx: Ctx, spec: dict) -> None:
    ctx.log(str(spec.get("log", "")))


def _error(ctx: Ctx, spec: dict) -> None:
    raise ActionError(str(spec.get("error", "流程主动报错")))


def _back(ctx: Ctx, spec: dict) -> None:
    ctx.device.key(4)
    ctx.sleep(0.6)


def _screenshot(ctx: Ctx, spec: dict) -> None:
    ctx.engine.save_debug(ctx.frame, f"manual_{spec['screenshot']}")


_HANDLERS: list[tuple[str, ActionFn]] = [
    ("tap", _tap),
    ("tap_xy", _tap_xy),
    ("tap_until_gone", _tap_until_gone),
    ("tap_points_until", _tap_points_until),
    ("wait_tpl", _wait_tpl),
    ("wait", _wait),
    ("swipe", _swipe),
    ("if", _if),
    ("repeat", _repeat),
    ("call", _call),
    ("log", _log),
    ("error", _error),
    ("back", _back),
    ("screenshot", _screenshot),
]


# ---------------------------------------------------------------- 业务策略

def skip_story(ctx: Ctx, spec: dict | None = None) -> None:
    """一键跳过剧情：点「跳过」→ 点「是」，循环到剧情结束。

    以前靠两个独立流程（跳过 / 跳过确认）接力，容易「刚点完跳过又把确认框点掉」。
    合成一个原子动作后，每轮先看确认框、再点跳过，不会互相打断。
    """
    from .config import get_path

    limit = int(get_path(ctx.cfg, "runtime.skip_limit", 80) or 80)
    interval = float(get_path(ctx.cfg, "runtime.skip_interval", 0.55) or 0.55)
    taps = 0
    for _ in range(limit):
        ctx.refresh()
        confirm = ctx.find("t_skip_confirm")
        if confirm is not None:
            ctx.tap_point(confirm.center)
            ctx.sleep(interval)
            taps += 1
            continue
        skip = ctx.find("t_skip")
        if skip is None:
            ctx.log(f"剧情已跳过（点击 {taps} 次）")
            return
        ctx.tap_point(skip.center)
        ctx.sleep(interval)
        taps += 1
    ctx.log(f"跳过剧情达到上限 {limit} 次，可能仍在剧情中", "warn")


def use_apple(ctx: Ctx, spec: dict | None = None) -> None:
    """AP 不足时按 ap.apple_order 依次尝试吃苹果。"""
    cfg = ctx.cfg.get("ap") or {}
    report = getattr(ctx.engine, "report", None)
    used = int(report.counters.get("apple", 0)) if report is not None else 0
    limit = int(cfg.get("max_per_run") or 0)
    if limit and used >= limit:
        raise ActionError(f"本次运行已吃 {used} 个苹果，达到上限 {limit}")

    # 有些 UI 先要点「使用苹果 / 恢复 AP」入口，再选苹果种类
    entry = ctx.find("t_use_apple")
    if entry is not None:
        ctx.tap_match(entry)
        ctx.sleep(1.2)
        ctx.refresh()

    order = [str(x) for x in (cfg.get("apple_order") or ["gold", "silver", "bronze", "quartz"])]
    points = cfg.get("apple_points") or {}
    ap_values = cfg.get("apple_ap") or {}

    for kind in order:
        match = ctx.find(f"t_apple_{kind}")
        if match is not None:
            ctx.tap_match(match)
            _finish_apple(ctx, kind, ap_values)
            return

    for kind in order:
        point = points.get(kind)
        if point:
            ctx.tap_point(ctx.point(point))
            _finish_apple(ctx, kind, ap_values)
            return

    # 一个苹果都没有：如果配置了等待 AP，就挂机等一会儿再重试
    wait_seconds = int(float((ctx.cfg.get("ap") or {}).get("wait_seconds", 0) or 0))
    if wait_seconds > 0:
        wait_seconds = min(wait_seconds, 1800)
        ctx.log(f"没有可用苹果，等待 AP 回复 {wait_seconds}s", "warn")
        ctx.sleep(float(wait_seconds))
        return

    # 兜底：入口已经点过（弹窗里通常默认选中可用的苹果），直接确认
    if entry is not None:
        _finish_apple(ctx, order[0] if order else "gold", ap_values)
        return
    raise ActionError(
        "AP 不足：没有可用苹果。请抓 t_apple_gold / t_apple_silver 等模板，"
        "或在 config.json 的 ap.apple_points 里配置坐标。"
    )


def _finish_apple(ctx: Ctx, kind: str, ap_values: dict) -> None:
    ctx.sleep(1.0)
    ctx.refresh()
    confirm = ctx.find("t_confirm_ok")
    if confirm is not None:
        ctx.tap_match(confirm)
    else:
        ctx.tap_point(ctx.point("popup_ok"))
    ctx.sleep(1.0)
    report = getattr(ctx.engine, "report", None)
    if report is not None:
        report.apple(kind=kind, ap=int((ap_values or {}).get(kind, 0) or 0))
    ctx.log(f"吃了一个苹果（{kind}）")


def pick_node(ctx: Ctx, spec: dict | None = None) -> None:
    """关卡列表里选关：story 打新关卡，farm 反复打同一个关卡。"""
    ctx.engine.battle_turn = 0  # 回到关卡列表 = 上一场战斗彻底结束
    loop = ctx.cfg.get("loop") or {}
    if str(loop.get("mode", "story")).lower() == "farm":
        tpl = loop.get("farm_node_tpl")
        match = ctx.find(str(tpl)) if tpl else None
        if match is not None:
            ctx.tap_match(match)
            ctx.log("刷本模式：进入固定关卡")
            return
        point = loop.get("farm_node_point")
        if point:
            ctx.tap_point(ctx.point(point))
            ctx.log("刷本模式：按坐标进入固定关卡")
            return
        ctx.log("刷本模式没有配置 farm_node_tpl / farm_node_point，退回普通节点", "warn")

    match = ctx.find("t_stage_node")
    if match is not None:
        offset = get_path(ctx.cfg, "params.node_offset")
        if isinstance(offset, (list, tuple)) and len(offset) == 2:
            width, height = ctx.device.size
            scale = width / 1600.0
            pt = (
                int(round(match.center[0] + float(offset[0]) * scale)),
                int(round(match.center[1] + float(offset[1]) * scale)),
            )
            pt = (max(0, min(pt[0], width - 1)), max(0, min(pt[1], height - 1)))
            ctx.tap_point(pt)
            ctx.log(f"点关卡节点 @ {match.center} + {tuple(offset)} -> {pt}")
            return
        ctx.tap_match(match)
        ctx.log(f"点关卡节点 @ {match.center}")
        return
    pt = ctx.point("nav.node")
    ctx.tap_point(pt)
    ctx.log(f"点关卡节点（兜底坐标）{pt}")


def record_result(ctx: Ctx, spec: dict | None = None) -> None:
    """结算界面出现一次 = 清了一次本，同时结束本场战斗的回合计数。"""
    report = getattr(ctx.engine, "report", None)
    if report is not None:
        report.result()
    stats = getattr(ctx.engine, "stats", None)
    if isinstance(stats, dict):
        stats["story_clears"] = int(stats.get("story_clears", 0)) + 1
    ctx.engine.battle_turn = 0


# ---------------------------------------------------------------- 策略注册

CALLS: dict[str, Callable[[Ctx, dict], None]] = {}


def register_call(name: str, fn: Callable[[Ctx, dict], None]) -> None:
    CALLS[name] = fn


def load_builtin_calls() -> None:
    """注册内置策略（延迟导入避免循环依赖）。"""
    from . import battle

    register_call("battle_attack", battle.battle_attack)
    register_call("pick_cards", battle.pick_cards)
    register_call("use_skills", battle.use_skills)
    register_call("reset_battle", battle.reset_battle)
    register_call("wait_battle_idle", battle.wait_battle_idle)
    register_call("skip_story", skip_story)
    register_call("use_apple", use_apple)
    register_call("pick_node", pick_node)
    register_call("record_result", record_result)
