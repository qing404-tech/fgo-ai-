"""兼容性检查：找出会往进程里注入的「游戏覆盖层」类软件。

典型是游戏加加（GamePP）、RTSS / MSI Afterburner、Fraps、部分录屏与输入法皮肤。
它们通过 DLL 注入绘制悬浮窗，遇到受限制的进程会创建 IPC 失败并刷错误日志，
严重时直接把宿主进程（例如本程序的 Tk 界面）搞崩。

本模块只做检测与提示，不做任何拦截。
"""

from __future__ import annotations

import ctypes
import os
from ctypes import wintypes

# 命中这些关键字就认为是覆盖层/注入类软件
OVERLAY_HINTS = (
    "gamepp",
    "gameplusplus",
    "gpp_",
    "rtss",
    "afterburner",
    "fraps",
    "nahimic",
    "overlay",
)


def own_modules() -> list[str]:
    """枚举当前进程已加载的模块路径（Windows）。失败返回空列表。"""
    if os.name != "nt":
        return []
    try:
        psapi = ctypes.WinDLL("psapi", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        process = kernel32.GetCurrentProcess()
        needed = wintypes.DWORD(0)
        if not psapi.EnumProcessModules(process, None, 0, ctypes.byref(needed)):
            return []
        count = int(needed.value) // ctypes.sizeof(wintypes.HMODULE)
        if count <= 0:
            return []
        modules = (wintypes.HMODULE * count)()
        if not psapi.EnumProcessModules(
            process, modules, ctypes.sizeof(modules), ctypes.byref(needed)
        ):
            return []
        total = int(needed.value) // ctypes.sizeof(wintypes.HMODULE)
        buffer = ctypes.create_unicode_buffer(1024)
        found: list[str] = []
        for index in range(min(total, count)):
            length = psapi.GetModuleFileNameExW(process, modules[index], buffer, 1024)
            if length:
                found.append(buffer.value)
        return found
    except Exception:  # pragma: no cover - 检测失败不该影响启动
        return []


def _match(text: str) -> bool:
    low = text.lower()
    return any(hint in low for hint in OVERLAY_HINTS)


def detect_overlays() -> list[str]:
    """返回检测到的覆盖层软件名（去重、可读）。"""
    seen: dict[str, None] = {}

    for path in own_modules():
        if _match(path):
            name = os.path.basename(path)
            seen.setdefault(name, None)

    # 已加载模块拿不到时，退回按进程名判断
    if not seen:
        try:
            from .adbscan import list_process_names

            for name in list_process_names():
                if _match(name):
                    seen.setdefault(name, None)
        except Exception:  # pragma: no cover
            pass

    return sorted(seen)


def describe(names: list[str]) -> str:
    if not names:
        return ""
    return (
        "检测到覆盖层软件："
        + "、".join(names)
        + "。它可能注入界面进程、导致闪退或按钮无响应，建议先退出它（或关闭「游戏内覆盖」）。"
    )
