"""设备层：ADB（真机 / 模拟器）与内置 mock 后端的统一接口。"""

from __future__ import annotations

import io
import os
import re
import shutil
import subprocess
import threading
import time
from pathlib import Path

import numpy as np


class DeviceError(RuntimeError):
    """设备相关的可预期错误（连接失败、截图失败等）。"""


# Windows 下不弹出黑框
_NO_WINDOW = 0
if os.name == "nt":  # pragma: no cover
    _NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

# 常见安卓模拟器自带的 adb 位置
_ADB_CANDIDATES = [
    r"C:\Program Files\Netease\MuMuPlayer-12.0\shell\adb.exe",
    r"C:\Program Files\Netease\MuMu Player 12\shell\adb.exe",
    r"C:\Program Files\Netease\MuMuPlayer-12.0\adb.exe",
    r"C:\Program Files\Netease\MuMu\emulator\nemu\vmonitor\bin\adb_server.exe",
    r"D:\Program Files\Netease\MuMuPlayer-12.0\shell\adb.exe",
    r"C:\LDPlayer\LDPlayer9\adb.exe",
    r"D:\LDPlayer\LDPlayer9\adb.exe",
    r"C:\leidian\LDPlayer9\adb.exe",
    r"C:\Program Files\BlueStacks_nxt\HD-Adb.exe",
    r"C:\Program Files (x86)\Nox\bin\adb.exe",
    r"C:\Program Files\Nox\bin\adb.exe",
    r"C:\Program Files (x86)\Microvirt\MEmu\adb.exe",
]

# 常见模拟器的 adb 监听端口
_COMMON_PORTS = ["16384", "16416", "5555", "5556", "62001", "7555", "21503", "5565"]


def parse_surface_displays(text: str) -> dict[str, dict]:
    """解析 `dumpsys SurfaceFlinger`，得到 {display_uid: {"layers": set, "active": bool}}。

    MuMu 会同时存在多个虚拟屏（mumuscreen000/002/003/004），默认 `screencap`
    抓的是 0 号屏（安卓桌面），游戏画面在另一个屏上。只能靠图层名判断哪个屏是游戏。
    """
    result: dict[str, dict] = {}
    for block in re.split(r"\nDisplay ", text):
        match = re.match(r"(\d{6,})\s*\(([^)]*)\)", block)
        if not match:
            continue
        uid = match.group(1)
        payload = block.split("\n", 1)[1] if "\n" in block else ""
        layers = set(re.findall(r"([A-Za-z][\w\.]*)/[\w\.$]+#\d+", payload))
        entry = result.setdefault(uid, {"layers": set(), "active": False, "port": ""})
        entry["layers"] |= layers
        if "(active)" in block[:120]:
            entry["active"] = True
        if not entry["port"]:
            port = re.search(r"HWC display (\d+)", match.group(2))
            entry["port"] = port.group(1) if port else ""
    return result


LAUNCHER_HINTS = ("launcher", "lawnchair", "nexuslauncher", "trebuchet")


def pick_game_displays(displays: dict[str, dict], packages: tuple[str, ...]) -> list[str]:
    """挑出「图层里含游戏包名」的显示器，按命中图层数从多到少排序。

    桌面屏（launcher/lawnchair）直接排除——MuMu 默认抓的就是它。
    """
    hits: list[tuple[int, str]] = []
    for uid, info in displays.items():
        layers = info.get("layers") or set()
        if any(any(hint in layer.lower() for hint in LAUNCHER_HINTS) for layer in layers):
            continue
        count = 0
        for layer in layers:
            low = layer.lower()
            if any(pkg.lower() in low for pkg in packages) or "fatego" in low:
                count += 1
        if count:
            hits.append((count, uid))
    hits.sort(reverse=True)
    return [uid for _, uid in hits]


_IMAGE_MAGICS = (b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff")
_PREFIX_SEARCH = 4096


def split_image_bytes(raw: bytes) -> tuple[bytes, str]:
    """剥掉截图前的噪声文本，返回 (图像字节, 前缀文本)。

    MuMu 等模拟器的 adb 会把告警打到 **stdout**，例如：
        [Warning] Multiple displays were found, but no display id was specified!
    它出现在 PNG 头之前，直接按 \x89PNG 判断就会误判成"截图无效"。
    """
    head = raw[:_PREFIX_SEARCH]
    for magic in _IMAGE_MAGICS:
        index = head.find(magic)
        if index >= 0:
            return raw[index:], raw[:index].decode("utf-8", "replace")
    return raw, ""


# ---------------------------------------------------------------- 基类

class Device:
    """设备接口。坐标一律使用上层像素坐标。"""

    width: int = 1280
    height: int = 720
    name: str = "device"

    @property
    def size(self) -> tuple[int, int]:
        return self.width, self.height

    def screenshot(self) -> np.ndarray:
        raise NotImplementedError

    def tap(self, x: int, y: int) -> None:
        raise NotImplementedError

    def swipe(self, x1: int, y1: int, x2: int, y2: int, ms: int = 300) -> None:
        raise NotImplementedError

    def key(self, code: int = 4) -> None:
        raise NotImplementedError

    def close(self) -> None:
        pass


# ---------------------------------------------------------------- ADB

def find_adb(explicit: str | Path | None = None) -> str:
    """按 显式指定 -> FGO_ADB -> PATH -> 模拟器安装目录 的顺序找 adb。"""
    if explicit:
        p = Path(explicit)
        if p.is_file():
            return str(p)
        found = shutil.which(str(explicit))
        if found:
            return found
        raise DeviceError(f"找不到指定的 adb: {explicit}")

    env = os.environ.get("FGO_ADB", "").strip()
    if env and Path(env).is_file():
        return env

    for key in ("ANDROID_HOME", "ANDROID_SDK_ROOT"):
        root = os.environ.get(key, "").strip()
        if root:
            cand = Path(root) / "platform-tools" / ("adb.exe" if os.name == "nt" else "adb")
            if cand.is_file():
                return str(cand)

    found = shutil.which("adb")
    if found:
        return found

    # 注册表 / 常见安装目录 / 各驱动器扫描（能处理装在 D:/E:/F: 的模拟器）
    try:
        from .adbscan import find_adb_binary

        detected = find_adb_binary()
        if detected:
            return detected
    except Exception:  # pragma: no cover - 探测失败就走固定候选
        pass

    for cand in _ADB_CANDIDATES:
        if Path(cand).is_file():
            return cand

    raise DeviceError(
        "没找到 adb。请任选一种方式解决：\n"
        "  1) 启动模拟器后点界面上的「自动检测」，会自动找模拟器自带的 adb；\n"
        "  2) 安装 Android Platform-Tools 并加入 PATH；\n"
        "  3) 在配置 device.adb_path 里填入 adb.exe 的完整路径。"
    )


class AdbDevice(Device):
    """通过 adb 控制安卓设备/模拟器。"""

    def __init__(
        self,
        adb_path: str | None = None,
        serial: str = "",
        connect: str = "",
        screenshot_timeout: float = 15.0,
        auto_detect: bool = True,
        detect_timeout: float = 20.0,
        auto_display: bool = True,
        display_id: str = "",
    ):
        self.serial = (serial or "").strip()
        self.connect_target = (connect or "").strip()
        self.screenshot_timeout = screenshot_timeout
        self._lock = threading.RLock()
        self._use_exec_out = True
        self.name = "adb"
        self.detected: dict | None = None
        self.size_source = "wm_size"
        self.last_prefix = ""
        # 多显示器（MuMu 等）：自动挑含游戏图层的那个屏
        self.auto_display = bool(auto_display)
        self.display_id = str(display_id or "").strip()
        self.display_uid = self.display_id
        self.display_port = ""
        self.display_ts = 0.0
        self.display_ttl = 45.0
        self.display_note = ""
        self.input_display = ""
        self._launcher_sig = None
        self._bad_displays: set[str] = set()
        self.size_note = ""
        self._size_synced = False
        self.adb = ""

        # 没填 adb 路径/序列号时，先自动探测一次模拟器
        if auto_detect and not adb_path and not self.serial and not self.connect_target:
            self._auto_detect(detect_timeout)
        if not self.adb:
            self.adb = find_adb(adb_path)
        self._prepare()

    # -- 底层调用 -------------------------------------------------

    def _run(self, args: list[str], timeout: float = 20.0) -> bytes:
        cmd = [self.adb]
        if self.serial:
            cmd += ["-s", self.serial]
        cmd += args
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                timeout=timeout,
                creationflags=_NO_WINDOW,
            )
        except subprocess.TimeoutExpired as exc:
            raise DeviceError(f"adb 命令超时: {' '.join(args)}") from exc
        except OSError as exc:
            raise DeviceError(f"无法执行 adb: {exc}") from exc
        if proc.returncode != 0:
            err = proc.stderr.decode("utf-8", "replace").strip()
            raise DeviceError(f"adb 失败 ({proc.returncode}): {' '.join(args)}\n{err}")
        return proc.stdout

    # -- 初始化 ---------------------------------------------------

    def _auto_detect(self, timeout: float) -> None:
        """自动找模拟器自带的 adb 和已连接的设备。"""
        try:
            from .adbscan import scan

            candidates = scan(deadline=timeout)
        except Exception:  # pragma: no cover - 探测失败不影响手动配置
            return
        ready = [c for c in candidates if c.ready]
        if not ready:
            return
        best = ready[0]
        self.adb = best.adb
        if not self.serial:
            self.serial = best.serial
        self.detected = best.as_dict()

    def _prepare(self) -> None:
        if self.connect_target:
            try:
                self._run(["connect", self.connect_target], timeout=10)
            except DeviceError:
                pass  # 可能已经连上了
        if not self.serial:
            devices = list_devices(self.adb)
            online = [d for d in devices if d[1] == "device"]
            if online:
                self.serial = online[0][0]
            else:
                self.serial = self._try_connect_ports()
        if not self.serial:
            raise DeviceError(
                "没有可用的安卓设备。请先启动模拟器，并在模拟器设置里打开"
                "「ADB 调试 / 本地连接」，或在配置里填 device.connect（例如 127.0.0.1:16384）。"
            )
        self.name = f"adb:{self.serial}"
        state = dict(list_devices(self.adb)).get(self.serial)
        if state != "device":
            raise DeviceError(
                f"设备 {self.serial} 状态为 {state or '未连接'}，请确认模拟器已完全启动。"
            )
        self.width, self.height = self._query_size()

    def _try_connect_ports(self) -> str:
        for port in _COMMON_PORTS:
            target = f"127.0.0.1:{port}"
            try:
                out = self._run(["connect", target], timeout=6)
            except DeviceError:
                continue
            text = out.decode("utf-8", "replace").lower()
            if "connected" in text or "already" in text:
                # 校验确实出现在设备列表里
                time.sleep(0.3)
                for serial, state in list_devices(self.adb):
                    if serial == target and state == "device":
                        return target
        return ""

    def _query_size(self) -> tuple[int, int]:
        try:
            out = self._run(["shell", "wm", "size"], timeout=10)
        except DeviceError:
            return 1280, 720
        text = out.decode("utf-8", "replace")
        sizes: list[tuple[int, int]] = []
        for line in text.splitlines():
            if ":" in line:
                payload = line.split(":", 1)[1].strip()
                if "x" in payload:
                    try:
                        w, h = payload.split("x")[:2]
                        sizes.append((int(w), int(h)))
                    except ValueError:
                        continue
        if not sizes:
            return 1280, 720
        return sizes[-1]  # Override size 在最后一行，优先使用

    # -- 设备操作 -------------------------------------------------

    def screenshot(self) -> np.ndarray:
        from PIL import Image

        with self._lock:
            last_err: Exception | None = None
            for attempt in range(3):
                self._ensure_display()
                try:
                    raw = self._capture()
                    rgb, prefix = self._decode_image(raw)
                    if rgb is not None:
                        self._bad_set().clear()
                        self._sync_size(rgb.shape[1], rgb.shape[0])
                        if self.display_uid and self._looks_like_launcher(rgb):
                            # 游戏切屏了（MuMu 会让游戏换虚拟屏），拉黑该屏并立刻重选
                            self._bad_set().add(self.display_uid)
                            self.display_uid = ""
                            self.display_ts = 0.0
                            self.input_display = ""
                            continue
                        if self.display_uid and self._looks_blank(rgb):
                            # 选错屏（黑屏/白屏）→ 拉黑该屏并下次重新挑
                            self._bad_set().add(self.display_uid)
                            self.display_uid = ""
                            self.display_ts = 0.0
                            self.input_display = ""
                            continue
                        return rgb
                    detail = f"（前置输出: {prefix.strip()[:80]}）" if prefix.strip() else ""
                    last_err = DeviceError(f"截图数据不是有效图片{detail}")
                    if self.display_uid:
                        # 该屏可能已销毁，退回默认屏重试
                        self.display_uid = ""
                        self.display_ts = 0.0
                except (DeviceError, OSError) as exc:
                    last_err = exc
                time.sleep(0.2)
            raise DeviceError(f"截图失败: {last_err}")

    def _decode_image(self, raw: bytes) -> tuple[np.ndarray | None, str]:
        from PIL import Image

        data, prefix = split_image_bytes(raw)
        if prefix.strip():
            self.last_prefix = prefix.strip()[:200]
        if data[:8] == b"\x89PNG\r\n\x1a\n" or data[:3] == b"\xff\xd8\xff":
            img = Image.open(io.BytesIO(data))
            return np.asarray(img.convert("RGB"), dtype=np.uint8), prefix
        return None, prefix

    def _looks_like_launcher(self, rgb: np.ndarray) -> bool:
        """抓到的是不是安卓桌面（说明游戏已经换屏了）。"""
        sig = getattr(self, "_launcher_sig", None)
        if sig is None:
            return False
        cur = np.asarray(rgb[::16, ::16, :3], dtype=np.int16)
        if cur.shape != sig.shape:
            return False
        return float(np.abs(cur - sig).mean()) < 3.0

    @staticmethod
    def _looks_blank(rgb: np.ndarray) -> bool:
        small = np.asarray(rgb[::8, ::8], dtype=np.float32)
        return float(small.mean(axis=2).std()) < 1.5

    # -- 多显示器选择 ---------------------------------------------

    def _ensure_display(self) -> None:
        """确定要抓哪个显示器（显式配置优先，其次自动挑选，缓存一段时间）。"""
        if getattr(self, "display_id", ""):
            self.display_uid = self.display_id
            return
        if not getattr(self, "auto_display", False):
            self.display_uid = ""
            return
        if self.display_uid and (time.time() - getattr(self, "display_ts", 0)) < getattr(
            self, "display_ttl", 45
        ):
            return
        self._resolve_display()

    def _resolve_display(self) -> None:
        """找「图层里含游戏包名」的屏；多个就挑内容最丰富的那个。"""
        try:
            self._resolve_display_inner()
        except Exception:  # noqa: BLE001 - 选屏失败就退回默认屏，不能影响截图
            self.display_uid = ""
            self.display_port = ""
            self.display_ts = time.time()

    def _resolve_display_inner(self) -> None:
        self.display_ts = time.time()
        try:
            from .adbscan import FGO_PACKAGES

            text = self._run(["shell", "dumpsys", "SurfaceFlinger"], timeout=25).decode(
                "utf-8", "replace"
            )
        except (DeviceError, OSError):
            return
        displays = parse_surface_displays(text)
        candidates = pick_game_displays(displays, tuple(FGO_PACKAGES))
        if not candidates:
            self.display_uid = ""
            self.display_port = ""
            return
        for uid, info in displays.items():
            layers = info.get("layers") or set()
            if any(any(h in layer.lower() for h in LAUNCHER_HINTS) for layer in layers):
                desktop, _ = self._decode_image(self._capture(uid))
                if desktop is not None:
                    self._launcher_sig = np.asarray(desktop[::16, ::16, :3], dtype=np.int16)
                break

        best_uid, best_score, best_layer = "", -1.0, ""
        for uid in candidates[:4]:
            if uid in self._bad_set():
                continue
            rgb, _ = self._decode_image(self._capture(uid))
            if rgb is None:
                continue
            score = float(np.asarray(rgb[::8, ::8], dtype=np.float32).mean(axis=2).std())
            if score > best_score:
                layers = displays.get(uid, {}).get("layers") or set()
                best_uid, best_score = uid, score
                best_layer = next(iter(layers), "")
        # 全都很素（黑屏/白屏/loading）就不要乱切，退回默认屏
        if best_score >= 3.0:
            self.display_uid = best_uid
            info = displays.get(best_uid, {})
            self.display_port = str(info.get("port", ""))
            self.display_note = f"port={self.display_port} 图层={best_layer} 细节={best_score:.1f}"
            self.size_source = "screenshot"
            self._resolve_input_display()
        else:
            self.display_uid = ""
            self.display_port = ""
            self.display_note = f"未找到游戏屏（最高细节 {best_score:.1f}），用默认屏"

    def _bad_set(self) -> set[str]:
        """被判为「抓错屏」的显示器集合（容忍部分构造的对象）。"""
        bad = getattr(self, "_bad_displays", None)
        if bad is None:
            bad = set()
            self._bad_displays = bad
        return bad

    def _ensure_input_display(self) -> None:
        if self.display_uid and not self.input_display:
            self._resolve_input_display()

    def _resolve_input_display(self) -> None:
        """把截图用的 display uid 映射到 `input -d` 需要的逻辑 displayId。

        MuMu 的每个虚拟屏都有独立的触摸 viewport，`input` 默认注入 0 号屏（桌面），
        必须带 `-d <displayId>` 才能点到游戏。id 来自 `dumpsys input` 的 viewport 行。
        """
        self.input_display = ""
        if not self.display_uid:
            return
        try:
            text = self._run(["shell", "dumpsys", "input"], timeout=25).decode("utf-8", "replace")
        except (DeviceError, OSError):
            return
        for match in re.finditer(r"displayId=(\d+),\s*uniqueId=local:(\d+)", text):
            if match.group(2) == self.display_uid:
                self.input_display = match.group(1)
                return

    def _input_args(self, *args: str) -> list[str]:
        cmd = ["shell", "input"]
        if self.input_display:
            cmd += ["-d", self.input_display]
        cmd += list(args)
        return cmd

    def _capture(self, display_uid: str | None = None) -> bytes:
        """截图；display_uid 为空字符串表示用默认屏。"""
        uid = self.display_uid if display_uid is None else display_uid
        extra = ["-d", uid] if uid else []
        timeout = getattr(self, "screenshot_timeout", 15.0)
        if self._use_exec_out:
            try:
                return self._run(["exec-out", "screencap", "-p"] + extra, timeout=timeout)
            except DeviceError:
                self._use_exec_out = False
        remote = "/sdcard/fgo_auto_screen.png"
        self._run(["shell", "screencap", "-p"] + extra + [remote], timeout=timeout)
        return self._run(["exec-out", "cat", remote], timeout=timeout)

    def _screencap(self) -> bytes:
        return self._capture()

    def _sync_size(self, width: int, height: int) -> None:
        """以截图尺寸为准。

        MuMu 等模拟器在 FGO 横屏运行时，`wm size` 仍可能回报竖屏（如 900x1600），
        而截图是 1600x900。坐标按截图裁剪，否则点击会被夹到错误范围。
        """
        if (width, height) == (self.width, self.height) or width <= 1 or height <= 1:
            return
        self.width, self.height = int(width), int(height)
        if not self._size_synced:
            self._size_synced = True
            self.size_source = "screenshot"
            self.size_note = f"画面 {width}x{height} 与 wm size 不同，已按画面校准"

    def tap(self, x: int, y: int) -> None:
        x = max(0, min(int(x), self.width - 1))
        y = max(0, min(int(y), self.height - 1))
        self._ensure_input_display()
        with self._lock:
            self._run(self._input_args("tap", str(x), str(y)), timeout=10)

    def swipe(self, x1: int, y1: int, x2: int, y2: int, ms: int = 300) -> None:
        with self._lock:
            self._run(
                self._input_args(
                    "swipe",
                    str(int(x1)), str(int(y1)), str(int(x2)), str(int(y2)), str(int(ms)),
                ),
                timeout=15,
            )

    def key(self, code: int = 4) -> None:
        self._ensure_input_display()
        with self._lock:
            self._run(self._input_args("keyevent", str(int(code))), timeout=10)

    def info(self) -> dict:
        data = {
            "backend": "adb",
            "adb": self.adb,
            "serial": self.serial,
            "size": [self.width, self.height],
        }
        if self.detected:
            data["auto_detected"] = self.detected
        data["size_source"] = self.size_source
        if self.last_prefix:
            data["screenshot_note"] = self.last_prefix
        data["display"] = self.display_port or ("default" if not self.display_uid else self.display_uid)
        if self.display_note:
            data["display_note"] = self.display_note
        if self.input_display:
            data["input_display"] = self.input_display
        if self.size_note:
            data["size_note"] = self.size_note
        return data


def list_devices(adb_path: str) -> list[tuple[str, str]]:
    """返回 [(serial, state)]，state 通常是 device / offline / unauthorized。"""
    try:
        proc = subprocess.run(
            [adb_path, "devices"],
            capture_output=True,
            timeout=15,
            creationflags=_NO_WINDOW,
        )
    except (subprocess.TimeoutExpired, OSError) as exc:
        raise DeviceError(f"执行 adb devices 失败: {exc}") from exc
    text = proc.stdout.decode("utf-8", "replace")
    out: list[tuple[str, str]] = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("List of devices") or line.startswith("*"):
            continue
        parts = line.split()
        if len(parts) >= 2:
            out.append((parts[0], parts[1]))
    return out


# ---------------------------------------------------------------- 工厂

def create_device(cfg: dict) -> Device:
    backend = str((cfg.get("device") or {}).get("backend", "adb")).lower()
    if backend == "mock":
        from .fakegame import MockDevice

        return MockDevice(cfg)
    dev = cfg.get("device") or {}
    return AdbDevice(
        adb_path=(dev.get("adb_path") or "").strip() or None,
        serial=(dev.get("serial") or "").strip(),
        connect=(dev.get("connect") or "").strip(),
        auto_detect=bool(dev.get("auto_detect", True)),
        detect_timeout=float(dev.get("detect_timeout", 20) or 20),
        auto_display=bool(dev.get("auto_display", True)),
        display_id=str(dev.get("display_id", "") or ""),
    )
