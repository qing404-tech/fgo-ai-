"""Tkinter 图形界面：实时画面、模板抓取、坐标拾取、日志与流程统计。"""

from __future__ import annotations

import logging
import queue
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk
from typing import Any

import numpy as np

from . import __version__, theme
from .config import ensure_config_file, get_path, load_config, save_config, template_dir
from .engine import Engine, configure_logging
from .templates import template_usage

APP_TITLE = "FGO 主线自动推进器"
BASE_DIR = Path(__file__).resolve().parents[1]
CONFIG_NAME = "config.json"
BACKENDS = {"Mock 演示（无需游戏）": "mock", "ADB 真机 / 模拟器": "adb"}
BACKEND_NAMES = {v: k for k, v in BACKENDS.items()}
LOG_LIMIT = 4000


class QueueLogHandler(logging.Handler):
    """把日志送进队列，由主线程写入 Text 控件。"""

    def __init__(self, sink: queue.Queue):
        super().__init__()
        self.sink = sink
        self.setFormatter(logging.Formatter("%(asctime)s %(levelname)-5s %(message)s", "%H:%M:%S"))

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.sink.put_nowait(("log", record.levelname, self.format(record)))
        except Exception:  # pragma: no cover
            pass


class App(tk.Tk):
    def __init__(self, base_dir: Path | None = None):
        super().__init__()
        self.base_dir = Path(base_dir) if base_dir else BASE_DIR
        self.config_path = self.base_dir / CONFIG_NAME
        self.templates_root = self.base_dir / "templates"
        ensure_config_file(self.config_path)
        self.cfg = load_config(self.config_path)

        self.log_queue: queue.Queue = queue.Queue()
        self.engine: Engine | None = None
        self._photo: Any = None
        self._frame_rgb: np.ndarray | None = None
        self._snap: dict | None = None
        self._preview_sig: Any = None
        self._img_scale = 1.0
        self._img_off = (0.0, 0.0)
        self._drag_start: tuple[float, float] | None = None
        self._drag_rect: int | None = None
        self._busy = False
        self._probing = False
        self._probe_auto = False
        self.probe_queue: queue.Queue = queue.Queue()
        self._last_stats_ts = 0.0
        self._scene_sig: tuple | None = None

        self.title(f"{APP_TITLE}  v{__version__}")
        # 默认尺寸按「1366x768 / 1536x864 笔记本屏 + 任务栏」能完整显示来定
        self._want_width, self._want_height = 1180, 720
        self.geometry("1180x720")
        self.minsize(960, 620)
        self._setup_style()
        self._build_menu()
        self._build_top()
        self._build_bottom()   # 先占住底部，避免被可伸缩主体挤没
        self._build_body()

        configure_logging(self.base_dir / "logs", logging.INFO)
        logging.getLogger("fgo_auto").addHandler(QueueLogHandler(self.log_queue))
        logging.getLogger("fgo_auto").info(
            "界面已就绪：先「连接设备」，再点「开始」。首次使用请用「抓取模板模式」补齐模板。"
        )
        try:
            from .compat import describe as describe_overlays
            from .compat import detect_overlays

            overlays = detect_overlays()
            if overlays:
                logging.getLogger("fgo_auto").warning(describe_overlays(overlays))
                self._overlays = overlays
        except Exception:  # noqa: BLE001 - 检测失败不影响启动
            pass
        self.after(80, self._enforce_size)
        self.after(150, self._tick)
        self.after(900, self._auto_probe)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------ 界面搭建

    def _setup_style(self) -> None:
        # 明日方舟风格：近黑底 + 细线 + 橙色强调（见 theme.py）
        theme.apply_theme(self)

    def _build_menu(self) -> None:
        menubar = tk.Menu(self)
        file_menu = tk.Menu(menubar, tearoff=False)
        file_menu.add_command(label="保存配置", accelerator="Ctrl+S", command=self._save_config)
        file_menu.add_command(label="重新加载配置", command=self._reload_config)
        file_menu.add_separator()
        file_menu.add_command(label="打开配置目录", command=self._open_dir)
        file_menu.add_command(label="打开日志目录", command=self._open_logs)
        file_menu.add_separator()
        file_menu.add_command(label="退出", command=self._on_close)
        menubar.add_cascade(label="文件", menu=file_menu)

        tools = tk.Menu(menubar, tearoff=False)
        tools.add_command(label="截取当前画面", command=self._on_refresh_frame)
        tools.add_command(label="模板管理器", command=self._open_templates)
        tools.add_command(label="缺失模板清单", command=self._show_missing)
        tools.add_command(label="未知界面记录", command=self._show_unknown_screens)
        tools.add_command(label="模板抓取向导", command=self._show_tpl_wizard)
        tools.add_command(label="模板体检（当前画面跑一遍全部模板）", command=self._check_templates)
        tools.add_command(label="打开模板目录", command=self._open_templates_dir)
        tools.add_separator()
        tools.add_command(label="导入战斗方案…", command=self._import_plan)
        tools.add_command(label="清除战斗方案", command=self._clear_plan)
        tools.add_command(label="运行摘要", command=self._show_report)
        menubar.add_cascade(label="工具", menu=tools)

        help_menu = tk.Menu(menubar, tearoff=False)
        help_menu.add_command(label="使用说明", command=self._show_help)
        help_menu.add_command(label="关于", command=self._show_about)
        menubar.add_cascade(label="帮助", menu=help_menu)
        self.config(menu=menubar)
        self.bind("<Control-s>", lambda _e: self._save_config())

    def _build_top(self) -> None:
        # ---- 标题条（画布，随窗口宽度重绘）----
        self.header = tk.Canvas(
            self, height=72, bg=theme.BG_ALT, highlightthickness=0, bd=0
        )
        self.header.pack(fill="x")
        self.header.bind("<Configure>", self._redraw_header)
        self._header_width = 0

        # ---- 设备行（两行，窄窗口也不溢出）----
        row1 = ttk.Frame(self, padding=(12, 8, 12, 2))
        row1.pack(fill="x")

        ttk.Label(row1, text="BACKEND", style="Label.TLabel").pack(side="left")
        backend = get_path(self.cfg, "device.backend", "adb")
        self.backend_var = tk.StringVar(value=BACKEND_NAMES.get(backend, "ADB 真机 / 模拟器"))
        combo = ttk.Combobox(
            row1, values=list(BACKENDS), textvariable=self.backend_var,
            width=18, state="readonly",
        )
        combo.pack(side="left", padx=(6, 12))
        combo.bind("<<ComboboxSelected>>", lambda _e: self._on_backend_change())

        ttk.Label(row1, text="SERIAL", style="Label.TLabel").pack(side="left")
        self.serial_var = tk.StringVar(value=str(get_path(self.cfg, "device.serial", "")))
        ttk.Entry(row1, textvariable=self.serial_var, width=16).pack(side="left", padx=(6, 12))

        ttk.Button(row1, text="自动检测", command=self._start_probe).pack(side="left", padx=(0, 4))
        ttk.Button(row1, text="启动模拟器", command=self._launch_emulator_clicked).pack(
            side="left", padx=(0, 4)
        )
        self.connect_btn = ttk.Button(row1, text="连接设备", command=self._on_connect)
        self.connect_btn.pack(side="left", padx=(0, 12))

        self.device_label = ttk.Label(row1, text="未连接", style="Accent.TLabel")
        self.device_label.pack(side="left")

        row2 = ttk.Frame(self, padding=(12, 0, 12, 8))
        row2.pack(fill="x")
        ttk.Label(row2, text="ADB", style="Label.TLabel").pack(side="left")
        self.adb_var = tk.StringVar(value=str(get_path(self.cfg, "device.adb_path", "")))
        ttk.Entry(row2, textvariable=self.adb_var).pack(
            side="left", fill="x", expand=True, padx=(6, 6)
        )

    def _enforce_size(self) -> None:
        """Tk 会按内容把窗口撑大；这里把尺寸钉回设定值，避免底部条被顶出屏幕。"""
        try:
            self.geometry(f"{self._want_width}x{self._want_height}")
        except Exception:  # noqa: BLE001
            pass

    def _redraw_header(self, event=None) -> None:
        width = int(getattr(event, "width", 0) or self.winfo_width() or 900)
        if abs(width - getattr(self, "_header_width", 0)) < 4 and event is not None:
            return
        self._header_width = width
        theme.draw_header(
            self.header,
            width,
            int(self.header.cget("height")),
            "主线自动推进器",
            f"AUTO COMMAND SYSTEM  //  v{__version__}",
        )

    def _build_body(self) -> None:
        paned = ttk.PanedWindow(self, orient="horizontal")
        paned.pack(fill="both", expand=True, padx=10, pady=4)

        left = ttk.Frame(paned)
        bar = ttk.Frame(left)
        bar.pack(fill="x", pady=(0, 4))
        ttk.Button(bar, text="检测画面", command=self._inspect_screen).pack(side="left")
        ttk.Button(bar, text="刷新画面", command=self._on_refresh_frame).pack(side="left", padx=(6, 0))
        self.capture_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            bar, text="抓取模板模式（拖框保存）", variable=self.capture_var,
            command=self._on_capture_mode,
        ).pack(side="left", padx=(10, 4))
        self.pick_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            bar, text="坐标拾取（点一下复制归一化坐标）", variable=self.pick_var,
            command=self._on_pick_mode,
        ).pack(side="left", padx=4)
        self.canvas = tk.Canvas(
            left, bg=theme.BG_ALT, highlightthickness=0, bd=0, cursor="crosshair"
        )
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.canvas.bind("<ButtonPress-1>", self._on_canvas_press)
        self.canvas.bind("<B1-Motion>", self._on_canvas_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_canvas_release)
        paned.add(left, weight=3)

        right = ttk.Frame(paned)
        self.flow_label = ttk.Label(
            right, text="当前识别：—", font=theme.font_latin(12, "bold"),
            foreground=theme.ACCENT, background=theme.BG,
        )
        self.flow_label.pack(anchor="w", pady=(0, 4))

        notebook = ttk.Notebook(right)
        notebook.pack(fill="both", expand=True)

        tab_flows = ttk.Frame(notebook)
        self.flow_tree = ttk.Treeview(
            tab_flows, columns=("count",), show="tree headings", height=8
        )
        self.flow_tree.heading("#0", text="流程")
        self.flow_tree.heading("count", text="次数")
        self.flow_tree.column("#0", width=200)
        self.flow_tree.column("count", width=60, anchor="center")
        self.flow_tree.pack(fill="both", expand=True)
        notebook.add(tab_flows, text="流程统计")

        tab_log = ttk.Frame(notebook)
        self.log_text = tk.Text(
            tab_log, height=12, wrap="word", bg=theme.PANEL, fg=theme.TEXT,
            insertbackground=theme.ACCENT, relief="flat", bd=0,
            font=theme.font_mono(9), padx=8, pady=6,
        )
        scroll = ttk.Scrollbar(tab_log, command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        self.log_text.pack(fill="both", expand=True)
        self.log_text.tag_configure("warn", foreground=theme.ACCENT)
        self.log_text.tag_configure("error", foreground=theme.DANGER)
        self.log_text.tag_configure("debug", foreground=theme.MUTED)
        notebook.add(tab_log, text="运行日志")

        # ---- 界面识别 ----
        tab_scene = ttk.Frame(notebook)
        self.scene_label = ttk.Label(
            tab_scene, text="当前界面：—", font=theme.font_latin(10, "bold"),
            foreground=theme.ACCENT, background=theme.BG,
        )
        self.scene_label.pack(anchor="w", padx=8, pady=(8, 2))

        self.scene_auto_var = tk.BooleanVar(
            value=bool(get_path(self.cfg, "scene.auto_learn", True))
        )
        ttk.Checkbutton(
            tab_scene, text="自动学习（模板高置信命中时把该界面记下来）",
            variable=self.scene_auto_var, command=self._toggle_auto_learn,
        ).pack(anchor="w", padx=8)

        body = ttk.Frame(tab_scene)
        body.pack(fill="both", expand=True, padx=8, pady=6)
        self.scene_tree = ttk.Treeview(
            body, columns=("count",), show="tree headings", height=8
        )
        self.scene_tree.heading("#0", text="界面")
        self.scene_tree.heading("count", text="样本")
        self.scene_tree.column("#0", width=190)
        self.scene_tree.column("count", width=60, anchor="center")
        self.scene_tree.pack(side="left", fill="both", expand=True)

        side = ttk.Frame(body)
        side.pack(side="right", fill="y", padx=(6, 0))
        ttk.Button(side, text="学习当前界面", command=self._learn_scene).pack(fill="x", pady=2)
        ttk.Button(side, text="删除选中", command=self._forget_scene).pack(fill="x", pady=2)
        ttk.Button(side, text="清空全部", command=self._clear_scenes).pack(fill="x", pady=2)
        ttk.Button(side, text="保存到磁盘", command=self._save_scenes).pack(fill="x", pady=2)
        notebook.add(tab_scene, text="界面识别")
        paned.add(right, weight=2)

    def _build_bottom(self) -> None:
        frm = ttk.Frame(self, padding=(12, 8, 12, 10))
        frm.pack(side="bottom", fill="x")
        ttk.Frame(self, style="Line.TFrame", height=1).pack(side="bottom", fill="x")

        self.start_btn = ttk.Button(
            frm, text="▶ 开始", style="Accent.TButton", command=self._on_start
        )
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(
            frm, text="■ 停止", style="Danger.TButton", command=self._on_stop, state="disabled"
        )
        self.stop_btn.pack(side="left", padx=8)
        ttk.Button(frm, text="单步", style="Ghost.TButton", command=self._on_step).pack(side="left")
        self.dry_var = tk.BooleanVar(value=bool(get_path(self.cfg, "runtime.dry_run", False)))
        ttk.Checkbutton(frm, text="干跑（只识别不点击）", variable=self.dry_var).pack(
            side="left", padx=(14, 6)
        )
        self.skip_var = tk.BooleanVar(
            value=bool(get_path(self.cfg, "runtime.skip_story", True))
        )
        ttk.Checkbutton(frm, text="跳过剧情", variable=self.skip_var).pack(side="left", padx=(0, 10))
        ttk.Button(
            frm, text="缺失模板", style="Ghost.TButton", command=self._show_missing
        ).pack(side="left", padx=4)

        self.stats_label = ttk.Label(
            frm, text="步数 0　点击 0　战斗 0　苹果 0　未知 0　用时 0s",
            style="Muted.TLabel",
        )
        self.stats_label.pack(side="right")

    # ------------------------------------------------------------ 配置

    def _collect_device_cfg(self) -> None:
        backend = BACKENDS[self.backend_var.get()]
        self.cfg["device"]["backend"] = backend
        self.cfg["device"]["serial"] = self.serial_var.get().strip()
        self.cfg["device"]["adb_path"] = self.adb_var.get().strip()
        self.cfg["runtime"]["dry_run"] = bool(self.dry_var.get())
        self.cfg["runtime"]["skip_story"] = bool(self.skip_var.get())

    def _save_config(self) -> None:
        self._collect_device_cfg()
        try:
            save_config(self.cfg, self.config_path)
            logging.getLogger("fgo_auto").info(f"配置已保存: {self.config_path}")
        except OSError as exc:
            messagebox.showerror("保存失败", str(exc))

    def _reload_config(self) -> None:
        self.cfg = load_config(self.config_path)
        self.backend_var.set(
            BACKEND_NAMES.get(str(get_path(self.cfg, "device.backend", "adb")), "ADB 真机 / 模拟器")
        )
        self.serial_var.set(str(get_path(self.cfg, "device.serial", "")))
        self.adb_var.set(str(get_path(self.cfg, "device.adb_path", "")))
        self.dry_var.set(bool(get_path(self.cfg, "runtime.dry_run", False)))
        if hasattr(self, "skip_var"):
            self.skip_var.set(bool(get_path(self.cfg, "runtime.skip_story", True)))
        logging.getLogger("fgo_auto").info("配置已重新加载（重新连接后生效）")

    # ------------------------------------------------------------ 自动检测

    def _auto_probe(self) -> None:
        """启动后静默探测一次：用户没填序列号、后端是 ADB 时才做。"""
        if BACKENDS[self.backend_var.get()] != "adb":
            return
        if self.serial_var.get().strip() or self.engine is not None:
            return
        self._start_probe(auto=True)

    def _start_probe(self, auto: bool = False) -> None:
        if self._probing:
            return
        self._probing = True
        self._probe_auto = auto
        self.device_label.config(text="正在探测模拟器…", foreground="#b45309")
        self.update_idletasks()

        def work() -> None:
            try:
                from .adbscan import scan as scan_devices

                candidates = [c.as_dict() for c in scan_devices(deadline=15)]
                self.probe_queue.put(("probe", candidates, None))
            except Exception as exc:  # noqa: BLE001 - 探测失败要能看见
                self.probe_queue.put(("probe", [], exc))

        threading.Thread(target=work, daemon=True, name="fgo-probe").start()

    def _drain_probe(self) -> None:
        try:
            kind, payload, extra = self.probe_queue.get_nowait()
        except queue.Empty:
            return

        if kind == "launched":
            self._probing = False
            if payload:
                logging.getLogger("fgo_auto").info(f"模拟器已就绪：{extra}")
                self._start_probe(auto=True)
            else:
                self.device_label.config(text="启动失败", foreground="#b91c1c")
                messagebox.showwarning("启动模拟器失败", str(extra))
            return

        candidates, error = payload, extra
        self._probing = False
        auto = self._probe_auto
        self._probe_auto = False

        if error is not None:
            self.device_label.config(text="探测失败", foreground="#b91c1c")
            if not auto:
                messagebox.showerror("自动检测失败", str(error))
            return
        if not candidates:
            self.device_label.config(text="未探测到设备", foreground="#b45309")
            try:
                from .adbscan import last_emulators

                emus = last_emulators()
            except Exception:  # noqa: BLE001
                emus = []

            # 检测到模拟器但没设备：可以一键拉起
            if emus:
                emu = emus[0]
                if auto and bool(get_path(self.cfg, "device.auto_launch", False)):
                    logging.getLogger("fgo_auto").info(
                        f"检测到 {emu.label} 未启动，按配置自动拉起"
                    )
                    self._start_launch(emu)
                    return
                if not auto and messagebox.askyesno(
                    "启动模拟器",
                    f"检测到 {emu.label}，但它没有在运行。\n现在启动吗？（约 30~90 秒）",
                ):
                    self._start_launch(emu)
                    return

            if not auto:
                hint = (
                    "检测到模拟器：" + "、".join(e.label for e in emus) + "\n"
                    "但它没有提供可用设备（多半是没启动或没开 ADB）。\n\n"
                    if emus
                    else ""
                )
                messagebox.showwarning(
                    "未探测到设备",
                    hint + "请依次检查：\n"
                    "1) 模拟器是否已经启动并进入桌面；\n"
                    "2) 模拟器设置里是否开启了 ADB 调试；\n"
                    "3) 安全软件是否拦截了 adb。\n\n"
                    "也可以点「启动模拟器」自动拉起，或手动填 adb 路径与序列号；\n"
                    "命令行：python -m fgo_auto.cli devices --launch",
                )
            return

        if auto or len(candidates) == 1:
            self._apply_candidate(candidates[0])
        else:
            self._show_candidates(candidates)

    # ------------------------------------------------------------ 启动模拟器

    def _launch_emulator_clicked(self) -> None:
        """手动点「启动模拟器」。"""
        try:
            from .adbscan import last_emulators

            emus = last_emulators()
        except Exception:  # noqa: BLE001
            emus = []
        if not emus:
            messagebox.showinfo(
                "启动模拟器",
                "没有检测到已安装的模拟器。\n"
                "请确认装了 MuMu / 雷电 / BlueStacks / 夜神，或先点「自动检测」。",
            )
            return
        emu = emus[0]
        self._start_launch(emu)

    def _start_launch(self, emu) -> None:
        if self._probing:
            return
        self._probing = True
        wait = int(get_path(self.cfg, "device.launch_wait", 120) or 120)
        index = int(get_path(self.cfg, "device.emulator_index", 0) or 0)
        self.device_label.config(
            text=f"正在启动 {emu.label}，最多等 {wait} 秒…", foreground="#b45309"
        )
        self.update_idletasks()

        def work() -> None:
            try:
                from .adbscan import start_and_connect

                serial, message = start_and_connect(emu, index=index, timeout=wait)
                self.probe_queue.put(("launched", serial, message))
            except Exception as exc:  # noqa: BLE001
                self.probe_queue.put(("launched", "", str(exc)))

        logging.getLogger("fgo_auto").info(f"启动模拟器：{emu.label}")
        threading.Thread(target=work, daemon=True, name="fgo-launch").start()


    def _apply_candidate(self, candidate: dict, connect: bool = True) -> None:
        self.backend_var.set(BACKEND_NAMES["adb"])
        self.cfg["device"]["backend"] = "adb"
        self.serial_var.set(str(candidate.get("serial", "")))
        self.adb_var.set(str(candidate.get("adb", "")))
        state = "已装 FGO" if candidate.get("has_fgo") else "未装 FGO"
        self.device_label.config(
            text=f"{candidate.get('emulator', '模拟器')} · {state}", foreground="#0f766e"
        )
        logging.getLogger("fgo_auto").info(
            "自动检测到 %s  %s  %s  %s"
            % (
                candidate.get("emulator", ""),
                candidate.get("serial", ""),
                candidate.get("size", ""),
                state,
            )
        )
        self._save_config()
        if connect:
            self._on_connect()

    def _show_candidates(self, candidates: list[dict]) -> None:
        win = tk.Toplevel(self)
        win.title("选择要控制的设备")
        win.geometry("760x320")
        win.transient(self)
        tree = ttk.Treeview(
            win,
            columns=("emulator", "serial", "size", "fgo", "adb"),
            show="headings",
            height=8,
        )
        for col, title, width in (
            ("emulator", "模拟器", 130),
            ("serial", "序列号", 150),
            ("size", "分辨率", 90),
            ("fgo", "FGO", 70),
            ("adb", "adb 路径", 300),
        ):
            tree.heading(col, text=title)
            tree.column(col, width=width)
        tree.pack(fill="both", expand=True, padx=8, pady=8)
        for cand in candidates:
            tree.insert(
                "",
                "end",
                values=(
                    cand.get("emulator", ""),
                    cand.get("serial", ""),
                    cand.get("size", ""),
                    "已装" if cand.get("has_fgo") else "未装",
                    cand.get("adb", ""),
                ),
            )

        def use_selected() -> None:
            selection = tree.selection()
            if not selection:
                return
            index = tree.index(selection[0])
            win.destroy()
            self._apply_candidate(candidates[index])

        tree.bind("<Double-1>", lambda _e: use_selected())
        bar = ttk.Frame(win)
        bar.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Button(bar, text="使用选中设备", command=use_selected).pack(side="left")
        ttk.Button(bar, text="取消", command=win.destroy).pack(side="left", padx=6)

    # ------------------------------------------------------------ 画面检测

    def _inspect_screen(self) -> None:
        """截一张图，做完整自检（黑屏/分辨率/界面指纹/模板/缺失）。"""
        if self.engine is None:
            self._on_connect(auto_start=False)
            if self.engine is None:
                return
        if self.engine.is_running or self._busy:
            messagebox.showinfo("检测画面", "请先停止运行，避免和识别抢设备。")
            return
        self._busy = True
        self.update_idletasks()
        try:
            frame = self.engine.grab()
            report = self.engine.inspect_screen(frame)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("检测失败", str(exc))
            return
        finally:
            self._busy = False
        self._show_inspect(report, frame)

    def _show_inspect(self, report, frame) -> None:
        from PIL import Image, ImageTk

        win = tk.Toplevel(self)
        win.title("画面检测")
        win.geometry("900x580")
        win.transient(self)

        bar = ttk.Frame(win, padding=(8, 6))
        bar.pack(side="bottom", fill="x")

        body = ttk.Frame(win)
        body.pack(fill="both", expand=True)

        left = ttk.Frame(body, padding=8)
        left.pack(side="left", fill="y")
        image = Image.fromarray(frame.rgb, mode="RGB")
        image.thumbnail((440, 250))
        photo = ImageTk.PhotoImage(image)
        preview = ttk.Label(left, image=photo, relief="sunken")
        preview.image = photo  # type: ignore[attr-defined]
        preview.pack()
        ttk.Label(
            left,
            text=f"{report.size_text} · 期望 {report.expected[0]}x{report.expected[1]}",
            padding=(0, 6),
        ).pack()

        text = tk.Text(body, wrap="word", width=50, bg="#0f1115", fg="#d7dce5", relief="flat")
        text.pack(side="right", fill="both", expand=True, padx=(0, 8), pady=8)
        text.insert("1.0", report.as_text())
        text.configure(state="disabled")

        def save_shot() -> None:
            default = f"inspect_{time.strftime('%H%M%S')}.png"
            path = filedialog.asksaveasfilename(
                title="保存截图",
                defaultextension=".png",
                initialfile=default,
                initialdir=str(self.base_dir / "logs"),
                filetypes=[("PNG", "*.png")],
            )
            if not path:
                return
            Image.fromarray(frame.rgb, mode="RGB").save(path)
            logging.getLogger("fgo_auto").info(f"截图已保存：{path}")

        ttk.Button(bar, text="保存截图", command=save_shot).pack(side="left")
        ttk.Button(
            bar, text="学习此界面",
            command=lambda: (win.destroy(), self._learn_scene(frame)),
        ).pack(side="left", padx=6)
        ttk.Button(bar, text="关闭", command=win.destroy).pack(side="right")
        logging.getLogger("fgo_auto").info(f"画面检测：{report.verdict}")

    # ------------------------------------------------------------ 界面识别

    def _toggle_auto_learn(self) -> None:
        enabled = bool(self.scene_auto_var.get())
        self.cfg["scene"]["auto_learn"] = enabled
        if self.engine is not None:
            self.engine.auto_learn = enabled
        logging.getLogger("fgo_auto").info(
            "界面自动学习：" + ("开启" if enabled else "关闭")
        )

    def _selected_scene(self) -> str | None:
        selection = self.scene_tree.selection()
        if not selection:
            return None
        return self.scene_tree.item(selection[0], "text") or None

    def _learn_scene(self, frame=None) -> None:
        if self.engine is None:
            messagebox.showinfo("学习当前界面", "请先连接设备并刷新画面。")
            return
        default = self.engine.last_flow or "新界面"
        name = simpledialog.askstring(
            "学习当前界面",
            "给这一屏起个名字（建议直接用流程名，例如「战斗回合」）：",
            initialvalue=default,
            parent=self,
        )
        if not name:
            return
        added = self.engine.learn_scene(name.strip(), frame)
        self._scene_sig = None
        self._refresh_scene_tree()
        if added:
            messagebox.showinfo("学习当前界面", f"已学习「{name.strip()}」。")
        else:
            messagebox.showinfo("学习当前界面", "已有几乎相同的样本，不用重复学习。")

    def _forget_scene(self) -> None:
        if self.engine is None:
            return
        name = self._selected_scene()
        if not name:
            return
        self.engine.forget_scene(name)
        self._scene_sig = None
        self._refresh_scene_tree()

    def _clear_scenes(self) -> None:
        if self.engine is None:
            return
        if not messagebox.askyesno("清空界面库", "确定清空所有已学习的界面指纹？"):
            return
        self.engine.scenes.clear()
        self.engine.scenes.save(force=True)
        self._scene_sig = None
        self._refresh_scene_tree()
        logging.getLogger("fgo_auto").info("已清空界面库")

    def _save_scenes(self) -> None:
        if self.engine is None:
            return
        if self.engine.scenes.save(force=True):
            logging.getLogger("fgo_auto").info(
                f"界面库已保存：{self.engine.scenes.path}"
            )
        else:
            messagebox.showwarning("保存失败", "界面库写盘失败，检查数据目录权限。")

    def _refresh_scene_tree(self) -> None:
        if self.engine is None:
            return
        rows = self.engine.scene_summary()
        sig = tuple(rows)
        if sig == self._scene_sig:
            return
        self._scene_sig = sig
        self.scene_tree.delete(*self.scene_tree.get_children())
        for name, count in rows:
            self.scene_tree.insert("", "end", text=name, values=(count,))

    # ------------------------------------------------------------ 引擎生命周期

    def _on_backend_change(self) -> None:
        backend = BACKENDS[self.backend_var.get()]
        self.cfg["device"]["backend"] = backend
        if backend == "mock":
            self.device_label.config(text="Mock 演示模式", foreground="#0f766e")
        else:
            self.device_label.config(text="未连接", foreground="#b45309")

    def _make_engine(self) -> Engine:
        self._collect_device_cfg()
        return Engine(self.cfg, base_dir=self.base_dir)

    def _on_connect(self, auto_start: bool = False) -> None:
        """同步连接。adb 建连通常 1~3 秒，宁可卡一下也不跨线程碰 Tk。"""
        if self._busy:
            return
        self._busy = True
        self.connect_btn.config(state="disabled")
        self.device_label.config(text="连接中…", foreground="#b45309")
        self.update_idletasks()
        try:
            engine = self._make_engine()
        except Exception as exc:  # noqa: BLE001 - 展示给用户
            self._busy = False
            self.connect_btn.config(state="normal")
            self.device_label.config(text="连接失败", foreground="#b91c1c")
            messagebox.showerror("连接失败", str(exc))
            return
        self._busy = False
        self.connect_btn.config(state="normal")

        if self.engine is not None and self.engine.is_running:
            self.engine.stop()
            self.engine.join(1.0)
        self.engine = engine
        w, h = engine.device.size
        self.device_label.config(
            text=f"已连接 {engine.device.name}  {w}x{h}", foreground="#0f766e"
        )
        warnings = list(engine.store.warnings)
        missing = engine.missing_templates()
        logging.getLogger("fgo_auto").info(
            f"模板 {len(engine.store)} 张，缺失 {len(missing)} 张"
        )
        for wmsg in warnings:
            logging.getLogger("fgo_auto").warning(wmsg)
        if missing:
            logging.getLogger("fgo_auto").warning(
                "缺失模板: " + ", ".join(missing) + "（缺失的流程会走兜底坐标或跳过）"
            )
        if auto_start:
            self._start_engine()

    def _start_engine(self) -> None:
        if self.engine is None:
            self._on_connect(auto_start=True)
            return
        if self.engine.is_running:
            return
        self.engine.cfg["runtime"]["dry_run"] = bool(self.dry_var.get())
        self.engine.dry_run = bool(self.dry_var.get())
        self.engine.cfg["runtime"]["skip_story"] = bool(self.skip_var.get())
        self.engine.start()
        self.start_btn.config(state="disabled")
        self.stop_btn.config(state="normal")
        logging.getLogger("fgo_auto").info("已开始自动推进")

    def _on_start(self) -> None:
        self._start_engine()

    def _on_stop(self) -> None:
        if self.engine is not None:
            self.engine.stop()
            logging.getLogger("fgo_auto").info("已请求停止，等待当前动作结束…")
        self.start_btn.config(state="normal")
        self.stop_btn.config(state="disabled")

    def _on_step(self) -> None:
        engine = self.engine
        if engine is None:
            self._on_connect(auto_start=False)
            return
        if engine.is_running or self._busy:
            return
        self._busy = True
        self.update_idletasks()
        try:
            engine.step()
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("单步执行失败", str(exc))
        finally:
            self._busy = False

    # ------------------------------------------------------------ 定时刷新

    def _tick(self) -> None:
        self._drain_probe()
        if self._frame_rgb is None and not getattr(self, "_placeholder_shown", False):
            self._draw_no_signal()
            self._placeholder_shown = True
        self._drain_logs()
        snap = self.engine.snapshot() if self.engine is not None else None
        self._snap = snap
        if snap is not None:
            self._render_preview(snap)
            if time.time() - self._last_stats_ts > 0.8:
                self._last_stats_ts = time.time()
                self._update_stats(snap)
        self.after(180, self._tick)

    def _drain_logs(self) -> None:
        lines: list[tuple[str, str]] = []
        while True:
            try:
                item = self.log_queue.get_nowait()
            except queue.Empty:
                break
            if item[0] == "log":
                lines.append((item[2], str(item[1]).lower()))
        if not lines:
            return
        self.log_text.configure(state="normal")
        for text, level in lines:
            tag = {"warning": "warn", "error": "error", "critical": "error", "debug": "debug"}.get(
                level, ""
            )
            self.log_text.insert("end", text + "\n", tag)
        count = int(self.log_text.index("end-1c").split(".")[0])
        if count > LOG_LIMIT:
            self.log_text.delete("1.0", f"{count - LOG_LIMIT + 1}.0")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _update_stats(self, snap: dict) -> None:
        stats = snap["stats"]
        report = snap.get("report") or {}
        self.stats_label.config(
            text=(
                f"步数 {stats['steps']}   点击 {stats['taps']}   "
                f"战斗 {report.get('battles', 0)}   苹果 {report.get('apples', 0)}   "
                f"未知 {stats['unknown']}   用时 {stats['elapsed']:.0f}s   "
                f"模板 {snap['templates']}   缺失 {len(snap['missing'])}"
            )
        )
        if snap["running"]:
            self.start_btn.config(state="disabled")
            self.stop_btn.config(state="normal")
        else:
            self.start_btn.config(state="normal")
            self.stop_btn.config(state="disabled")
        flows = stats.get("flows") or {}
        self.flow_tree.delete(*self.flow_tree.get_children())
        for name, count in sorted(flows.items(), key=lambda kv: -kv[1]):
            self.flow_tree.insert("", "end", text=name, values=(count,))
        if snap.get("error"):
            self.flow_label.config(text=f"已停止：{snap['error']}", foreground="#b91c1c")
        else:
            scene = snap.get("scene")
            score = float(snap.get("scene_score") or 0.0)
            via = "界面识别" if snap.get("via") == "scene" else "模板匹配"
            extra = f"　｜　界面：{scene} {score:.2f}（{via}）" if scene else ""
            self.flow_label.config(
                text=f"当前识别：{snap.get('flow') or '—'}{extra}", foreground="#0f766e"
            )

        if snap.get("scene") is not None:
            self.scene_label.config(
                text=f"当前界面：{snap['scene']}（相似度 {float(snap.get('scene_score') or 0):.2f}）"
            )
        else:
            self.scene_label.config(text="当前界面：—（还没学到这一屏）")
        self._refresh_scene_tree()

    # ------------------------------------------------------------ 预览 / 抓取

    def _draw_canvas_decor(self, tw=None, th=None, ox=None, oy=None) -> None:
        """网格底纹与角落刻度（在画面之下）。"""
        self.canvas.delete("decor")
        cw = max(40, self.canvas.winfo_width())
        ch = max(40, self.canvas.winfo_height())
        theme.draw_grid(self.canvas, 0, 0, cw, ch, "#15191F", 44, tag="decor")
        self.canvas.create_text(
            cw - 10, ch - 8, anchor="se", text="SCREEN // 1280x720",
            fill="#242A32", font=theme.font_mono(8), tags="decor",
        )
        self.canvas.tag_lower("decor")

    def _on_canvas_resize(self, _event=None) -> None:
        if self._frame_rgb is None:
            self._draw_no_signal()
        else:
            self._draw_canvas_decor()

    def _draw_no_signal(self) -> None:
        """还没画面时的占位：NO SIGNAL。"""
        cw = max(80, self.canvas.winfo_width())
        ch = max(60, self.canvas.winfo_height())
        self.canvas.delete("all")
        self._draw_canvas_decor()
        pad = 26
        theme.draw_brackets(self.canvas, pad, pad, cw - pad * 2, ch - pad * 2, theme.LINE, 26)
        size = max(14, min(26, int(cw / 22)))
        self.canvas.create_text(
            cw / 2, ch / 2 - 10, text="NO SIGNAL", fill=theme.MUTED,
            font=theme.font_latin(size, "bold"),
        )
        self.canvas.create_text(
            cw / 2, ch / 2 + 22, text="连接设备后点「检测画面」或「刷新画面」",
            fill="#4A515B", font=theme.font_cn(9),
        )

    def _render_preview(self, snap: dict) -> None:
        rgb = snap.get("frame")
        if rgb is None:
            if self._frame_rgb is None:
                self._draw_no_signal()
            return
        self._frame_rgb = rgb
        self._placeholder_shown = False
        sig = np.asarray(rgb[::16, ::16, :3], dtype=np.int16)
        if (
            self._preview_sig is not None
            and self._preview_sig.shape == sig.shape
            and float(np.abs(sig - self._preview_sig).mean()) < 1.0
        ):
            return  # 画面没变，跳过重绘
        self._preview_sig = sig
        width, height = snap["size"]
        cw = max(80, self.canvas.winfo_width())
        ch = max(60, self.canvas.winfo_height())
        scale = min(cw / width, ch / height)
        tw, th = max(1, int(width * scale)), max(1, int(height * scale))

        from PIL import Image, ImageDraw, ImageTk

        image = Image.fromarray(rgb, mode="RGB").resize((tw, th), Image.BILINEAR)
        draw = ImageDraw.Draw(image)
        for match in snap.get("matches", []):
            x, y, w, h = match["box"]
            box = [int(x * scale), int(y * scale), int((x + w) * scale), int((y + h) * scale)]
            color = (34, 197, 94)
            draw.rectangle(box, outline=color, width=2)
            label = f"{match['name']} {match['score']:.2f}"
            draw.text((box[0] + 2, max(0, box[1] - 14)), label, fill=color)
        self._photo = ImageTk.PhotoImage(image)
        self.canvas.delete("all")
        ox, oy = (cw - tw) / 2, (ch - th) / 2
        self._img_scale = scale
        self._img_off = (ox, oy)
        self._draw_canvas_decor(tw, th, ox, oy)
        self.canvas.create_image(ox, oy, image=self._photo, anchor="nw")
        # 画面边框 + 取景角标
        self.canvas.create_rectangle(ox, oy, ox + tw, oy + th, outline=theme.LINE, width=1)
        theme.draw_brackets(self.canvas, ox - 1, oy - 1, tw + 2, th + 2, theme.ACCENT, 18)
        # 顶部状态标签
        live = "LIVE" if snap.get("running") else "STANDBY"
        live_color = theme.ACCENT if snap.get("running") else theme.MUTED
        self.canvas.create_text(
            ox + 10, oy - 14, anchor="w", text=f"◉ {live}", fill=live_color,
            font=theme.font_mono(9),
        )
        if snap.get("flow"):
            self.canvas.create_text(
                ox + 10, oy + 12, anchor="nw", text=f"FLOW  {snap['flow']}",
                fill=theme.ACCENT, font=theme.font_latin(12, "bold"),
            )
        if not snap["running"]:
            self.canvas.create_text(
                ox + 10, oy + th - 18, anchor="nw", text="未运行 · 可单步调试",
                fill=theme.MUTED, font=theme.font_cn(9),
            )

    def _on_refresh_frame(self) -> None:
        if self.engine is None:
            self._on_connect(auto_start=False)
            return
        if self._busy or self.engine.is_running:
            return
        self._busy = True
        self.update_idletasks()
        try:
            self.engine.grab()
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("截屏失败", str(exc))
        finally:
            self._busy = False

    def _on_capture_mode(self) -> None:
        if self.capture_var.get():
            self.pick_var.set(False)
            logging.getLogger("fgo_auto").info("抓取模板模式：在画面上按住左键拖出要保存的模板区域")
        self.canvas.config(cursor="tcross" if self.capture_var.get() else "crosshair")

    def _on_pick_mode(self) -> None:
        if self.pick_var.get():
            self.capture_var.set(False)
            logging.getLogger("fgo_auto").info("坐标拾取模式：点击画面任意位置，复制归一化坐标")
        self.canvas.config(cursor="tcross" if self.pick_var.get() else "crosshair")

    def _canvas_to_image(self, cx: float, cy: float) -> tuple[int, int] | None:
        if self._frame_rgb is None:
            return None
        ox, oy = self._img_off
        scale = self._img_scale or 1.0
        x = (cx - ox) / scale
        y = (cy - oy) / scale
        h, w = self._frame_rgb.shape[:2]
        x = int(max(0, min(round(x), w - 1)))
        y = int(max(0, min(round(y), h - 1)))
        return x, y

    def _on_canvas_press(self, event: tk.Event) -> None:
        if self.capture_var.get():
            self._drag_start = (event.x, event.y)
            self._drag_rect = self.canvas.create_rectangle(
                event.x, event.y, event.x, event.y, outline="#f59e0b", width=2
            )

    def _on_canvas_drag(self, event: tk.Event) -> None:
        if self._drag_start and self._drag_rect:
            self.canvas.coords(
                self._drag_rect, self._drag_start[0], self._drag_start[1], event.x, event.y
            )

    def _on_canvas_release(self, event: tk.Event) -> None:
        if self._drag_start:
            start = self._drag_start
            self._drag_start = None
            if self._drag_rect:
                self.canvas.delete(self._drag_rect)
                self._drag_rect = None
            a = self._canvas_to_image(*start)
            b = self._canvas_to_image(event.x, event.y)
            if a and b:
                x0, x1 = sorted((a[0], b[0]))
                y0, y1 = sorted((a[1], b[1]))
                if x1 - x0 >= 8 and y1 - y0 >= 8:
                    self._prompt_save_template((x0, y0, x1 - x0, y1 - y0))
                else:
                    logging.getLogger("fgo_auto").warning("选区太小（至少 8x8 像素）")
        elif self.pick_var.get():
            pt = self._canvas_to_image(event.x, event.y)
            if pt and self._frame_rgb is not None:
                h, w = self._frame_rgb.shape[:2]
                nx, ny = pt[0] / w, pt[1] / h
                text = f"[{nx:.3f}, {ny:.3f}]"
                self.clipboard_clear()
                self.clipboard_append(text)
                logging.getLogger("fgo_auto").info(
                    f"坐标 {text} 已复制（像素 {pt}，画面 {w}x{h}）"
                )

    def _prompt_save_template(self, box: tuple[int, int, int, int]) -> None:
        if self._frame_rgb is None or self.engine is None:
            messagebox.showwarning("无法保存", "请先连接设备并刷新画面")
            return
        x, y, w, h = box
        crop = self._frame_rgb[y : y + h, x : x + w]
        if crop.size == 0:
            return
        name = simpledialog.askstring(
            "保存模板",
            f"选区 {w}x{h}，输入模板名（例如 t_attack）：",
            parent=self,
        )
        if not name:
            return
        try:
            path = self.engine.store.add(name.strip(), crop)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("保存失败", str(exc))
            return
        self.engine.matcher.clear_cache()
        logging.getLogger("fgo_auto").info(f"已保存模板 {path.name}（{w}x{h}）")
        self._refresh_missing_hint()

    def _refresh_missing_hint(self) -> None:
        if self.engine is None:
            return
        missing = self.engine.missing_templates()
        if missing:
            logging.getLogger("fgo_auto").warning("仍缺模板: " + ", ".join(missing))

    # ------------------------------------------------------------ 模板管理

    def _template_dir(self) -> Path:
        if self.engine is not None:
            return self.engine.templates_dir
        return template_dir(self.cfg, self.base_dir)

    def _open_templates(self) -> None:
        if self.engine is None:
            self._on_connect(auto_start=False)
            return
        win = tk.Toplevel(self)
        win.title("模板管理器")
        win.geometry("640x460")
        win.transient(self)

        left = ttk.Frame(win, padding=8)
        left.pack(side="left", fill="both", expand=True)
        right = ttk.Frame(win, padding=8)
        right.pack(side="right", fill="y")

        names = sorted(self.engine.store.names())
        listbox = tk.Listbox(left, height=20)
        listbox.pack(fill="both", expand=True)
        for name in names:
            listbox.insert("end", name)

        preview = ttk.Label(right, text="", relief="sunken", anchor="center", width=32)
        preview.pack(fill="x", pady=(0, 6))
        info = ttk.Label(right, text="", justify="left", wraplength=240)
        info.pack(fill="x", pady=(0, 6))

        def on_select(_event: object = None) -> None:
            selection = listbox.curselection()
            if not selection:
                return
            tpl = self.engine.store.get(names[selection[0]])
            if tpl is None:
                return
            from PIL import Image, ImageTk

            image = Image.fromarray(tpl.rgb, mode="RGB")
            image.thumbnail((240, 160))
            photo = ImageTk.PhotoImage(image)
            preview.configure(image=photo)
            preview.image = photo  # type: ignore[attr-defined]
            info.config(
                text=(
                    f"{tpl.name}\n尺寸 {tpl.width}x{tpl.height}\n"
                    f"阈值 {tpl.threshold if tpl.threshold is not None else '默认'}"
                )
            )

        listbox.bind("<<ListboxSelect>>", on_select)

        def delete_selected() -> None:
            selection = listbox.curselection()
            if not selection:
                return
            name = names[selection[0]]
            if not messagebox.askyesno("删除模板", f"确定删除 {name} ？", parent=win):
                return
            if self.engine.store.remove(name):
                listbox.delete(selection[0])
                logging.getLogger("fgo_auto").info(f"已删除模板 {name}")
                self._refresh_missing_hint()

        ttk.Button(right, text="删除选中", command=delete_selected).pack(fill="x", pady=2)
        ttk.Button(
            right, text="打开模板目录", command=lambda: self._open_path(self._template_dir())
        ).pack(fill="x", pady=2)
        ttk.Button(right, text="关闭", command=win.destroy).pack(fill="x", pady=(12, 2))

    def _show_tpl_wizard(self) -> None:
        """模板抓取向导：抓一张实时画面，框选后依次保存缺失的模板。"""
        from PIL import Image, ImageTk

        from .config import template_dir
        from .templates import collect_template_names

        tdir = template_dir(self.cfg)
        tdir.mkdir(parents=True, exist_ok=True)
        names = list(collect_template_names(self.cfg))
        missing = [n for n in names if not (tdir / f"{n}.png").exists()]
        if not missing:
            messagebox.showinfo("模板抓取向导", "模板已经齐了，不需要再抓。")
            return

        win = tk.Toplevel(self)
        win.title("模板抓取向导")
        win.geometry("1180x760")
        win.configure(bg=theme.BG)
        ttk.Label(
            win, text="① 抓到当前画面  ② 用鼠标框选按钮  ③ 点「保存并下一个」",
            style="Accent.TLabel",
        ).pack(anchor="w", padx=10, pady=(8, 4))

        body = ttk.Frame(win)
        body.pack(fill="both", expand=True, padx=10)

        canvas = tk.Canvas(body, bg=theme.BG_ALT, highlightthickness=1,
                           highlightbackground=theme.LINE)
        canvas.pack(side="left", fill="both", expand=True)
        side = ttk.Frame(body, width=300)
        side.pack(side="right", fill="y", padx=(10, 0))

        ttk.Label(side, text="还缺的模板", style="Label.TLabel").pack(anchor="w")
        tree = ttk.Treeview(side, columns=("done",), show="tree", height=14)
        tree.pack(fill="both", expand=True, pady=(4, 8))
        for name in missing:
            tree.insert("", "end", iid=name, text=name, values=("待抓",))

        state: dict = {"frame": None, "photo": None, "scale": 1.0, "off": (0, 0),
                       "start": None, "rect": None, "name": missing[0]}

        def redraw() -> None:
            canvas.delete("all")
            frame = state["frame"]
            if frame is None:
                canvas.create_text(20, 20, anchor="nw", text="先点「抓取当前画面」",
                                   fill=theme.MUTED, font=theme.font_cn(10))
                return
            cw = max(200, canvas.winfo_width())
            ch = max(160, canvas.winfo_height())
            h, w = frame.shape[:2]
            scale = min(cw / w, ch / h)
            tw, th = max(1, int(w * scale)), max(1, int(h * scale))
            img = Image.fromarray(frame).resize((tw, th), Image.BILINEAR)
            photo = ImageTk.PhotoImage(img)
            state["photo"] = photo
            state["scale"] = scale
            ox, oy = (cw - tw) / 2, (ch - th) / 2
            state["off"] = (ox, oy)
            canvas.create_image(ox, oy, image=photo, anchor="nw")

        def grab() -> None:
            try:
                if self.engine is not None:
                    state["frame"] = self.engine.grab().rgb
                elif self._frame_rgb is not None:
                    state["frame"] = self._frame_rgb
                else:
                    self._on_connect(auto_start=False)
                    state["frame"] = self.engine.grab().rgb if self.engine else None
            except Exception as exc:  # noqa: BLE001
                messagebox.showerror("抓取失败", str(exc))
                return
            state["rect"] = None
            redraw()

        def on_press(event) -> None:
            state["start"] = (event.x, event.y)
            state["rect"] = None

        def on_drag(event) -> None:
            if not state["start"] or state["frame"] is None:
                return
            canvas.delete("sel")
            canvas.create_rectangle(
                state["start"][0], state["start"][1], event.x, event.y,
                outline=theme.ACCENT, width=2, tags="sel",
            )

        def on_release(event) -> None:
            if not state["start"] or state["frame"] is None:
                return
            x0, y0 = state["start"]
            x1, y1 = event.x, event.y
            ox, oy = state["off"]
            scale = state["scale"]
            fx0 = int(max(0, (min(x0, x1) - ox) / scale))
            fy0 = int(max(0, (min(y0, y1) - oy) / scale))
            fx1 = int(max(0, (max(x0, x1) - ox) / scale))
            fy1 = int(max(0, (max(y0, y1) - oy) / scale))
            if fx1 - fx0 < 8 or fy1 - fy0 < 8:
                state["rect"] = None
                return
            state["rect"] = (fx0, fy0, fx1, fy1)
            canvas.delete("sel")
            canvas.create_rectangle(min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1),
                                    outline=theme.ACCENT, width=2, tags="sel")

        def save_current() -> None:
            if state["frame"] is None or state["rect"] is None:
                messagebox.showwarning("模板抓取向导", "请先抓画面并框选一个按钮。")
                return
            name = tree.selection()[0] if tree.selection() else state["name"]
            x0, y0, x1, y1 = state["rect"]
            crop = state["frame"][y0:y1, x0:x1]
            Image.fromarray(crop).save(tdir / f"{name}.png")
            tree.set(name, "done", "已保存")
            tree.item(name, text=f"{name} ✓")
            logging.getLogger("fgo_auto").info(f"模板已保存: {name} ({x1 - x0}x{y1 - y0})")
            state["rect"] = None
            canvas.delete("sel")
            nxt = [n for n in missing if not (tdir / f"{n}.png").exists()]
            if nxt:
                tree.selection_set(nxt[0])
                state["name"] = nxt[0]
            else:
                messagebox.showinfo("模板抓取向导", "全部补齐了，重启任务即可使用。")

        canvas.bind("<ButtonPress-1>", on_press)
        canvas.bind("<B1-Motion>", on_drag)
        canvas.bind("<ButtonRelease-1>", on_release)
        canvas.bind("<Configure>", lambda _e: redraw())

        ttk.Button(side, text="抓取当前画面", style="Accent.TButton", command=grab).pack(fill="x")
        ttk.Button(side, text="保存并下一个", command=save_current).pack(fill="x", pady=6)
        ttk.Button(side, text="关闭", style="Ghost.TButton", command=win.destroy).pack(fill="x")
        win.after(150, grab)

    def _show_unknown_screens(self) -> None:
        """列出运行中遇到的、没有模板的界面（来自 logs/unknown.jsonl）。"""
        import json as _json

        path = Path(get_path(self.cfg, "runtime.log_dir", "logs")) / "unknown.jsonl"
        records: list[dict] = []
        if path.exists():
            for line in path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(_json.loads(line))
                except _json.JSONDecodeError:
                    continue
        win = tk.Toplevel(self)
        win.title("未知界面记录")
        win.geometry("760x420")
        win.configure(bg=theme.BG)
        text = tk.Text(
            win, wrap="word", bg=theme.PANEL, fg=theme.TEXT, insertbackground=theme.ACCENT,
            relief="flat", bd=0, font=theme.font_mono(9), padx=8, pady=6,
        )
        text.pack(fill="both", expand=True, padx=8, pady=8)
        if not records:
            text.insert("end", "还没有记录。跑一轮后，没认出来的界面会记在这里。\n")
            text.insert("end", f"文件位置：{path}\n")
        else:
            text.insert("end", f"共 {len(records)} 种未知界面（同一屏只记一次）：\n\n")
            for index, item in enumerate(records, 1):
                top = "，".join(f"{n}={s:.2f}" for n, s in (item.get("top") or []))
                size = "x".join(str(x) for x in (item.get("size") or []))
                text.insert("end", f"{index}. 分辨率 {size}  最接近：{top}\n")
            text.insert("end", "\n建议：按「最接近」里分数最高的那个流程，抓一张对应按钮的模板。\n")
            text.insert("end", f"文件位置：{path}\n")
        text.config(state="disabled")
        ttk.Button(win, text="关闭", command=win.destroy).pack(pady=(0, 10))

    def _show_missing(self) -> None:
        usage = template_usage(self.cfg)
        have = set(self.engine.store.names()) if self.engine else set()
        missing = [(n, where) for n, where in sorted(usage.items()) if n not in have]
        win = tk.Toplevel(self)
        win.title("缺失模板清单")
        win.geometry("620x420")
        win.transient(self)
        text = tk.Text(win, wrap="word")
        text.pack(fill="both", expand=True, padx=8, pady=8)
        if not missing:
            text.insert("1.0", "所有模板齐全。\n")
        else:
            text.insert(
                "1.0",
                "以下模板还没有抓取。缺失的流程会用兜底坐标，或直接跳过：\n\n",
            )
            for name, where in missing:
                text.insert("end", f"• {name:<22} 用于：{', '.join(where) or '—'}\n")
            text.insert(
                "end",
                "\n用法：勾选「抓取模板模式」，在画面上框住对应按钮/文字，输入上面的名字保存。\n",
            )
        text.configure(state="disabled")

    # ------------------------------------------------------------ 战斗方案 / 报告

    def _import_plan(self) -> None:
        if self.engine is None:
            self._on_connect(auto_start=False)
            if self.engine is None:
                return
        path = filedialog.askopenfilename(
            title="选择战斗方案 JSON",
            filetypes=[("战斗方案", "*.json"), ("所有文件", "*.*")],
            initialdir=str(self.base_dir),
        )
        if not path:
            return
        try:
            plan = self.engine.set_plan(path)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("导入失败", str(exc))
            return
        if plan is not None:
            self.cfg["battle"]["plan"] = path
            messagebox.showinfo(
                "已导入战斗方案",
                f"{plan.name}\n\n{plan.describe(6)}\n\n"
                "注意：技能/宝具优先用 t_skill_<从者>_<技能>、t_np_<从者> 模板，"
                "没有模板时用 battle.skill_grid / np_grid 坐标（需校准）。",
            )

    def _clear_plan(self) -> None:
        if self.engine is None:
            return
        self.engine.set_plan(None)
        self.cfg["battle"]["plan"] = ""
        logging.getLogger("fgo_auto").info("已清除战斗方案，回到旧技能轴")

    def _check_templates(self) -> None:
        if self.engine is None:
            self._on_connect(auto_start=False)
            if self.engine is None:
                return
        if self.engine.is_running or self._busy:
            messagebox.showinfo("模板体检", "请先停止运行再体检，避免和识别抢设备。")
            return
        self._busy = True
        self.update_idletasks()
        try:
            rows = self.engine.check_templates()
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("体检失败", str(exc))
            return
        finally:
            self._busy = False

        win = tk.Toplevel(self)
        win.title("模板体检")
        win.geometry("620x480")
        win.transient(self)
        tree = ttk.Treeview(
            win, columns=("score", "thr", "verdict"), show="tree headings", height=18
        )
        tree.heading("#0", text="模板")
        tree.heading("score", text="分数")
        tree.heading("thr", text="阈值")
        tree.heading("verdict", text="结论")
        tree.column("#0", width=220)
        tree.column("score", width=70, anchor="center")
        tree.column("thr", width=60, anchor="center")
        tree.column("verdict", width=200)
        tree.pack(fill="both", expand=True, padx=8, pady=(8, 4))
        for row in rows:
            if row["ok"]:
                verdict = "命中"
            elif row["color_rejected"]:
                verdict = "分数够但颜色不符"
            elif row["score"] >= row["threshold"] - 0.05:
                verdict = "临界，建议降阈值/重抓"
            else:
                verdict = "未命中"
            tree.insert(
                "", "end", text=row["name"],
                values=(f"{row['score']:.3f}", f"{row['threshold']:.3f}", verdict),
            )
        good = sum(1 for r in rows if r["ok"])
        footer = ttk.Label(
            win,
            text=f"命中 {good}/{len(rows)}；结果已写入 logs/template_check.txt",
            padding=(10, 4),
        )
        footer.pack(fill="x")
        try:
            lines = ["模板\t分数\t阈值\t结论"]
            for row in rows:
                verdict = (
                    "命中" if row["ok"]
                    else ("颜色不符" if row["color_rejected"] else "未命中")
                )
                lines.append(f"{row['name']}\t{row['score']:.3f}\t{row['threshold']:.3f}\t{verdict}")
            (self.base_dir / "logs").mkdir(parents=True, exist_ok=True)
            (self.base_dir / "logs" / "template_check.txt").write_text(
                "\n".join(lines) + "\n", encoding="utf-8"
            )
        except OSError:
            pass

    def _show_report(self) -> None:
        if self.engine is None:
            messagebox.showinfo("运行摘要", "还没有连接设备。")
            return
        summary = self.engine.report.summary()
        text = "\n".join(f"{key}: {value}" for key, value in summary.items())
        messagebox.showinfo(
            "运行摘要",
            text + f"\n\n明细: {self.engine.report.events_path}\n汇总: {self.engine.report.summary_path}",
        )

    def _show_help(self) -> None:
        messagebox.showinfo(
            "使用说明",
            "1. 打开模拟器（MuMu / LDPlayer / BlueStacks 等），在模拟器设置里开启 ADB 调试。\n"
            "2. 顶部选「ADB 真机 / 模拟器」，点「连接设备」；连不上就填 adb 路径或设备序列号。\n"
            "3. 第一次使用：勾选「抓取模板模式」，在游戏画面上框选按钮并命名为清单里的模板名。\n"
            "4. 缺模板可以点「缺失模板」查看清单和用途。\n"
            "5. 点「开始」；「干跑」只识别不点击，适合先验证识别是否稳定。\n"
            "6. 想先看效果：后端切到「Mock 演示」，点开始即可跑通全流程。\n\n"
            "坐标拾取：勾选后点画面任意位置，会把归一化坐标复制到剪贴板，可粘进 config.json 的 params。",
        )

    def _show_about(self) -> None:
        messagebox.showinfo(
            "关于",
            f"{APP_TITLE} v{__version__}\n\n"
            "纯本地运行的画面识别 + 点击自动化，不修改游戏、不读取内存。\n"
            "仅用于单机推进与学习交流，使用风险自负。",
        )

    # ------------------------------------------------------------ 文件操作

    def _open_dir(self) -> None:
        self._open_path(self.base_dir)

    def _open_logs(self) -> None:
        self._open_path(self.base_dir / "logs")

    def _open_templates_dir(self) -> None:
        path = self._template_dir()
        path.mkdir(parents=True, exist_ok=True)
        self._open_path(path)

    @staticmethod
    def _open_path(path: Path) -> None:
        import os
        import subprocess

        try:
            if os.name == "nt":
                os.startfile(str(path))  # type: ignore[attr-defined]
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("打开失败", f"{path}\n{exc}")

    # ------------------------------------------------------------ 退出

    def _on_close(self) -> None:
        try:
            if self.engine is not None:
                self.engine.stop()
                self.engine.join(2.0)
        finally:
            self.destroy()


def _fatal_dialog() -> None:
    """没有控制台时（pythonw / EXE），把启动异常显示出来，而不是静默退出。"""
    import traceback

    detail = traceback.format_exc()
    try:
        from tkinter import messagebox

        messagebox.showerror(
            APP_TITLE,
            "启动失败：\n\n" + detail[-1600:] +
            "\n\n数据目录写不进去时也会这样，可检查该目录权限。",
        )
    except Exception:  # pragma: no cover - 连弹窗都起不来就算了
        pass


def main() -> None:
    try:
        app = App()
    except Exception:
        _fatal_dialog()
        raise
    app.mainloop()


if __name__ == "__main__":
    main()
